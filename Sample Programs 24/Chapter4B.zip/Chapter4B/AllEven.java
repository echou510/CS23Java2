
public class AllEven
{
    static int[] a = {1, 2, 3, 4, 5}; 
    static int[] b = {1, 3, 5, 7, 9}; 
    static int[] c = {2, 4, 6, 8, 10};
    
    public static boolean allEven(int[] x){
      for (int i=0; i<x.length; i++){
          if (x[i]%2 !=0) return false; 
        }
      return true; 
    }
    public static boolean allOdd(int[] x){
      for (int i=0; i<x.length; i++){
          if (x[i]%2 ==0) return false; 
        }
      return true; 
    }
    public static boolean hasEven(int[] x){
      for (int i=0; i<x.length; i++){
          if (x[i]%2 ==0) return true; 
        }
      return false; 
    }
    public static boolean hasOdd(int[] x){
      for (int i=0; i<x.length; i++){
          if (x[i]%2 !=0) return true; 
        }
      return false; 
    }
    
    public static void main(String[] args){
       System.out.print("\f");
       System.out.printf("a is allEven is %b\n", allEven(a)); 
       System.out.printf("a is allOdd is %b\n",  allOdd(a)); 
       System.out.printf("a is hasEven is %b\n", hasEven(a)); 
       System.out.printf("a is hasOdd is %b\n",  hasOdd(a)); 
       System.out.println(); 
       System.out.printf("b is allEven is %b\n", allEven(b)); 
       System.out.printf("b is allOdd is %b\n",  allOdd(b)); 
       System.out.printf("b is hasEven is %b\n", hasEven(b)); 
       System.out.printf("b is hasOdd is %b\n",  hasOdd(b)); 
       System.out.println(); 
       System.out.printf("c is allEven is %b\n", allEven(c)); 
       System.out.printf("c is allOdd is %b\n",  allOdd(c)); 
       System.out.printf("c is hasEven is %b\n", hasEven(c)); 
       System.out.printf("c is hasOdd is %b\n",  hasOdd(c)); 
       System.out.println(); 
    }
}
