
public class Even
{
    public static boolean isEven1(int n){
       if (n%2==0){ 
           return true; 
        }
       else { 
           return false;
        }
    }
    public static boolean isEven2(int n){
       if (n%2==0){ 
           return true; 
        }
       // n%2!=0 after this line
       return false;
    }
    public static boolean isEven3(int n){
       return n%2==0; 
    }
    public static void main(String[] args){
      System.out.print("\f");
      
      System.out.printf("%d is even is %b\n", 5, isEven1(5)); 
      System.out.printf("%d is even is %b\n", 5, isEven2(5)); 
      System.out.printf("%d is even is %b\n", 5, isEven3(5)); 
      System.out.println(); 
      System.out.printf("%d is even is %b\n", 4, isEven1(4)); 
      System.out.printf("%d is even is %b\n", 4, isEven2(4)); 
      System.out.printf("%d is even is %b\n", 4, isEven3(4)); 
    }
}
