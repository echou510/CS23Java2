
public class AP2_RunningIndex
{
     public static double[] list = {1.0, 2.0, 3.0, 4.0, 5.0, 
                                   6.0, 7.0, 8.0, 9.0, 10.0};
     
     public static void main(String[] args){
         System.out.print("\f");
         int p=0; 
         while (p<list.length){
             System.out.println(list[p++]);    
         }
      }
   
}
