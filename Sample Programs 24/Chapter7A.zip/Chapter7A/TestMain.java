
/**
 * Write a description of class TestMain here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class TestMain
{
   public static void main(String[] args){
        String[] strings = {"New York", "Boston", "Atlanta"}; 
        A.main(strings); 
   }
} 
