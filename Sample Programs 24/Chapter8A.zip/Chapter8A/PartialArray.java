
public class PartialArray
{
  public static int[][] m  = {
      {1, 2, 3}, 
      {4, 5, 6}, 
      {7, 8, 9}
    };
  public static void printLowerTriangle(String title, int[][] m){
       System.out.println(title); 
       for (int r=0; r<m.length; r++){
          for (int c=0; c<=r; c++){
               System.out.printf("%3d ", m[r][c]); 
            }
          System.out.println(); 
        }
    }
    public static void printUpperTriangle(String title, int[][] m){
       System.out.println(title); 
       for (int r=0; r<m.length; r++){
          for (int i=0; i<r; i++) System.out.printf("%3s ", " "); 
          for (int c=r; c<m.length; c++){
               System.out.printf("%3d ", m[r][c]); 
            }
          System.out.println(); 
        }
    }
  public static void main(String[] args){
      System.out.print("\f");
      printLowerTriangle("Lower Triangle", m);
      printUpperTriangle("Upper Triangle", m); 
    }
}
