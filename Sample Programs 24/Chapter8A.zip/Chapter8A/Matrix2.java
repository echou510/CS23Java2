import java.util.*; 
public class Matrix2
{   
    static int[][] m; 
    public static void printMatrix(int[][] m){
       if (m==null) { System.out.println(m);  return; }
       
       for (int r=0; r<m.length; r++){ // m.length means how many rows in the matrix m
            if (m[r]==null) { System.out.println(m[r]);  continue; }
            for (int c=0; c<m[r].length; c++){
               System.out.printf("%5d", m[r][c]); 
            }
            System.out.println(); 
        }
    }
    public static void randomizeMatrix(int[][] m, int start, int end){
       if (m==null) { System.out.println(m);  return; }
       
       for (int r=0; r<m.length; r++){ // m.length means how many rows in the matrix m
            if (m[r]==null) { System.out.println(m[r]);  continue; }
            for (int c=0; c<m[r].length; c++){
               int count = end - start; 
               int x = (int)(Math.random()*count) + start; // [start, end)
               m[r][c] = x; 
            }
        }
    }
    public static void main(String[] args){
       System.out.print("\f"); 
       System.out.println("Part 1: Declaration"); 
       System.out.println(m); 
       System.out.println(); 
       System.out.println("Part 2: Instantiation of 2D Matrix Step 1"); 
       m =new int[][]{null, null, null}; 
       System.out.println(m);
       System.out.println("m[][]="+Arrays.toString(m)); 
       System.out.println(); 
       System.out.println("Part 3: Instantiation of 2D Matrix Step 2 - ragged matrix"); 
       m[0] = new int[]{1, 2}; 
       m[1] = null; 
       m[2] = new int[]{3, 5, 6, 7, 8}; 
       printMatrix(m); 
       System.out.println(); 
       System.out.println("Part 4: Instantiation of 2D Matrix Step 3 - uniform"); 
       for (int row =0; row <m.length; row++){
           m[row] = new int[3]; 
        }
       printMatrix(m); 
       System.out.println(); 
       
       System.out.println("Part 5: Initialization of 2D Matrix by Randomization"); 
       randomizeMatrix(m, 0, 101); 
       printMatrix(m); 
       System.out.println(); 
    }
}
