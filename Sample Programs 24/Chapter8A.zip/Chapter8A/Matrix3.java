import java.util.*; 
public class Matrix3
{
    static int[][] m = new int[4][5]; // all zero have been assigned to each cell. 
     
    public static void printMatrix(int[][] m){
       for (int r=0; r<m.length; r++){ // m.length means how many rows in the matrix m
            for (int c=0; c<m[r].length; c++){
               System.out.printf("%5d", m[r][c]); 
            }
            System.out.println(); 
        }
    }
    public static void randomizeMatrix(int[][] m, int start, int end){
       for (int r=0; r<m.length; r++){ // m.length means how many rows in the matrix m
            for (int c=0; c<m[r].length; c++){
               m[r][c] = (int)(Math.random()*(end-start)) + start;
            }
        }
    }
    
    public static void resetMatrix(int[][] m){
        for (int r=0; r<m.length; r++){ // m.length means how many rows in the matrix m
            for (int c=0; c<m[r].length; c++){
               m[r][c] = 0; 
            }
        }
    }
    
    public static void inputMatrix(int[][] m){
        Scanner input = new Scanner(System.in); 
        for (int r=0; r<m.length; r++){ // m.length means how many rows in the matrix m
            for (int c=0; c<m[r].length; c++){
               System.out.printf("Enter the element at m[%d][%d]:", r, c); 
               m[r][c] = Integer.parseInt(input.nextLine()); 
            }
        }
    }
    
    public static void main(String[] args){
       System.out.print("\f");
       System.out.println("Initialization of a 4x5 matrix"); 
       randomizeMatrix(m, 0, 100);
       printMatrix(m); 
       System.out.println(); 
       System.out.println("Reset of a 4x5 matrix"); 
       resetMatrix(m);
       printMatrix(m); 
       System.out.println(); 
       System.out.println("Input 4x5 matrix"); 
       inputMatrix(m);
       printMatrix(m); 
       System.out.println(); 
    }
}
