
public class Traversal
{
  static int[][] m = {
      {1, 2, 3, 4, 5}, 
      {6, 7, 8, 9, 10}, 
      {11, 12, 13, 14, 15}, 
      {16, 17, 18, 19, 20}, 
      {21, 22, 23, 24, 25}
    }; 
    
  public static void printMatrix0(int[][] m){
       for (int r=0; r<m.length; r++){ // m.length means how many rows in the matrix m
            for (int c=0; c<m[r].length; c++){
               System.out.printf("%3d", m[r][c]); 
            }
        }
    }
  public static void printMatrix1(int[][] m){
       for (int r=0; r<m.length; r++){ // m.length means how many rows in the matrix m
            for (int c=m[r].length-1; c>=0; c--){
               System.out.printf("%3d", m[r][c]); 
            }
        }
    }
    public static void printMatrix2(int[][] m){
       for (int r=m.length-1; r>=0; r--){ // m.length means how many rows in the matrix m
            for (int c=0; c<m[r].length; c++){
               System.out.printf("%3d", m[r][c]); 
            }
        }
    }
  public static void printMatrix3(int[][] m){
       for (int r=m.length-1; r>=0; r--){ // m.length means how many rows in the matrix m
            for (int c=m[r].length-1; c>=0; c--){
               System.out.printf("%3d", m[r][c]); 
            }
        }
    }
      public static void printMatrix4(int[][] m){
        for (int c=0; c<m[0].length; c++){
            for (int r=0; r<m.length; r++){ // m.length means how many rows in the matrix m
               System.out.printf("%3d", m[r][c]); 
            }
        }
    }
  public static void printMatrix5(int[][] m){
      for (int c=m[0].length-1; c>=0; c--){
       for (int r=0; r<m.length; r++){ // m.length means how many rows in the matrix m
               System.out.printf("%3d", m[r][c]); 
            }
        }
    }
    public static void printMatrix6(int[][] m){
      for (int c=0; c<m[0].length; c++){
       for (int r=m.length-1; r>=0; r--){ // m.length means how many rows in the matrix m
               System.out.printf("%3d", m[r][c]); 
            }
        }
    }
  public static void printMatrix7(int[][] m){
    for (int c=m[0].length-1; c>=0; c--){
       for (int r=m.length-1; r>=0; r--){ // m.length means how many rows in the matrix m

               System.out.printf("%3d", m[r][c]); 
            }
        }
    }
    public static void randomizeMatrix(int[][] m, int start, int end){
       for (int r=0; r<m.length; r++){ // m.length means how many rows in the matrix m
            for (int c=0; c<m[r].length; c++){
               m[r][c] = (int)(Math.random()*(end-start)) + start;
            }
        }
    }
    
    public static void resetMatrix(int[][] m){
        for (int r=0; r<m.length; r++){ // m.length means how many rows in the matrix m
            for (int c=0; c<m[r].length; c++){
               m[r][c] = 0; 
            }
        }
    }
    
    public static void main(String[] args){
      System.out.print("\f"); 
      System.out.print("RSS: "); 
      printMatrix0(m); 
      System.out.println(); 
      System.out.print("RSB: "); 
      printMatrix1(m); 
      System.out.println(); 
      System.out.print("RBS: "); 
      printMatrix2(m); 
      System.out.println(); 
      System.out.print("RBB: "); 
      printMatrix3(m); 
      System.out.println(); 
      System.out.print("CSS: "); 
      printMatrix4(m); 
      System.out.println(); 
      System.out.print("CSB: "); 
      printMatrix5(m); 
      System.out.println(); 
      System.out.print("CBS: "); 
      printMatrix6(m); 
      System.out.println(); 
      System.out.print("CBB: "); 
      printMatrix7(m); 
      System.out.println(); 
    }
}
