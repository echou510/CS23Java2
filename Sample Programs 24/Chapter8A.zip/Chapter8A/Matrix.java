
public class Matrix
{
   static int[][] mat = {
       {1, 2, 3},   // row 0 
       {4, 5, 6},   // row 1
       {7, 8, 9}    // row 2 
    }; 
    
   public static void printMatrix(int[][] m){
       for (int r=0; r<m.length; r++){ // m.length means how many rows in the matrix m
            for (int c=0; c<m[r].length; c++){
               System.out.print(m[r][c]+" "); 
            }
            System.out.println(); 
        }
    }
    
    
   public static void main(String[] args){
       System.out.print("\f");
       printMatrix(mat); 
    }
}
