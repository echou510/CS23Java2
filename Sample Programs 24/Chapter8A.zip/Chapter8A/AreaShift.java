
public class AreaShift
{
   static int[][] m = {
       {1, 2, 3, 4, 5}, 
       {2, 3, 4, 5, 6},  
       {3, 4, 5, 6, 7}
    }; 
    
   public static void areaShift(int[][] m){
       for (int r = 0; r<m.length; r++){
           int temp = m[r][0]; 
           for (int c=1; c<m[r].length; c++){
               m[r][c-1] = m[r][c]; 
            } 
           m[r][m[r].length-1] = temp; 
        }
    }

   public static void printMatrix(String title, int[][] m){
       System.out.println(title); 
       for (int r=0; r<m.length; r++){
           for (int c=0; c<m[r].length; c++){
               System.out.printf("%3d ", m[r][c]); 
            }
           System.out.println(); 
        }
       System.out.println(); 
    }

   public static void main(String[] args){
      System.out.print("\f");
      printMatrix("Scene 1:", m);
      areaShift(m); 
      printMatrix("Scene 2:", m);
      areaShift(m); 
      printMatrix("Scene 3:", m);
      areaShift(m); 
      printMatrix("Scene 4:", m);
      areaShift(m); 
    }
}
