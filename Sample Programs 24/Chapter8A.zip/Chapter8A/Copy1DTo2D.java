import java.util.*; 
public class Copy1DTo2D
{
    static int[] a = {1, 2, 3, 4, 5, 6, 7, 8, 
     9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20}; 
    
    static int[][] m = new int[5][5]; 
    static int[][] n = new int[4][4]; 
    
    public static void printMatrix(int[][] m){
       for (int r=0; r<m.length; r++){ // m.length means how many rows in the matrix m
            for (int c=0; c<m[r].length; c++){
               System.out.printf("%5d", m[r][c]); 
            }
            System.out.println(); 
        }
    }
    public static void randomizeMatrix(int[][] m, int start, int end){
       for (int r=0; r<m.length; r++){ // m.length means how many rows in the matrix m
            for (int c=0; c<m[r].length; c++){
               m[r][c] = (int)(Math.random()*(end-start)) + start;
            }
        }
    }
    
    public static void resetMatrix(int[][] m){
        for (int r=0; r<m.length; r++){ // m.length means how many rows in the matrix m
            for (int c=0; c<m[r].length; c++){
               m[r][c] = 0; 
            }
        }
    }
    public static void copy1Dto2D(int[] a, int[][] m){
        int p =0; 
        for (int r=0; r<m.length; r++){ // m.length means how many rows in the matrix m
            for (int c=0; c<m[r].length; c++){
              if (p<a.length) m[r][c]=a[p++]; 
            }
        }
    }
    
    public static void main(String[] args){
      System.out.print("\f");
      System.out.println(Arrays.toString(a)); 
      copy1Dto2D(a, m);
      printMatrix(m);
      System.out.println();  
      
      copy1Dto2D(a, n);
      printMatrix(n);
      System.out.println();  
    }
}
