
public class RowColumnMajor
{
   static int[][] m;
   
   public static int[][] createMatrix(int N, int range){
       int[][] m = new int[N][N]; 
       for (int r=0; r<N; r++){
           for (int c=0; c<N; c++){
               m[r][c] = (int)(Math.random()*(range+1)); 
            }
        }
       return m; 
    }
   public static void printMatrix(String title, int[][] m){
       System.out.println(title); 
       for (int r=0; r<m.length; r++){
           for (int c=0; c<m[r].length; c++){
               System.out.printf("%3d ", m[r][c]); 
            }
           System.out.println(); 
        }
       System.out.println(); 
    }
   public static void columnMatrix(String title, int[][] m){
       System.out.println(title); 
       for (int c=0; c<m[0].length; c++){
          for (int r=0; r<m.length; r++){
               System.out.printf("%3d ", m[r][c]); 
            }
           System.out.println(); 
        }
       System.out.println(); 
    }    
    
   public static String serializeRSS(int[][] m){
        String s = "{"; 
        boolean first = true; 
        for (int r=0; r<m.length; r++){
           for (int c=0; c<m[r].length; c++){
               if (first) { s += m[r][c]; first=!first; }
               else s += ", " + m[r][c]; 
            }
        }
        s += "}"; 
        return s; 
    }
   public static String serializeCBS(int[][] m){
        String s = "{"; 
        boolean first = true; 
        for (int c=0; c<m[0].length; c++){
           for (int r=m.length-1; r>=0; r--){
               if (first) { s += m[r][c]; first=!first; }
               else s += ", " + m[r][c]; 
            }
        }
        s += "}"; 
        return s; 
    }
   public static void main(String[] args){
      System.out.print("\f"); 
      m = createMatrix(3, 100); 
      printMatrix("Row Major: ", m); 
      columnMatrix("Column Major", m); 
      System.out.println("RSS: "+serializeRSS(m)); 
      System.out.println("CBS: "+serializeCBS(m));
    }
}
