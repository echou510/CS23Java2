public class Motion
{
   static int[][] m;
   public static void resetMatrix(int[][] m){ 
       for (int r=0; r<m.length; r++){
           for (int c=0; c<m[0].length; c++){
               m[r][c] = 0; 
            }
        }
    }
   public static int[][] createMatrix(int N, int range){
       int[][] m = new int[N][N]; 
       for (int r=0; r<N; r++){
           for (int c=0; c<N; c++){
               m[r][c] = (int)(Math.random()*(range+1)); 
            }
        }
       return m; 
    }
   public static void printMatrix(String title, int[][] m){
       System.out.println(title); 
       for (int r=0; r<m.length; r++){
           for (int c=0; c<m[r].length; c++){
               System.out.printf("%3d ", m[r][c]); 
            }
           System.out.println(); 
        }
       System.out.println(); 
    }

    public static boolean in(int r, int c, int[][] m){
       return r>=0 && r<m.length && c>=0 && c<m[0].length; 
    }
    public static void copyMatrix(int[][] m, int[] v, int top, int left, int brow, int bcol){
       int[][] buffer = new int[brow][bcol]; 
       // backup the regional data
       for (int row = 0; row <brow; row++){
           for (int col = 0; col < bcol; col++){
               if (in(top+row, left+col, m)) buffer[row][col] = m[top+row][left+col]; 
            }  
        }
       
       int ntop = top+v[0]; 
       int nleft = left+v[1]; 
       
       for (int row = 0; row <brow; row++){
           for (int col = 0; col < bcol; col++){
               if (in(ntop+row, nleft+col, m)) m[ntop+row][nleft+col]= buffer[row][col]; 
            }  
        }
    } 
    public static void moveMatrix(int[][] m, int[] v, int top, int left, int brow, int bcol, int background){
       int[][] buffer = new int[brow][bcol]; 
       // backup the regional data
       for (int row = 0; row <brow; row++){
           for (int col = 0; col < bcol; col++){
               if (in(top+row, left+col, m)) { 
                   buffer[row][col] = m[top+row][left+col];
                   m[top+row][left+col] = background; 
                }
            }  
        }
       
       int ntop = top+v[0]; 
       int nleft = left+v[1]; 
       
       for (int row = 0; row <brow; row++){
           for (int col = 0; col < bcol; col++){
               if (in(ntop+row, nleft+col, m)) m[ntop+row][nleft+col]= buffer[row][col]; 
            }  
        }
    } 
   public static void main(String[] args){
      System.out.print("\f");
      m = new int[5][5]; 
      m[0][0] = 10; m[0][1] = 20; m[1][0] = 30; m[1][1]= 40; 
      int[] u = {2, 2}; 
      m = createMatrix(5, 100); 
      printMatrix("Intitial Matrix", m); 
      copyMatrix(m, u, 0, 0, 3, 3); 
      printMatrix("copy Matrix", m);
      
      m = createMatrix(5, 100); 
      printMatrix("Intitial Matrix", m); 
      moveMatrix(m, u, 0, 0, 3, 3, 0); 
      printMatrix("copy Matrix", m);
    }
}
