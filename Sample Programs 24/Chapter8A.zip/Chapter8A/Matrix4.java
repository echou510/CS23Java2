import java.util.*; 
public class Matrix4
{
    static int[][] m = new int[4][4]; 
   
    public static void printMatrix(int[][] m){
       for (int r=0; r<m.length; r++){ // m.length means how many rows in the matrix m
            for (int c=0; c<m[r].length; c++){
               System.out.printf("%5d", m[r][c]); 
            }
            System.out.println(); 
        }
    }
    public static void randomizeMatrix(int[][] m, int start, int end){
       for (int r=0; r<m.length; r++){ // m.length means how many rows in the matrix m
            for (int c=0; c<m[r].length; c++){
               m[r][c] = (int)(Math.random()*(end-start)) + start;
            }
        }
    }
    
    public static void resetMatrix(int[][] m){
        for (int r=0; r<m.length; r++){ // m.length means how many rows in the matrix m
            for (int c=0; c<m[r].length; c++){
               m[r][c] = 0; 
            }
        }
    }
    
    public static int sumOfMatrix(int[][] m){
        int sum = 0; 
        for (int r=0; r<m.length; r++){
            for (int c=0; c<m[r].length; c++){
               sum += m[r][c]; 
            }
        }
        return sum; 
    }
    
    public static void printColumnSum(int[][] m){
       for (int c=0; c<m[0].length; c++){
           int sum =0; 
           for (int r=0; r<m.length; r++){
              sum += m[r][c]; 
            }
           System.out.println(sum); 
        }
    }
    
    public static int findLargestRow(int[][] m){
       int max = Integer.MIN_VALUE; 
       int ridx = -1;
       
       for (int r=0; r<m.length; r++){
          int sum =0; // sum for the row
          for (int element: m[r]){
              sum += element; 
            }
          if (sum > max){
               max = sum; 
               ridx = r; 
            }
        }
       return ridx; 
    }
    
    public static int findIndexOfLargest(int[][] m){
      int max = Integer.MIN_VALUE; 
      int mr = -1; 
      int mc = -1; 
      for (int r=0; r<m.length; r++){
          for (int c=0; c<m[r].length; c++){
               if (m[r][c] > max){ // > for firstIndexOf, >= for lastIndexOf
                   max = m[r][c]; 
                   mr = r; 
                   mc = c; 
                }
            }
        }
      // max at [r][c]; 
      return mr * m[0].length + mc; 
    }
    
    public static void shuffle(int[][] m){
      for (int r=0; r<m.length; r++){
           for (int c=0; c<m[r].length; c++){
              int i = (int)(Math.random()*m.length); 
              int j = (int)(Math.random()*m[r].length);
              
              int tmp = m[r][c]; 
              m[r][c] = m[i][j]; 
              m[i][j] = tmp; 
            }
        }
    }
    
    public static void main(String[] args){
       System.out.print("\f"); 
       System.out.println("Part 1: Initial Value"); 
       randomizeMatrix(m, 0, 100);
       printMatrix(m); 
       System.out.println(); 
       System.out.println("Part 2: sum"); 
       System.out.printf("Sum of the Matrix: %d\n", sumOfMatrix(m));
       System.out.println(); 
       
       System.out.println("Part 3: Column Sums"); 
       printColumnSum(m); 
       System.out.println(); 
       
       System.out.println("Part 4: Finding Greatest Row"); 
       int maxrow = findLargestRow(m); 
       System.out.printf("Row %d has the largest sum. \n", maxrow);
       System.out.println(); 
       
       System.out.println("Part 5: Finding the index for max value"); 
       int code = findIndexOfLargest(m); 
       int mr = code / m[0].length; 
       int mc = code % m[0].length; 
       System.out.printf("The largest value %d is at row %d and col %d\n", m[mr][mc], mr, mc);
       System.out.println(); 
       
       System.out.println("Part 6:"); 
       System.out.println("Before: "); 
       printMatrix(m); 
       System.out.println();
       for (int i=0; i<20; i++) shuffle(m); 
       System.out.println("After: "); 
       printMatrix(m); 
       System.out.println();
    }
}
