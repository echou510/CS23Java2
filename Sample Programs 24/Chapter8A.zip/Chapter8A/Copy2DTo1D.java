import java.util.*; 
public class Copy2DTo1D
{
    static int[][] m = {
      {1, 2, 3, 4, 5}, 
      {6, 7, 8, 9, 10}, 
      {11, 12, 13, 14, 15}, 
      {16, 17, 18, 19, 20}, 
      {21, 22, 23, 24, 25}
    }; 
    
    static int[] a = new int[16]; 
    static int[] b = new int[30]; 
    
    public static void copy2Dto1D(int[][] m, int[] a){
        int p =0; 
        for (int r=0; r<m.length; r++){ // m.length means how many rows in the matrix m
            for (int c=0; c<m[r].length; c++){
              if (p<a.length) a[p++] = m[r][c]; 
            }
        }
    }
    
    public static void printMatrix(int[][] m){
       for (int r=0; r<m.length; r++){ // m.length means how many rows in the matrix m
            for (int c=0; c<m[r].length; c++){
               System.out.printf("%5d", m[r][c]); 
            }
            System.out.println(); 
        }
    }
    public static void randomizeMatrix(int[][] m, int start, int end){
       for (int r=0; r<m.length; r++){ // m.length means how many rows in the matrix m
            for (int c=0; c<m[r].length; c++){
               m[r][c] = (int)(Math.random()*(end-start)) + start;
            }
        }
    }
    
    public static void resetMatrix(int[][] m){
        for (int r=0; r<m.length; r++){ // m.length means how many rows in the matrix m
            for (int c=0; c<m[r].length; c++){
               m[r][c] = 0; 
            }
        }
    }
    
    public static void main(String[] args){
      System.out.print("\f");
      printMatrix(m); 
      System.out.println();
      copy2Dto1D(m, a);
      System.out.println(Arrays.toString(a)); 
      copy2Dto1D(m, b);
      System.out.println(Arrays.toString(b)); 
    }
}
