/**
 * Write a description of class TestGenericStack here.
 * 
 * @author (Eric Y. Chou) 
 * @version (01/15/2017)
 */
public class TestGenericStack
{
    public static void main(){
      GenericStack<String> stk = new GenericStack<>(); 
      stk.push("I");
      stk.push("Love");
      stk.push("Java");
      stk.push("Programming"); 
      while (stk.peek() != null){
          System.out.print(stk.pop()+" "); 
        }
      System.out.println(); 
    }
}
