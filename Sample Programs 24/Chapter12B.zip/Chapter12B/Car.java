public class Car
{
    String brand;
    int year; 
    
    Car(){ brand=""; }
    Car(String b){
       brand = b; 
    }
    Car(int y){
      year = y; 
    }
    Car(String b, int y){
       brand = b; 
       year  = y; 
    }
    
    public String toString(){
      return String.format("Car(%s, %d)", brand, year); 
    }
}
