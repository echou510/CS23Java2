public class HondaCRV extends HondaCar
{
   String owner; 
   
   HondaCRV(int year, String ow){
       super(year, "CRV"); 
       owner = ow; 
    }
}
