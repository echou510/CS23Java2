import java.util.*; 
public class Trim
{
    public static int[] a = {0, 0, 0, 1, 2, 3, 4, 0, 0, 0, 0}; 
    
    // trim to {1, 2, 3, 4}; 
    public static int[] trim(int[] a){
      if (a==null || a.length<1) return a; 
      int low=0; 
      int high=a.length-1; 
      while (low<a.length && a[low]==0){ // low >= a.length || a[low] !=0
          low++; 
        } 
      while (high>=0 && a[high]==0){ // high <0 || a[high] != 0 
          high--; 
        }
      if (low>high) return new int[0]; 
      
      high = high + 1; 
      int size = high-low; 
      int[] b = new int[size]; 
      int p=0; 
      for (int i=low; i<high; i++){
          b[p++] = a[i]; 
        }
      return b; 
    }
    
    public static int[] rtrim(int[] a){
      if (a==null || a.length<1) return a; 
      int low=0; 
      int high=a.length-1; 

      while (high>=0 && a[high]==0){ // high <0 || a[high] != 0 
          high--; 
        }
      if (low>high) return new int[0]; 
      
      high = high + 1; 
      int size = high-low; 
      int[] b = new int[size]; 
      int p=0; 
      for (int i=low; i<high; i++){
          b[p++] = a[i]; 
        }
      return b; 
    }
    public static int[] ltrim(int[] a){
      if (a==null || a.length<1) return a; 
      int low=0; 
      int high=a.length-1; 
      while (low<a.length && a[low]==0){ // low >= a.length || a[low] !=0
          low++; 
        } 

      if (low>high) return new int[0]; 
      
      high = high + 1; 
      int size = high-low; 
      int[] b = new int[size]; 
      int p=0; 
      for (int i=low; i<high; i++){
          b[p++] = a[i]; 
        }
      return b; 
    }
    
    public static void main(String[] args){
      System.out.print("\f"); 
      int[] b = trim(a); 
      System.out.println(Arrays.toString(a));
      System.out.println(Arrays.toString(b)); 
      System.out.println(); 
      a = new int[]{}; 
      b = trim(a); 
      System.out.println(Arrays.toString(a));
      System.out.println(Arrays.toString(b)); 
      System.out.println(); 
      
      a = new int[]{0}; 
      b = trim(a); 
      System.out.println(Arrays.toString(a));
      System.out.println(Arrays.toString(b)); 
      System.out.println(); 
      
      a = new int[]{0, 1, 2, 3, 4}; 
      b = trim(a); 
      System.out.println(Arrays.toString(a));
      System.out.println(Arrays.toString(b)); 
      System.out.println(); 
      
      a = new int[]{1, 2, 3, 4, 0, 0, 0, 0}; 
      b = trim(a); 
      System.out.println(Arrays.toString(a));
      System.out.println(Arrays.toString(b)); 
      System.out.println();
      
      a = new int[]{0, 0, 0, 1, 2, 3, 4, 0, 0, 0, 0}; 
      b = ltrim(a); 
      System.out.println(Arrays.toString(a));
      System.out.println(Arrays.toString(b)); 
      System.out.println();
      
      a = new int[]{0, 0, 0, 1, 2, 3, 4, 0, 0, 0, 0}; 
      b = rtrim(a); 
      System.out.println(Arrays.toString(a));
      System.out.println(Arrays.toString(b)); 
      System.out.println();
    }
}
