import java.util.*; 
public class SortingWithBinarySearchNInsertion
{  
   public static int[] a ={5, 8, 9, 1, 3, 2, 7, 4, 10, 6};
   public static int search(int[] a, int key){
       int low  = 0; 
       int high = a.length-1;
       while (low <= high){ // exit: cross over, low > high
           int mid = (low+high)/2; 
           
           if (a[mid]==key) return mid; 
           else if (a[mid]>key) high = mid - 1; // key is on the left (smaller) side 
           else low = mid + 1; // key is the on the right side (bigger) side
        }
       // exit: cross over happened, low > high, there is no more data to be searched. 
       return -1-low;  // I = -1 - low
    }  
     
   public static int[] insert(int[] a, int idx, int key){
       if (idx <0 || idx >a.length) return a; // null or a, up to you. 
       int[] b = new int[a.length+1]; 
       int p=0;  // running index; 
       for (int i=0; i<idx; i++){ // copy the left side. 
           b[p++] = a[i]; 
        }
       b[p++] = key; // put the value the the idx location
       for (int i=idx; i<a.length; i++){ // copy the right side over to b
           b[p++] = a[i]; 
        }
       return b; 
    }
    
   public static void main(String[] args){
       System.out.print("\f"); 
       int[] b = new int[0]; 
       System.out.println(Arrays.toString(a)); 
       for (int i=0; i<a.length; i++){
           int data = a[i]; 
           int I = search(b, data); 
           int low = -1 -I;
           b = insert(b, low, data); 
        }
       System.out.println(Arrays.toString(b)); 
    }
}
