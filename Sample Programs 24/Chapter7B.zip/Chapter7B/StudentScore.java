import java.io.File; 
import java.io.IOException; 
import java.util.Scanner; 
/**
 * Write a description of class StudentScore here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class StudentScore
{
    public static void printHeader(){
        System.out.println("                              Washington High School        "); 
        System.out.println("                         Semester Class Score Report Card "); 
        System.out.println("==========================================================================================="); 
    }
    
   public static char getGrade(int score){
      char grade = ' '; 
        if (score>=90 && score<=100){grade = 'A';}
        else if (score>=80 && score<=100)  {grade = 'B';}
        else if (score>=70 && score<=100)  {grade = 'C';}
        else if (score>=60 && score<=100)  {grade = 'D';}
        else if (score<60 && score>= 0){grade = 'F';}
        else { grade = 'N';}
      return grade; 
    } 
    
   public static void main(String[] args) throws IOException {
      File ifile = new File("score.txt"); 
      Scanner input = new Scanner(ifile); 
      
      int lines = 0; 
      String token = ""; 
      while (input.hasNext()){
           token = input.nextLine(); 
           lines ++; 
        }
      input.close(); 
      String[] names   = new String[lines]; 
      int[] mathScore  = new int[lines];
      int[] engScore   = new int[lines];
      char[] mathGrade = new char[lines];
      char[] engGrade  = new char[lines]; 
      
      input = new Scanner(ifile); 
      
      printHeader(); 
      int i = 0; 
      while(input.hasNext()){
           names[i]     = input.next();
           mathScore[i] = Integer.parseInt(input.next());
           engScore[i]  = Integer.parseInt(input.next());
           mathGrade[i] = getGrade(mathScore[i]);
           engGrade[i]  = getGrade(engScore[i]); 
           
           // print out one record
           System.out.printf("Name: %-12s   ", names[i]);
           System.out.printf("Math Score: %3d  ", mathScore[i]); 
           System.out.printf("Math Grade: %2c  ", mathGrade[i]); 
           System.out.printf("English Score: %3d  ", engScore[i]); 
           System.out.printf("English Grade: %2c  %n", engGrade[i]); 
           
           i++; 
        }
        
      String grades = "ABCDF"; 
      int[] gcountMath  = new int[5];
      int[] gcountEng   = new int[5];
      
      System.out.println(); 
      System.out.printf("%-30s", "Grade Distribution: ");
      System.out.printf("%20s", "Math Grade");
      System.out.printf("%20s %n", "English Grade"); 
      for (i = 0; i<grades.length(); i++){
           gcountMath[i] = 0;
           gcountEng[i]  = 0; 
           for (int j = 0; j<lines; j++){
               if (grades.charAt(i) == mathGrade[j]) gcountMath[i]++; 
               if (grades.charAt(i) == engGrade[j])  gcountEng[i]++; 
           }
           
           System.out.printf("%-30s", "Grade "+grades.charAt(i)+": "); 
           System.out.printf("%15d     ", gcountMath[i]);
           System.out.printf("%15d     %n", gcountEng[i]);
        }
        
      input.close(); 
    }
}
