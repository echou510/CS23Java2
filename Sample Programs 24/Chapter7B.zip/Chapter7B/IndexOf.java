import java.util.*; 
public class IndexOf
{
    public static int[] a = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10}; 
    public static int[] b = {4, 5, 6}; 
    public static int[] c = {4, 5, 7}; 
    public static int indexOf(int[] a, int[] b){
       return indexOf(a, b, 0); 
    }
    public static int indexOf(int[] a, int[] b, int from){
       if (from > a.length-b.length) return -1; 
       for (int i=from; i<a.length-b.length+1; i++){
           int[] d = Arrays.copyOfRange(a, i, i+b.length); 
           if (Arrays.equals(b, d)) return i; 
        }
       return -1; 
    }
    
    public static void main(String[] args){
      System.out.print("\f");
      
      System.out.printf("a.indexOf(b)=%d\n", indexOf(a, b)); 
      System.out.printf("a.indexOf(b)=%d\n", indexOf(a, b, 3)); 
      System.out.printf("a.indexOf(b)=%d\n", indexOf(a, b, 7)); 
    }
}
