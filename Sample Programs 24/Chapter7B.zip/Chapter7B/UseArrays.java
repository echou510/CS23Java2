import java.util.Arrays; 
public class UseArrays
{
   public static int[] a = {1, 2, 3}; 
   public static int[] b = {1, 2, 3}; 
   public static int[] c = {2, 4, 6}; 
   
   public static void main(String[] args){
       System.out.print("\f");
       System.out.printf("A[] = %s\n", Arrays.toString(a)); 
       System.out.printf("B[] = %s\n", Arrays.toString(b)); 
       System.out.printf("C[] = %s\n", Arrays.toString(c));
       System.out.println(); 
       System.out.printf("A[] == B[] is %b\n", Arrays.equals(a, b)); 
       System.out.printf("A[] == C[] is %b\n", Arrays.equals(a, c));
       System.out.println(); 
       System.out.printf("Index of 4 in c[] is %d\n", Arrays.binarySearch(c, 4)); 
       System.out.printf("Index of 3 in c[] is %d\n", Arrays.binarySearch(c, 3)); 
       System.out.printf("Index of 1 in c[] is %d\n", Arrays.binarySearch(c, 1)); 
       System.out.printf("Index of 5 in c[] is %d\n", Arrays.binarySearch(c, 5)); 
       
       int[] d = Arrays.copyOf(a, a.length); 
       d[1]= 20; 
       System.out.println(Arrays.toString(a)); 
       System.out.println(Arrays.toString(d)); 
    }
}
