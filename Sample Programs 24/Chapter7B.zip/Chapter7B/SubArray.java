import java.util.*; 
public class SubArray
{  public static int[] a = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10}; 
   public static int[] subArray(int[] a, int start, int end) throws Exception{ // end not included
       if (end <= start) return new int[]{}; // or null 
       if (start<0 || end >a.length) { throw new Exception("Array Index Out of Bound. ");  }
       int[] b = new int[end-start]; 
       //System.out.println(Arrays.toString(b)); 
       int p = 0;
       for (int i=start; i<end; i++){
          b[p++] = a[i]; 
        }
       return b; 
    }
    
   public static void main(String[] args) throws Exception{
       System.out.print("\f");
       System.out.println(Arrays.toString(a)); 
       int[] b = subArray(a, 3, 7); 
       System.out.println(Arrays.toString(b)); 
    }
}
