import java.util.*; 
public class Insertion
{
    public static int[] a = {2, 4, 6, 8, 10, 12, 14, 16, 18, 20}; 
    
    // non-destructive insertion
    public static int[] insert(int[] a, int idx, int key){
       if (idx <0 || idx >a.length) return a; // null or a, up to you. 
       int[] b = new int[a.length+1]; 
       int p=0;  // running index; 
       for (int i=0; i<idx; i++){ // copy the left side. 
           b[p++] = a[i]; 
        }
       b[p++] = key; // put the value the the idx location
       for (int i=idx; i<a.length; i++){ // copy the right side over to b
           b[p++] = a[i]; 
        }
       return b; 
    }
    public static void main(String[] args){
       System.out.print("\f"); 
       System.out.println(Arrays.toString(a));
       int[] b = insert(a, 1, 5);
       System.out.println(Arrays.toString(b)); 
       System.out.println(); 
       System.out.println(Arrays.toString(a));
       b = insert(a, 6, 5);
       System.out.println(Arrays.toString(b)); 
       System.out.println(); 
       System.out.println(Arrays.toString(a));
       b = insert(a, 10, 5);
       System.out.println(Arrays.toString(b)); 
       
       // destructive
       System.out.println(); 
       System.out.println(Arrays.toString(a));
       a = insert(a, 6, 5);
       System.out.println(Arrays.toString(a)); 
    }
}
