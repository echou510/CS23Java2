import java.util.Scanner; 
/**
 * Write a description of class Validation here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Validation
{
    public static void main(String[] args){
       System.out.print("\f");
       Scanner input = new Scanner(System.in);
       int x = 0; 
       boolean done=false; 
       do {
          try{
             System.out.print("Enter an Integer: "); 
             x = Integer.parseInt(input.nextLine()); 
             done = true; 
          }
          catch (Exception e){
             System.out.println("Wrong input format"); 
          }
       } while (!done); 
       System.out.println("The number entered: "+x); 
    }
}
