import java.util.Scanner; 
/**
 * Write a description of class SentinelValue here.
 * 
 * @author (Eric Y. Chou) 
 * @version (V1, 11/21/2015)
 */
public class SentinelValue
{
    	public static void main(String[] args) {
		// TODO Auto-generated method stub
	    // Create a Scanner
	    Scanner input = new Scanner(System.in);

	    // Read an initial data
	    System.out.print("Enter an int value (exits if the input is -1): ");
	    int data = input.nextInt();

	    // Keep reading data until the input is 0
	    int sum = 0;
	    while (data != -1) {
	      sum += data;

	      // Read the next data
	      System.out.print("Enter an int value (exits if the input is -1): ");
	      data = input.nextInt();
	    }

	    System.out.println("The sum is " + sum);
	   }

}
