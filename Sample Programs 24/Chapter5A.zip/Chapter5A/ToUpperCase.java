import java.io.*; 
import java.util.Scanner; 
/**
 * Write a description of class ToLowerCase here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class ToUpperCase
{
   public static void main(String[] args) throws Exception {
       File iFile = new File("usdeclaration.txt"); 
       File oFile = new File("USDECLARATION1.txt"); 
       //Scanner input = new Scanner(new File("usdeclaration.txt")); 
       Scanner input = new Scanner(iFile);
       PrintWriter out = new PrintWriter(oFile); 
       String token = ""; 
    
       while (input.hasNext()){
          token = input.nextLine();
          // To Screen
          System.out.println(token.toUpperCase()); 
          // To File
                 out.println(token.toUpperCase()); 
        }
       System.out.println();
       input.close();  
       out.close(); 
    
    }
}
