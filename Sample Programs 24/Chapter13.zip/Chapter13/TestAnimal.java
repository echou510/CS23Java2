
/**
 * Write a description of class Animal here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
abstract class Animal
{  
    public abstract String howToEat(); 
}

class Chicken extends Animal{
   @Override
   public String howToEat(){
      return "Fry it"; 
    }
}

class Duck extends Animal{
   @Override
   public String howToEat(){
      return "Roast it"; 
    }
}

public class TestAnimal{
    
   public static String eat(Animal animal){
       return animal.howToEat(); 
    }
    
   public static void main(String[] args){
      Animal animal = new Chicken(); 
      System.out.println(animal.getClass().getName()+": "+eat(animal)); 
      animal = new Duck(); 
      System.out.println(animal.getClass().getName()+": "+eat(animal));       
    }
}