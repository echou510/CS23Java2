class Chicken implements Edible{
   @Override
   public String howToEat(){
       return "Fry it (2)"; 
    }
}

class Duck implements Edible{
   @Override
   public String howToEat(){
       return "Roast it (2)"; 
    }
}

class Brocoli implements Edible{
   @Override
   public String howToEat(){
       return "Stir-Fry it (2)"; 
    }
}

public class TestStuff
{
   public static String eat(Edible stuff){
      return stuff.howToEat(); 
    }
    
   public static void main(String[] args){
      Edible stuff = new Chicken(); 
      System.out.println(stuff.getClass().getName()+": "+eat(stuff)); 
      
      stuff = new Duck(); 
      System.out.println(stuff.getClass().getName()+": "+eat(stuff)); 
    
      stuff = new Brocoli(); 
      System.out.println(stuff.getClass().getName()+": "+eat(stuff)); 
    }
}
