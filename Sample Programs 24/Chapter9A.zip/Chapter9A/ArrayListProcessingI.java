import java.util.ArrayList; 
import java.util.Arrays;
import java.util.List; 
import java.util.Iterator; 
/**
 * Write a description of class ArrayListProcessingI here.
 * 
 * @author (Eric Y. Chou) 
 * @version (12/05/2015)
 */
public class ArrayListProcessingI
{   
    public static void indexOfExample() {
      System.out.println("ArrayList indexOf() Example:......... "); 
      // create an empty array list with an initial capacity
      ArrayList<String> arrlist = new ArrayList<String>(5);

      // use add() method to add values in the list
      arrlist.add("G");
      arrlist.add("E");
      arrlist.add("F");
      arrlist.add("M");
	
      System.out.println("Size of list: " + arrlist.size());

      // let us print all the values available in list
      for (String value : arrlist) {
        System.out.println("Value = " + value);
      }  

      // retrieving the index of element "E"
      int retval=arrlist.indexOf("E");
      System.out.println("The element E is at index " + retval);
    }
    public static void containsExample() {
       System.out.println("Arraylist contains() Example:......... "); 
       // create an empty array list with an initial capacity
       ArrayList<Integer> arrlist = new ArrayList<Integer>();

       // use add() method to add elements in the list
       arrlist.add(20);
       arrlist.add(25);
       arrlist.add(10);
       arrlist.add(15);        
       
       // let us print all the elements available in list
       for (Integer number : arrlist) {
         System.out.println("Number = " + number);
       }

       // list contains element 10
       boolean retval = arrlist.contains(10); 
       if (retval == true) {
       System.out.println("element 10 is contained in the list");
       }
       else {
       System.out.println("element 10 is not contained in the list");
       }
    }
    public static void subListExample(){
     System.out.println("Arraylist subList(start, end) Example:......... "); 
     ArrayList<String> al = new ArrayList<String>();

     //Addition of elements in ArrayList
     al.add("Steve");
     al.add("Justin");
     al.add("Ajeet");
     al.add("John");
     al.add("Arnold");
     al.add("Chaitanya");

     System.out.println("Original ArrayList Content: "+al);

     //Sublist to ArrayList
     ArrayList<String> al2 = new ArrayList<String>(al.subList(1, 4));  // subList is of List type.  Need to be converted to ArrayList
     System.out.println("SubList stored in ArrayList: "+al2);

     //Sublist to List
     List<String> list = al.subList(1, 4);
     System.out.println("SubList stored in List: "+list);
    }
    public static void arraylistAddAllExample() {
       System.out.println("Arraylist addAll() Example:......... "); 
       // ArrayList1 
       ArrayList<String> al = new ArrayList<String>();
       al.add("Apple"); al.add("Orange");al.add("Grapes");al.add("Mango");
       System.out.println("ArrayList1 before addAll:"+al);

       //ArrayList2 
       ArrayList<String> al2 = new ArrayList<String>();
       al2.add("Fig"); al2.add("Pear"); al2.add("Banana"); al2.add("Guava");
       System.out.println("ArrayList2 content:"+al2);

       //Adding ArrayList2 in ArrayList1 at 3rd position(index =2)
       al.addAll(2, al2);
       System.out.println("ArrayList1 after adding ArrayList2 at 3rd Pos:\n"+al);
    } 
    
    public static void equalityDemo() { 
        System.out.println("Equality Example:......... "); 
        // create an array list 
        ArrayList<String> al = new ArrayList<String>(); 
        // add elements to the array list 
        al.add("C"); 
        al.add("A"); 
        al.add("E"); 
        al.add("B"); 
        al.add("D"); 
        al.add("F"); 
        ArrayList<String> a2 = new ArrayList<String>(Arrays.asList(new String[]{
           "C", "A", "E", "B", "D", "F"
        })); 
        System.out.println("Added List and Anonymous Array List are equal is "+al.equals(a2)); 
    } 
    
    public static void removeAllExample() { 
      System.out.println("removeAll(Collection<E> c) Example:......... "); 
      // create an empty array list   
      ArrayList<String> color_list = new ArrayList<String>();  
  
      // use add() method to add values in the list  
      color_list.add("White");  
      color_list.add("Black");  
      color_list.add("Red");  
     
      // create an empty array sample with an initial capacity   
      ArrayList<String> sample = new ArrayList<String>();  
      
      // use add() method to add values in the list   
      sample.add("Green");   
      sample.add("Red");   
      sample.add("White");  
      
      // remove all elements from second list if it exists in first list  
      sample.removeAll(color_list);  
      
      System.out.println("First List :"+ color_list);  
      System.out.println("Second List :"+ sample);  
    }
    
    public static void removeUsingIteratorExample() { 
        System.out.println("Remove Using Iterator itr.nremove() Example:......... "); 
        ArrayList<Integer> numbers = new ArrayList<Integer>(); 
        numbers.add(101); 
        numbers.add(200); 
        numbers.add(301); 
        numbers.add(400); 
        System.out.println("ArrayList Before : " + numbers); 
        Iterator<Integer> itr = numbers.iterator(); // remove all even numbers 
        while (itr.hasNext()) { 
            Integer number = itr.next(); 
            if (number % 2 == 0) { 
                // numbers.remove(number);   // Erroreous, open only when you want to see what goes wrong, and you must comment out itr.remove() when open this.
                itr.remove();
            } 
        } 
        System.out.println("ArrayList After : " + numbers); 
    }

    public static void removeExample(){
      System.out.println("removeAll(Object) Example:......... "); 
      ArrayList<Integer> numbers = new ArrayList<Integer>(); 
      numbers.add(1); 
      numbers.add(2); 
      numbers.add(3); 
      System.out.println("ArrayList contains : " + numbers); // Calling remove(index) 
      numbers.remove(1); //removing object at index 1 i.e. 2nd Object, which is 2 //Calling remove(object) 
      //numbers.remove(3); // Erroreous, open only when you want to see what goes wrong. And, you must comment out numbers.remove(new Integer(3)); when open this. 
      numbers.remove(new Integer(3)); 
      System.out.println("ArrayList after removal : " + numbers);
    }
    
    public static void main(String[] args){
       equalityDemo(); 
       containsExample();
       indexOfExample(); 
       subListExample(); 
       arraylistAddAllExample(); 
       removeExample();    
       removeUsingIteratorExample(); 
       removeAllExample(); 
    }
}
