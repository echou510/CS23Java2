import java.util.ArrayList; 
import java.util.Arrays;
import java.util.List; 
import java.util.Iterator; 
/**
 * Write a description of class ArrayListCreation here.
 * 
 * @author (Eric Y. Chou) 
 * @version (12/05/2015)
 */
public class ArrayListCreation
{
    
    public static void arraylistDemo() { 
        System.out.println("Arraylist Demo Example:......... "); 
        // create an array list 
        ArrayList<String> al = new ArrayList<String>(); 
        System.out.println("Initial size of al: " + 
        al.size()); 
        // add elements to the array list 
        al.add("C"); 
        al.add("A"); 
        al.add("E"); 
        al.add("B"); 
        al.add("D"); 
        al.add("F"); 
        al.add(1, "A2"); 
        System.out.println("Size of al after additions: " + 
        al.size()); 
        // display the array list 
        System.out.println("Contents of al: " + al); 
        // Remove elements from the array list 
        al.remove("F"); 
        al.remove(2); 
        System.out.println("Size of al after deletions: " + 
        al.size()); 
        System.out.println("Contents of al: " + al); 
    } 
    
    public static void createArrayListInLoop(){
      System.out.println("Create ArrayList Using Loop Example:......... ");  
      int count = 5;
      ArrayList<Integer> aList = new ArrayList<Integer>(); 
      for (int i=0; i<5; i++)
        { aList.add((int)(Math.random()*8));    // from console or file aList.add(input.nextInt()); 
        }
      System.out.println("Loop Creation of an ArrayList: "+aList); 
    }
    
    public static void intArrayToIntegerArray(){
        System.out.println("Convert int array to Integer array Example:......... ");  
        int[] primitiveArray = {1, 2, 3, 4, 5};
        Integer[] objectArray = new Integer[primitiveArray.length];

        for(int ctr = 0; ctr < primitiveArray.length; ctr++) {
           objectArray[ctr] = Integer.valueOf(primitiveArray[ctr]); // returns Integer value
        }
        System.out.println("int to Integer: "+Arrays.toString(primitiveArray)+" to "+Arrays.toString(objectArray)); 
    }
    
    public static void IntegerArrayTointArray(){
        System.out.println("Convert Integer array to int array Example:......... ");  
        Integer[] objectArray = {5, 4, 3, 2, 1};
        int[] primitiveArray = new int[objectArray.length];

        for(int ctr = 0; ctr < objectArray.length; ctr++) {
             primitiveArray[ctr] = objectArray[ctr].intValue(); // returns int value
        }
        System.out.println("Integer to int: "+Arrays.toString(objectArray)+" to "+Arrays.toString(primitiveArray)); 
    }
    
    public static void IntegerArrayToArrayList(){
       System.out.println("Convert Integer array to ArrayList Example:......... "); 
       Integer[] ary = {1, 2, 3, 4};  // cannot use int[] ary = {1, 2, 3, 4}; 
                                      // Integer[] ary = {new Integer(1), new Integer(2), new Integer(3), new Integer(4)};  OK
       ArrayList<Integer> aList = new ArrayList<Integer>(Arrays.asList(ary));
       ArrayList<Integer> bList = new ArrayList<Integer>(Arrays.asList(new Integer[]{1, 2, 3})); // Example using Anonymous Integer array
       String aa = aList.toString(); 
       System.out.println("aList printed by toString(): "+aa); 
       System.out.println("aList printed by default:    "+aList); 
       System.out.println("bList printed by default:    "+bList); 
    }
    
    public static void main(String[] args){
       arraylistDemo();
       createArrayListInLoop(); 
       IntegerArrayToArrayList(); 
       intArrayToIntegerArray();
       IntegerArrayTointArray();  
    }
}
