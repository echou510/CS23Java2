import java.util.ArrayList; 
public class CreationOfList
{
    public static void main(String[] args){
        ArrayList<Integer> list = new ArrayList<Integer>(); 
        list.add(3);list.add(new Integer(4)); list.add(null); list.add(5); 
        list.remove(2); 
        System.out.println(list.get(2)); 
        System.out.println(list); 
    }
}