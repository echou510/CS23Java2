import java.util.*; 
import java.io.*; 
public class Combinations
{
   static String s = "ABCDE"; 
   
   public static void main(String[] args){
       System.out.print("\f"); 
       ArrayList<String> combinations = new ArrayList<String>(); 
       for (int i=0; i<s.length()-1; i++){
          for (int j=i+1; j<s.length(); j++){
               String x = ""+s.charAt(i)+s.charAt(j); 
               combinations.add(x); 
            }
        }
       System.out.println(combinations); 
    }
}
