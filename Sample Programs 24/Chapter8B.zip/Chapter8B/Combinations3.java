import java.util.*; 
import java.io.*; 
public class Combinations3
{
   static String s = "ABCDE"; 
   
   public static void main(String[] args){
       System.out.print("\f"); 
       ArrayList<String> combinations3 = new ArrayList<String>(); 
       for (int i=0; i<s.length()-2; i++){
          for (int j=i+1; j<s.length()-1; j++){
               for (int k=j+1; k<s.length(); k++){
                 String x = ""+s.charAt(i)+s.charAt(j)+s.charAt(k); 
                 combinations3.add(x); 
               }
            }
        }
       System.out.println(combinations3); 
    }
}
