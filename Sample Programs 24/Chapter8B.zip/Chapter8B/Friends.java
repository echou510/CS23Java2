import java.util.ArrayList; 
public class Friends
{  static boolean[][] likes ={
         {false,  true,  true, false, false,  true}, 
         {false, false,  true,  true, false,  true}, 
         {true,   true, false,  true,  true, false}, 
         {true,  false,  true, false, false, false}, 
         {false, false,  true, false, false,  true}, 
         {true,  false,  true,  true, false, false} 
     }; 
   static public class Pair{
      int p1=0; 
      int p2=0;
      Pair(int a, int b){
           p1=a; 
           p2=b; 
        }
      public String toString(){ return "("+p1+", "+p2+")"; }
    }
   public static void main(String[] args){
       ArrayList<Pair> f = new ArrayList<Pair>(); 
       
       for (int i=1; i<likes.length; i++){
           for (int j=0; j<i; j++){
               if (likes[i][j] && likes[j][i]) f.add(new Pair(i, j)); 
            
            }
        }
    
       System.out.println(f); 
    }
}
