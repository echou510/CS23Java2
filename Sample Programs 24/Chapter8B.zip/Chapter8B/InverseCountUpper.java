public class InverseCountUpper
{
    static int[] a = {1,4, 3, 2, 5};
    public static int inverseCountUpper(int[] x){    
       int count = 0; 
       for (int i=0; i<x.length-1; i++){
          for (int j=i+1; j<x.length; j++){
               if (x[i]>x[j]) count++; 
            }
        }
       return count; 
    }
   
   public static void main(String[] args){
      System.out.println("inverseCountUpper(a)="+inverseCountUpper(a));  
   }
}


