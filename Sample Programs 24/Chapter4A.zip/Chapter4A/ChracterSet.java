import java.util.*; 

public class ChracterSet
{
   public static String BINARY = "01"; 
   public static String DNA = "ATCG"; 
   public static String OCTAL = "01234567";
   public static String DECIMAL = "0123456789"; 
   public static String HEXADECIMAL = "0123456789ABCDEF";
   public static String PROTEIN = "ACDEFGHIKLMNPQRSTVWY";
   public static String LOWERCASE = "abcdefghijklmnopqrstuvwxyz"; 
   public static String UPPERCASE = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"; 
   public static String BASE64 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"; 
}
