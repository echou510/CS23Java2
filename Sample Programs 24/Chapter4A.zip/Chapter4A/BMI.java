import java.util.Scanner; 
/**
 * Write a description of class BMI here.
 * 
 * @author (Eric Y. Chou) 
 * @version (V1, 11/15/2015)
 */
public class BMI
{
   public static void main(String[] args){
      Scanner input = new Scanner(System.in); 
      
      System.out.print("Enter Your Name: ");
      String name = input.nextLine(); 
      System.out.print("Enter Your Weight: "); 
      double weight = input.nextDouble();  
      System.out.print("Enter Your Height: ");
      double height = input.nextDouble(); 
      
      double bmi = weight/height/height; 
      
      String category = ""; 
      if (bmi < 16.0) {
          category = "Severe Thinness"; 
        }
      else if (bmi >= 16.0 && bmi < 17){
          category = "Moderate Thinness";
        }
      else if (bmi >= 17.0 && bmi < 18.5){
          category = "Mild Thinness"; 
        }
      else if (bmi >= 18.5 && bmi < 25){
          category = "Normal"; 
        }  
      else if (bmi >= 25.0 && bmi < 30){
          category = "Overweight"; 
        }
      else if (bmi >= 30.0 && bmi < 35){
          category = "Obese Class I"; 
        }
      else if (bmi >= 35.0 && bmi <= 40){
          category = "Obese Class II"; 
        }    
      else {
          category = "Obese Class III"; 
        }
      System.out.println("         Body Mass Index (BMI) Report ");
      System.out.println("               "+name); 
      System.out.println("============================================");
      System.out.printf("  Weight: %6.2f", weight);
      System.out.printf("  Height: %6.2f%n", height);
      System.out.printf("  BMI:    %6.2f", bmi); 
      System.out.printf("  Category: %-20s%n", category);
    }
}
