
public class TwoDObject extends PaintedInfilledShape
{
    TwoDObject(String shape, String paint, String style){
      super(shape, paint, style); 
    }
}
