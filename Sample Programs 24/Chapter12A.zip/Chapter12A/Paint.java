
public class Paint
{
    String name; 
    Paint(String n){
        name = n; 
    }
    public String getPaint(){ return name; }
    public String toString(){
       return String.format("(%s)", name); 
    }
}
