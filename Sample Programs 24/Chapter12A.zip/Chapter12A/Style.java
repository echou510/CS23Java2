
public class Style
{
    String name; 
    Style(String n){
        name = n; 
    }
    public String getStyle(){ return name; }
    public String toString(){
       return String.format("[%s]", name); 
    }
}