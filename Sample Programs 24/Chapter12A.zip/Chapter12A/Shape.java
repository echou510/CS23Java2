
public class Shape
{
    String name; 
    Shape(String n){
        name = n; 
    }
    public String getShape(){ return name; }
    public String toString(){
       return String.format("<%s>", name); 
    }
}
