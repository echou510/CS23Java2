
public class PaintedInfilled extends Style
{
    String paint; 
    PaintedInfilled(String p, String s){
       super(s); 
       paint = p; 
    }
    public String getStyle(){  return super.getStyle(); }
    public String getPaint(){  return paint; }
    public String toString(){
       return String.format("[(%s, %)]", paint, getStyle()); 
    }
}
