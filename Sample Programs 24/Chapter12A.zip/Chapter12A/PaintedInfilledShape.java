
public class PaintedInfilledShape extends PaintedInfilled
{
    String shape; 
    PaintedInfilledShape(String sp, String p, String s){
       super(p, s); 
       shape = sp; 
    }
    public String getStyle(){  return super.getStyle(); }
    public String getPaint(){  return super.getPaint(); }
    public String getShape(){  return shape; }
    public String toString(){
       return String.format("<[(%s, %s, %s)]>", shape, getPaint(), getStyle()); 
    }
}
