
public class TestTwoDObject
{
    public static void main(String[] args){
      System.out.print("\f");
      
      TwoDObject tw = new TwoDObject("diamond", "blue", "tiled"); 
      System.out.println(tw); 
    }
}
