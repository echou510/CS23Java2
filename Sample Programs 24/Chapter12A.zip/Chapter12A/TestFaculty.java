
public class TestFaculty
{
    public static void main(String[] args){
      Faculty fc = new Faculty(); 
    }
}