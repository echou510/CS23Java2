import javax.swing.JPanel; 
import java.awt.Graphics;
import javax.swing.JFrame;
/**
 * Write a description of class RecursiveRectanle here.
 * 
 * Use drawing recursive rectangles to demonstrate the principles of designing programs by divide and conquer. 
 * 
 * 
 * @author (Eric Chou) 
 * @version (08/27/2019)
 */
public class RecursiveRectangle extends JPanel{
    
    final double C13 = 1.0/3.0;  // Constant for one third
    final double C23 = 2.0/3.0;  // constant for two third
    
    public void drawRecursiveRectangle(int x1, int y1, int x2, int y2, int x3, int y3, int x4, int y4, Graphics canvas)
    {
        if(((x1-x2)*(x1-x2) + (y1-y2)*(y1-y2)) > 10)
        {
            canvas.drawLine(x1, y1, x2, y2); 
            canvas.drawLine(x2, y2, x3, y3);
            canvas.drawLine(x3, y3, x4, y4);
            canvas.drawLine(x4, y4, x1, y1);
            
            
            drawRecursiveRectangle((int)(C13*x1+C23*x2), (int)(C13*y1+C23*y2), 
                                   (int)(C13*x2+C23*x3), (int)(C13*y2+C23*y3),
                                   (int)(C13*x3+C23*x4), (int)(C13*y3+C23*y4),
                                   (int)(C13*x4+C23*x1), (int)(C13*y4+C23*y1),canvas);
        }
    }
    
    public void paint(Graphics g)
    {
        drawRecursiveRectangle(0, 0, 300, 0, 300, 300, 0, 300, g);
    }
    public static void main(String[] args) {
        JFrame frame = new JFrame("My Drawing");
        JPanel canvas = new RecursiveRectangle();
        canvas.setSize(400, 400);
        frame.add(canvas);
        frame.pack();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
}