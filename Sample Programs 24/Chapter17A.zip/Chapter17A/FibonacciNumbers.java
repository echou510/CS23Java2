import java.util.Scanner;
/**
 * Write a description of class FibonacciNumbers here.
 * 
 * The purpose of this program is to be able to calculate the numbers of the Fibonacci sequence.
 * This program allows the user to enter his or her own number and will print out the result.
 * If the number is too small or too big for the program to calculate, it will return the reason why the program
 * was unable to calculate the answer.
 * 
 * @author (Eric S. Chou Jr.) 
 * @version (1/24/16)
 */
public class FibonacciNumbers
{
    //Constructor for the class FibonacciNumbers
    FibonacciNumbers(){
    }
    
    // overloading method for fibo(0) to fibo(43); 
    public int fibo(int n){
        int result=0; 
        if(n == 0)return 0;
        else if(n == 1)return 1;
        
        if(n > 1) result = fibo(n-1) + fibo(n-2); 
        return result; 
    }
    
    // overloading method for fibo(44) to fibo(92);  
    public long fibo(long n){
        long result=0; 
        if(n == 0)return 0;
        else if(n == 1)return 1;
        
        if(n > 1) result = fibo(n-1) + fibo(n-2); 
        return result; 
    }
    
    //main function of the program
    public static void main(String[] args){

      Scanner input = new Scanner(System.in);
      boolean quit = true;
      do{
        //System.out.println("\f"); 
        quit = true; 
        System.out.print("Enter the value for the variable n: ");
        int n = Integer.parseInt(input.nextLine());
        FibonacciNumbers fibonacci = new FibonacciNumbers();
        if (n <= 46 && n>=0) {
                     System.out.println(fibonacci.fibo(n));        
                     System.out.print("Do you want to continue(y/n)? ");
                     String answer = input.nextLine();
                     if(answer.charAt(0)== 'y' || answer.charAt(0)=='Y')quit = false; 
             }
        else if (n<=92 && n>=0){   
                     long n1 = n; 
                     System.out.println(fibonacci.fibo(n1));        
                     System.out.print("Do you want to continue(y/n)? ");
                     String answer = input.nextLine();
                     if(answer.charAt(0)== 'y' || answer.charAt(0)=='Y')quit = false; 
        }
        else if (n>= 0){
          System.out.println("Fibonacci number out of int/long range"); 
          quit = true; 
        }
        else {
          System.out.println("Wrong input number, need to be positive!!!"); 
          quit = true;         
        }
      }while(!quit);
    }
}