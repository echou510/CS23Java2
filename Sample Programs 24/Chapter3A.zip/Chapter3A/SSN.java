import java.util.Scanner; 
/**
 * Write a description of class SSN here. 
 * 
 * To read in a Social Security Number in the following format. 
 * 
 * ###-##-####   # means a digit 
 * eg. 
 * 123-45-6789
 * 
 * Then, output 
 * 123456789
 * 123
 * 45
 * 6789
 * 1
 * 2
 * 3
 * 4
 * 5
 * 6
 * 7
 * 8
 * 9
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class SSN
{
   public static void main(String[] args){
       Scanner input = new Scanner(System.in); 
       
       System.out.print("Enter Social Security Number (123-45-6789 format): "); 
       String ssn = input.nextLine(); 
       
       System.out.println("All social security numbers: "+ssn.substring(0,3)+ssn.substring(4,6)+ssn.substring(7, 11));
       System.out.println("Digit 0: "+ssn.charAt(0));
       System.out.println("Digit 1: "+ssn.charAt(1));
       System.out.println("Digit 2: "+ssn.charAt(2));
       System.out.println("Digit 3: "+ssn.charAt(4));
       System.out.println("Digit 4: "+ssn.charAt(5));
       System.out.println("Digit 5: "+ssn.charAt(7));
       System.out.println("Digit 6: "+ssn.charAt(8));
       System.out.println("Digit 7: "+ssn.charAt(9));
       System.out.println("Digit 8: "+ssn.charAt(10));
    } 
}