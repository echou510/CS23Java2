import java.util.Scanner; 
/**
 * Write a description of class StudentInfo here.
 * 
 * This is a buggy verion.  The right version is in StudentInfoAnswer.java
 * 
 * @author (Eric Y. Chou) 
 * @version (V1, 11/11/2015)
 */
public class StudentInfo
{
    public static void main(String[] args){
      Scanner input  = new Scanner(System.in); 
      System.out.print("Enter name: "); 
      String name    = input.next();
      System.out.print("Enter Math Score: "); 
      int mathScore  = input.nextInt(); 
      System.out.print("Enter English Score: "); 
      int engScore   = input.nextInt(); 
      //String aa = input.nextLine(); 
      System.out.print("Enter Address: "); 
      String address = input.nextLine(); 
      System.out.print("Enter Physics Score  : "); 
      int phyScore   = input.nextInt(); 
      System.out.print("Enter Chemistry Score: "); 
      int chemScore  = input.nextInt(); 
      
      System.out.println("Name: "+name); 
      System.out.println("Math: "+mathScore); 
      System.out.println("Eng:  "+engScore); 
      System.out.println("Address: "+address); 
      System.out.println("Phy:  "+phyScore); 
      System.out.println("Chem: "+chemScore); 
    }
}
