class INT2{
  private int x=0; 
 
  public int change(){   // instance method
         x = 5;
         
         return x; 
  }
  
  public static int change(INT2 a){ // class method to change x
         a.x = 3;        // can not use x because non-static x
         return a.x; 
  }
} 