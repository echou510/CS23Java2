public class ThisReference
{
    static class Student {
        char grade='F'; 
        int  score=0; 
        
        Student(){
        }
        
        Student(int score){
          setCurvedScore(score); 
          setGrade(score);
        }
        
        public char getGrade(){
          return grade;      
        }
        
        public int getScore(){
          return score;      
        }
        
        public void setCurvedScore(int score){
          score = (int) (score * 1.05); 
          this.score = score; 
        }
        
        public void setGrade(int score){
         if (score>=90 && score<=100){grade = 'A';}
         else if (score>=80 && score<=100)  {grade = 'B';}
         else if (score>=70 && score<=100)  {grade = 'C';}
         else if (score>=60 && score<=100)  {grade = 'D';}
         else if (score<60 && score>= 0){grade = 'F';}
         else { grade = 'N';}
        }
    }
    
    public static void main(String[] args){
       int[] score = {80, 70, 60};  
       char[] grade = new char[3]; 
       Student[] s = new Student[3]; 
       
    for (int i =0; i<s.length; i++){
       s[i] = new Student(score[i]);
      
      System.out.println("Score="+s[i].getScore()+"    Grade="+s[i].getGrade()); 
    }
    }
}


