class TestINT2{
    public static void main(){
      INT2 t1 = new INT2(); 
      INT2 t2 = new INT2(); 

      System.out.println("t1.x changed by instance method:  "+t1.change()); 
      System.out.println("t2.x changed by class method: " + INT2.change(t2)); 

   }
}