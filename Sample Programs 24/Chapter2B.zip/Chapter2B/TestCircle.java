
/**
 * Write a description of class TestCircle here.
 *
 * @author (Eric Y. Chou)
 * @version (03/22/2019)
 */
public class TestCircle
{
   public static void main(String[] args){
      Circle c1= new Circle(3.0); 
      
      System.out.println("Radius: "+c1.getRadius()); 
      System.out.println("Area: "+c1.getArea()); 
      System.out.println("Perimeter: "+c1.getPerimeter()); 
    }
}
