
/**
 * Write a description of class Physics here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Physics {
    public static double LIGHT_SPEED = 3E8; 

    public static double energy(double mass){
         return mass * LIGHT_SPEED * LIGHT_SPEED; // e = m * c^2
    }

    public static void main(String[] args){
        double mass = 1.0; 
        double energyOfMass = energy(mass);
        System.out.println(energyOfMass);  
    } 
}
