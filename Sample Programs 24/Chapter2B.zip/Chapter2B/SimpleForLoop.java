
/**
 * Write a description of class SimpleForLoop here.
 *
 * @author (Eric Y. Chou)
 * @version (03/23/2019)
 */
public class SimpleForLoop
{
   public static void main(String[] args){
        for (int i=0; i<10; i++){
           System.out.println("Hello World!"); 
        }
    }
}
