import java.util.ArrayList; 
import java.io.File; 
import java.io.PrintWriter; 
import java.io.IOException; 
import java.util.Scanner; 
/**
 * Write a description of class WordCountBibleSorted here.
 * 
 * @author (Eric Y. Chou) 
 * @version (12/21/2015)
 */
public class WordCountBibleSorted
{
   public static void main(String[] args) throws IOException {
       File ifile = new File("biblecountunsorted.txt"); 
       Scanner input = new Scanner(ifile); 
       
       ArrayList<String>  bList  = new ArrayList<String>();    // bible word list
       ArrayList<Integer> bWList = new ArrayList<Integer>();   // bible word occurrence list
       
       int num = Integer.parseInt(input.next()); 
       String token = input.nextLine(); 
       int insertPoint = 0; 
       boolean found = false; 

       while (input.hasNext()){
           found = false; 
           num = Integer.parseInt(input.next()); 
           token = input.nextLine(); 
           for (int i=0; i<bWList.size() && !found; i++){
               if (num > bWList.get(i)){
                   insertPoint = i;  // insert here, when num is > bWList.get(i); 
                   bWList.add(insertPoint, new Integer(num)); 
                   bList.add(insertPoint, token); 
                   found = true; 
                }
            }
            
           if (!found) { // if smallest, append to the end of the arrayList
               bWList.add(new Integer(num)); 
               bList.add(token); 
            } 
        }
       
       input.close(); 
       
       File ofile = new File("biblecountSorted.txt"); 
       PrintWriter output = new PrintWriter(ofile); 
        
       for (int i=0; i<bWList.size(); i++){
          System.out.println(bWList.get(i)+" "+bList.get(i)); 
          output.println(bWList.get(i)+" "+bList.get(i)); 
        }
       output.close(); 
    }
}
