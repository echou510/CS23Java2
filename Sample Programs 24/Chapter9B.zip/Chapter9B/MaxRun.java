import java.util.*; 
public class MaxRun
{
   static int[] a = {1,1, 2, 3, 4, 4, 4, 5, 5, 6, 6, 6, 6, 7, 7, 8, 9, 10, 10, 10, 10, 10, 11, 12}; 
   
   public static int maxRun(int[] a){
       ArrayList<Integer> cuts = new ArrayList<Integer>(); 
       
       for (int i=1; i<a.length; i++){
          if (a[i] != a[i-1]) cuts.add(i); 
        }
       
       cuts.add(0, 0); 
       cuts.add(a.length); 
       
       int max = 1; 
       for (int i=1; i<cuts.size(); i++){
           int span = cuts.get(i) - cuts.get(i-1); 
           if (span > max) max = span; 
        }
       return max; 
    }
    
   public static void main(String[] args){
       System.out.print("\f");
       
       System.out.println(maxRun(a));
    }
}

