import java.util.*; 
public class IntervalList
{
   static int[] a = {1,1, 2, 3, 4, 4, 4, 5, 5, 6, 6, 6, 6, 7, 7, 8, 9, 10, 10, 10, 10, 10, 11, 12}; 
   static class Interval{
       int start; 
       int end; 
       Interval(int t, int e){ start = t; end = e; }
       public String toString(){ return "<"+start+","+end+">"; }
    }
    
   public static ArrayList<Interval> createInterval(int[] a){
      ArrayList<Integer> cuts = new ArrayList<Integer>(); 
       
       for (int i=1; i<a.length; i++){
          if (a[i] != a[i-1]) cuts.add(i); 
        }
       
       cuts.add(0, 0); 
       cuts.add(a.length); 
       
       ArrayList<Interval> ilist = new ArrayList<Interval>(); 
       for (int i=1; i<cuts.size(); i++){
           int s = cuts.get(i-1); 
           int e = cuts.get(i);
           ilist.add(new Interval(s, e)); 
        }
      return ilist; 
    }
    
   public static void main(String[] args){
       System.out.print("\f");
       
       System.out.println(createInterval(a)); 
    }
}
