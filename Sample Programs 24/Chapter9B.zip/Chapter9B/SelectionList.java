import java.util.ArrayList; 
import java.util.Arrays; 
/**
 * Write a description of class AvailableList here.
 * 
 * @author (Eric Y. Chou) 
 * @version (04/10/2017)
 */
public class SelectionList
{
   public static int[] SelectionSort(int[] a){
        ArrayList<Integer> alist = new ArrayList<Integer>();
        int[] b = new int[a.length];
        for (int i: a){
           alist.add(i);
        }
        int cnt = 0; 
        while (alist.size()>0){
            int max = Integer.MIN_VALUE;
            int index = 0; 
            System.out.println(cnt+"th run's avaliable list "+alist);
            for (int i=0; i<alist.size(); i++){
                if (max < alist.get(i)){
                   max = alist.get(i); 
                   index = i; 
                }
            }
            b[cnt++] = alist.remove(index);
        }
        return b; 
    }
   
   public static void printa(int[] a){
      Integer[] b= new Integer[a.length];
      for (int i=0; i<a.length;  i++){
           b[i] = new Integer(a[i]); 
        }
      System.out.println(Arrays.asList(b));
    }
   public static void main(String[] args){
      int[] a={8, 7, 9, 5, 6, 11, 9, -3, 2, 0, 17, 5}; 
      System.out.println("\fBefore Selection Sort:"); 
      printa(a); 
      a = SelectionSort(a); 
      System.out.println("After Selection Sort:"); 
      printa(a); 
    }
}
