import java.util.Arrays; 
import java.util.ArrayList; 
public class DifferenceList
{
   public static ArrayList<Integer> Difference(int[] a){
       ArrayList<Integer> b = new ArrayList<Integer>(); 
       for (int i=0; i<a.length-1; i++){
           b.add(a[i+1]-a[i]); 
        }   
       return b; 
    }
   public static void printa(int[] a){
      Integer[] b= new Integer[a.length];
      for (int i=0; i<a.length;  i++){
           b[i] = new Integer(a[i]); 
        }
      System.out.println(Arrays.asList(b));
    }
   public static void main(String[] args){
      int[] a={8, 7, 9, 5, 9, 8, 9, -3, 2, 0, 17, 5}; 
      ArrayList<Integer> dlist = new ArrayList<Integer>(); 
      System.out.println("\fBefore Occurrenc Count:"); 
      printa(a); 
      dlist = Difference(a); 
      System.out.println(" The difference list :"); 
      System.out.println(dlist); 
    }
}
