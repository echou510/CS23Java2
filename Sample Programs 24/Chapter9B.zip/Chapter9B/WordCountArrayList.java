import java.util.ArrayList; 
import java.util.Arrays;
import java.util.List; 
import java.util.Iterator; 
import java.io.File; 
import java.io.IOException; 
import java.util.Scanner; 
import java.io.PrintWriter; 
/**
 * Write a description of class WordCountArrayList here.
 * 
 * @author (Eric Y. Chou) 
 * @version (12/06/2015)
 */
public class WordCountArrayList
{
    //new for ArrayList
    static class Word {
      String name = ""; 
      int count = 0;   
    }
    
    //new for ArrayList
    static ArrayList<Word> dict = new ArrayList<Word>(); 
    
    public static void logln(PrintWriter out, String message) throws IOException {  
       System.out.println(message); 
       out.println(message); 
    }
    
    public static void log(PrintWriter out, String message) throws IOException {  
       System.out.print(message); 
       out.print(message); 
    }
    
    public static void logf(PrintWriter out, String formattedMessage) throws IOException {  
       //String formattedString = String.format(format1, message); 
       System.out.print(formattedMessage); 
       out.print(formattedMessage); 
    }
    
    public static void main(String[] args) throws IOException{
       File oFile = new File("biblecount.txt"); 
       PrintWriter out = new PrintWriter(oFile);
        //final String alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";  
        //final int WORDLIMIT = 50000; 
        final String filename = "bible.txt"; 
        File iFile = new File(filename);
        Scanner input = new Scanner(iFile);
        String text = ""; 
        
        // commented out for ArrayList
        //int[] wordCount = new int[WORDLIMIT];
        //String[] dict  = new String[WORDLIMIT];
        //int top = 0; 
        
        while (input.hasNext()){
           text += input.nextLine(); 
        }
        
        text = text.toLowerCase(); 
        
        for (int i=0; i<text.length(); i++){
           char ch = text.charAt(i); 
           
           if (  !((ch >= 'A' && ch <= 'Z') || (ch >= 'a' && ch <= 'z') || ch == ' ') )
           text = text.replace("" + ch, " ");
           //if ( ch == '\t' ) text = text.replace(""+ch, ""); 
        }
        
        String[] words = text.split(" ");
        boolean found = false; 
        
        for (int i =0; i<words.length; i++) {
          found = false; 
          words[i] = words[i].trim(); 
            
          if (!words[i].equals("")){
             //for (int j=0; j<=top && !found; j++){
             for (int j=0; j<dict.size() && !found; j++)
               //if ( words[i].equals(dict[j]) ) {  // found the word in dictionary
                 if (words[i].equals(dict.get(j).name)){
                   //wordCount[j]++; 
                   dict.get(j).count++; 
                   found = true; 
                }
             
             // did not find it in the dictionary
             if (!found){ 
               //wordCount[top]++; 
               //dict[top] = words[i];
               //top++; 
               Word a = new Word(); 
               a.name = words[i]; 
               a.count++; 
               dict.add(a); 
             }
          }
        }
        for (int i=0; i<dict.size(); i++) {
              // dual I/O printf
              //String formattedMessage = String.format("%-5d", wordCount[i]); 
              String formattedMessage = String.format("%-5d", dict.get(i).count);
              logf(out, formattedMessage); 
              
              // dual I/O for println
              //logln(out, " "+dict[i]);
              logln(out, " "+dict.get(i).name);
        }
        // dual I/O for println
        System.out.println("Total Word Count          : "+words.length); 
        // dual I/O for println
        //System.out.println("Total Different Word Count: "+top); 
        System.out.println("Total Different Word Count: "+dict.size()); 
        
        input.close(); 
        out.close(); 
    }
}
