import java.util.Scanner; 
import java.io.File; 
import java.io.IOException; 
import java.util.ArrayList; 
/**
 * Write a description of class Washington here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Washington
{
   public static ArrayList readFile(Scanner input) throws IOException {
        ArrayList aList = new ArrayList(); 
        String token;
        while (input.hasNext()){
           token = input.nextLine(); 
           aList.add(token); 
        }
        
        return aList; 
    }
    
   public static void main(String[] args) throws IOException {
       ArrayList<ArrayList> school = new ArrayList<ArrayList>(); 
       File ifile1 = new File("WHSL01.txt"); 
       Scanner input1 = new Scanner(ifile1); 
       File ifile2 = new File("WHSL02.txt"); 
       Scanner input2 = new Scanner(ifile2);    
       File ifile3 = new File("WHSL03.txt"); 
       Scanner input3 = new Scanner(ifile3); 
       File ifile4 = new File("WHSL04.txt"); 
       Scanner input4 = new Scanner(ifile4);  
       File ifile5 = new File("WHSL05.txt"); 
       Scanner input5 = new Scanner(ifile5);  
       try {
          school.add(readFile(input1));    
          school.add(readFile(input2));   
          school.add(readFile(input3));  
          school.add(readFile(input4)); 
          school.add(readFile(input5));
        }
        catch(IOException e){
           System.out.println("File I/O Problem. ");
        }
       
       int i=1; 
       for (ArrayList a: school) {
        System.out.println("Class "+(i++)+": "+a);
    }
       input1.close(); 
       input2.close();               
       input3.close();                
       input4.close(); 
       input5.close();        
    }
}
