import java.util.*; 
public class ArrayListRemoval
{
    static String[] a = {"A", "A", "A", "A", "B", "C", "D", "A", "E", "A", "A", "F", "G"}; 
    
    public static void main(String[] args){
      System.out.print("\f");
      
      ArrayList<String> alist = new ArrayList<String>(Arrays.asList(a)); 
      System.out.println("Original: "+alist); 
      
      // remove all A
      for (int i=0; i<alist.size(); i++){
           if (alist.get(i).equals("A")) alist.remove(i); 
        }
      
      System.out.println("After removal: "+alist); 
    }
}
