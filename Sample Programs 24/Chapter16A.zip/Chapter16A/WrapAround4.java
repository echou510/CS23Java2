
public class WrapAround4
{
    public static int next(int x, int COUNT){
       return ++x % COUNT; 
    }
    public static int prev(int x, int COUNT){
       return (--x+COUNT) % COUNT; 
    }
    public static void main(String[] args){
       System.out.print("\f"); 
       int COUNT = 5;
       int STEP = 4; 
       int BASE = 4; 
       int c = 0;
       for (int i=0; i<10; i++){
           System.out.print(c*STEP+BASE+"  ");
           if (i%10==9) System.out.println(); 
           c = next(c, COUNT); 
        }
       System.out.println(); 
       c=0; 
       for (int i=0; i<10; i++){
           System.out.print(c*STEP+BASE+"  ");
           if (i%10==9) System.out.println(); 
           c = prev(c, COUNT); 
        }
    }
}