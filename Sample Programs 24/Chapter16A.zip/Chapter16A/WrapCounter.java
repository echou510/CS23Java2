public class WrapCounter
{
    int state = 0; 
    int COUNT = 1; 
    WrapCounter(int COUNT, int initial_state){
      this.COUNT = COUNT; 
      state = initial_state;
    }
    public int next(){
       state = ++state % COUNT; 
       return state; 
    }
    public int prev(){
       state = (--state+COUNT) % COUNT; 
       return state; 
    }
}


