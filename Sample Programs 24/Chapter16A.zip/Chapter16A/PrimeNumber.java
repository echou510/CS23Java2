import java.util.ArrayList; 
public class PrimeNumber
{
    /**
     * Upper List for the Prime Number List. 
     */
    private int upperLimit; 
    /**
     * The prime number List under the Prime Number Upper Limit
     */
    private ArrayList<Integer>  primeList; 
    
    /**
     * Constructor PrimeNmber Class
     * 
     * @param upperLimit int upper limit for the prime numbers
     */
    PrimeNumber(int upperLimit){
       this.upperLimit = upperLimit; 
       primeList = new ArrayList<Integer>();
    }
    
    /**
     * get the upper limit
     * 
     * @return int the upperlimit for the prime number list. 
     */
    public int getUpperLimit(){
       return this.upperLimit; 
    }
    
    /**
     * set the upper limit
     * 
     * @param limit int the upperlimit for the prime number list. 
     */
    public void setUpperLimit(int limit){
        this.upperLimit = limit; 
    }    
    /** get the prime number list
     * 
     * @return ArrayList<Integer> the prime number list under the upper limit. 
     */
    public ArrayList<Integer> getPrimeList(){
       return this.primeList;
    }
    
    /**
     * isPrime: 
     * Check if a number is prime. 
     * If none of the prime number from 0 to p-1 can divide p, then p is a prime number. 
     * 
     * @param number integer number to be checked if it is prime. 
     * @return boolean true if number is prime, otherwise return false. 
     */
    public boolean isPrime(int number){
        boolean prime = true;
        if(number == 2){
            this.primeList.add(2);
            return prime;
        }
        
        for(Integer i: this.primeList){
            if(number % i == 0){prime = false;}
        }
        
        if (prime) this.primeList.add(number);
        return prime;
    }
    
    /**
     * isPrime2: (extra)
     * Check if a number is prime.
     * If none of the number from 2 to p-1 (or number/2, or Math.sqrt(numer)) can divide 
     * p is a prime number. 
     * 
     * @param number integer to be checked if it is prime. 
     * @return boolean true if number is prime, otherwise return false. 
     */
    public boolean isPrime2(int number){
        boolean prime = true;
 
        //for(int i= 2; i<number-1; i++){         // can be turned on to check for the prime number, must turn down the other two for-statement. 
        //for(int i = 2; i<= number/2; i++){      // can be turned on to check for the prime number, must turn down the other two for-statement. 
        for(int i = 2; i<= (int) Math.sqrt(number); i++){    // can be turned on to check for the prime number, must turn down the other two for-statement. 
            if(number % i == 0) {prime = false;}
        }
        
        return prime;
    }    
 
    /**
     * printPrimeOfLimit: print the prime numbers from 2 to the upper limit number assigned by user.
     * 
     * @param upperlimit the number limit that used to check the prime numbers. 
     */
    public void printPrimeOfLimit(){
        int count = 0; 
        
        for(int i = 2; i<= this.upperLimit; i++){
           if(isPrime(i)){           // can be replaced by isPrime2 to check for other algorithms. 
              System.out.printf("%3d ", i);
              if((count+1) % 20 == 0)System.out.println();  // wrapper aound for the prime number for every 20 numbers. 
              count++;
            }
        }
    }
}
