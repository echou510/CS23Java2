
public class WrapAround5
{
    public static void main(String[] args){
       System.out.print("\f"); 
       int COUNT = 5;
       int STEP = 4; 
       int BASE = 4; 
       WrapCounter wc = new WrapCounter(COUNT, 0); 
       int c=0; 
       for (int i=0; i<10; i++){
           System.out.print(c*STEP+BASE+"  ");
           if (i%10==9) System.out.println(); 
           c = wc.next(); 
        }
       System.out.println(); 
       c=0; 
       for (int i=0; i<10; i++){
           System.out.print(c*STEP+BASE+"  ");
           if (i%10==9) System.out.println(); 
           c = wc.prev(); 
        }
    }
}
