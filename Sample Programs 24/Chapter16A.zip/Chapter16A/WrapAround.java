
public class WrapAround
{
    public static int countTo6(int x){
       x += 1; 
       if (x >=6) return 0; 
       return x; 
    }
    public static void main(String[] args){
       System.out.print("\f"); 
       int c = 0;
       for (int i=0; i<20; i++){
           System.out.print(c+"  ");
           if (i%10==9) System.out.println(); 
           c = countTo6(c); 
        }
    }
}
