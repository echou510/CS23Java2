// Recursively list the contents of a directory (Unix's "ls -r" command).
import java.io.File;

/**
 * Write a description of class ListFiles here.
 * 
 * @author (Eric Y. Chou) 
 * @version (01/25/2016)
 */
public class ListDirectoryRecusive {
   public static void main(String[] args) {
      File dir = new File("C:\\Eric_Chou");  // Escape sequence needed for '\'; Try your own directory
      listRecursive(dir);
   }
   
   public static void listRecursive(File dir) {
      if (dir.isDirectory()) {
         File[] items = dir.listFiles();
         for (File item : items) {
            System.out.println(item.getAbsoluteFile());
            if (item.isDirectory()) listRecursive(item);  // Recursive call
         }
      }
   }
}