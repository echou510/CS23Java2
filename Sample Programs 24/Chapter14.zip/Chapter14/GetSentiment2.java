import java.util.*; 
import java.io.*; 
public class GetSentiment2{
    static Map<String, Double> m = new HashMap<String, Double>(); 
    
    public static double sentimentVal(String w){
       if (m.containsKey(w)) return m.get(w); 
       return 0.0; 
    }
    
    public static void main(String[] args) throws Exception{
       System.out.print("\f");
       File f = new File("cleanSentiment.csv"); 
       Scanner input = new Scanner(f);
    
       while (input.hasNext()){
           String line = input.nextLine(); 
           String[] tokens = line.split(",");
           String w = tokens[0].trim(); 
           Double d = Double.parseDouble(tokens[1].trim());
           m.put(w, d); 
        }
       input.close(); 
       
       System.out.println(sentimentVal("happily")); 
       System.out.println(sentimentVal("terrible")); 
       System.out.println(sentimentVal("cold")); 
       System.out.println(sentimentVal("zzzzz")); 
    }
}

