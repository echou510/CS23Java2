import java.util.*; 
import java.io.*; 
public class ReviewFileToWords
{
   public static void main(String[] args) throws Exception{
      System.out.print("\f");
      Scanner input = new Scanner(new File("SimpleReview.txt"));
      
      ArrayList<String> words = new ArrayList<String>(); 
      
      while(input.hasNext()){
           String word = input.next().trim();
           
           String wordx = ""; 
           
           for (char c: word.toCharArray()){
               if (Character.isLetterOrDigit(c))  wordx += c; 
               else break;
            }
           
           words.add(wordx); 
        }
    
      for (String w: words) System.out.println(w); 
      input.close(); 
    }
}
