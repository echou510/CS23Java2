
public class Word
{
    String word; 
    double sentiment; 
    
    Word(String w, double d){
       word = w; 
       sentiment = d; 
    }
    
    public String get(){ return word; }
    public double sentiment(){ return sentiment; }
    
    public String toString(){
      return String.format("%s --> %.2f", word, sentiment); 
    }
}
