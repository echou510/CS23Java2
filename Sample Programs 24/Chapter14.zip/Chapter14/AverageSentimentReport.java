import java.util.*; 
import java.io.*; 
public class AverageSentimentReport
{   
    static Map<String, Double> m = new HashMap<String, Double>();
    static double[] avg = new double[26];
    static int[] cnt = new int[26]; 
    
    public static void main(String[] args) throws Exception{
      System.out.print("\f");
      Scanner sc = new Scanner(new File("cleanSentiment.csv"));
      while (sc.hasNext()){
           String line = sc.nextLine(); 
           String[] tokens = line.split(",");
           String w = tokens[0].trim().toLowerCase(); 
           Double d = Double.parseDouble(tokens[1].trim());
           m.put(w, d); 
           char c = w.charAt(0); 
           if (Character.isLetter(c)){
               avg[c-'a'] += d; 
               cnt[c-'a']++; 
            }
        }
      sc.close();
      
      PrintWriter out = new PrintWriter(new File("report.csv"));
      for (int i=0; i<26; i++){
          char c = (char) ('a'+i); 
          System.out.printf("%c,%.4f\n", c, avg[i]/cnt[i]); 
                 out.printf("%c,%.4f\n", c, avg[i]/cnt[i]); 
        }
      out.close(); 
    }
}
