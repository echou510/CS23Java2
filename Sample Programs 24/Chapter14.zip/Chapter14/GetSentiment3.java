import java.util.*; 
import java.io.*; 
public class GetSentiment3
{
    static ArrayList<Word> words = new ArrayList<Word>(); 
    
    public static double sentimentVal(String w){
       int low=0; 
       int high = words.size()-1; 
       while (low <=high){
          int mid = (low+high)/2;
          if (w.equals(words.get(mid).get())) return words.get(mid).sentiment(); 
          else if (w.compareTo(words.get(mid).get())<0) high = mid -1; 
          else low = mid +1; 
        }
       return 0.0; 
    }
    
    public static void main(String[] args) throws Exception{
       System.out.print("\f");
       
       File f = new File("cleanSentiment.csv"); 
       Scanner input = new Scanner(f);
    
       while (input.hasNext()){
           String line = input.nextLine(); 
           String[] tokens = line.split(",");
           String w = tokens[0].trim(); 
           Double d = Double.parseDouble(tokens[1].trim());
           words.add(new Word(w, d));  
        }
        
       input.close(); 
       
       System.out.println(sentimentVal("happily")); 
       System.out.println(sentimentVal("terrible")); 
       System.out.println(sentimentVal("cold")); 
       System.out.println(sentimentVal("zzzzz")); 
    }
}

