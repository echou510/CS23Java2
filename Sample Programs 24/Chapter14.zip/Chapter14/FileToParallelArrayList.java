import java.util.*; 
import java.io.File;
public class FileToParallelArrayList
{
    public static void main(String[] args) throws Exception{
       System.out.print("\f");
       
       File f = new File("cleanSentiment.csv"); 
       Scanner input = new Scanner(f);
       
       ArrayList<String> words = new ArrayList<String>(); 
       ArrayList<Double> sentiment = new ArrayList<Double>(); 
       
       while (input.hasNext()){
           String line = input.nextLine(); 
           String[] tokens = line.split(",");
           String w = tokens[0].trim(); 
           Double d = Double.parseDouble(tokens[1].trim());
           words.add(w); 
           sentiment.add(d);  
        }
        
       for (int i=0; i<words.size(); i++){
          System.out.printf("%s --- %.2f\n", words.get(i), sentiment.get(i));
        }
       input.close(); 
    }
}

