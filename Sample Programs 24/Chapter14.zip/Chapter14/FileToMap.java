import java.util.*; 
import java.io.File;
public class FileToMap
{
    public static void main(String[] args) throws Exception{
       System.out.print("\f");
       
       File f = new File("cleanSentiment.csv"); 
       Scanner input = new Scanner(f);
       
       Map<String, Double> m = new HashMap<String, Double>();  
       
       while (input.hasNext()){
           String line = input.nextLine(); 
           String[] tokens = line.split(",");
           String w = tokens[0].trim(); 
           Double d = Double.parseDouble(tokens[1].trim());
           m.put(w, d); 
        }
        
       for (String k: m.keySet()){
          System.out.printf("%s === %.2f\n", k, m.get(k));
        }
       input.close(); 
    }
}
