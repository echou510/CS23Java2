import java.util.Scanner; 
import java.io.File;
public class FileToTokens
{
    public static void main(String[] args) throws Exception{
       System.out.print("\f");
       
       File f = new File("cleanSentiment.csv"); 
       Scanner input = new Scanner(f);
       
       while (input.hasNext()){
           String line = input.nextLine(); 
           String[] tokens = line.split(",");
           for (int i=0; i<tokens.length; i++)
              System.out.print(tokens[i]+"  ");
           System.out.println(); 
        }
        
       input.close(); 
    }
}

