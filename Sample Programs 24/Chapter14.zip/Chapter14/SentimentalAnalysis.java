import java.util.*; 
import java.io.*; 
public class SentimentalAnalysis
{
   static Map<String, Double> m = new HashMap<String, Double>(); 
    
   public static double sentimentVal(String w){
       if (m.containsKey(w)) return m.get(w); 
       return 0.0; 
    }
    
   public static void main(String[] args) throws Exception{
      System.out.print("\f");
            Scanner sc = new Scanner(new File("cleanSentiment.csv"));
      while (sc.hasNext()){
           String line = sc.nextLine(); 
           String[] tokens = line.split(",");
           String w = tokens[0].trim(); 
           Double d = Double.parseDouble(tokens[1].trim());
           m.put(w, d); 
        }
      sc.close();
      
      Scanner input = new Scanner(new File("SimpleReview.txt"));
      ArrayList<String> words = new ArrayList<String>(); 
      while(input.hasNext()){
           String word = input.next().trim();     
           String wordx = ""; 
           for (char c: word.toCharArray()){
               if (Character.isLetterOrDigit(c))  wordx += c; 
               else break;
            }
           words.add(wordx); 
        }
      input.close(); 
      
      for (String w: words) {
          w = w.toLowerCase(); 
          System.out.printf("%s --> %.2f\n", w, sentimentVal(w)); 
      }      
    }
}