import java.util.Scanner;
/**
 * Write a description of class StrongPasswordMethod here.
 * 
 * @author (Eric Y. Chou) 
 * @version (11/26/2015)
 */
public class StrongPasswordMethod
{   
   public static int showMenu(Scanner input){
        int selection = 5; 
        System.out.println("\n\n\nPassword Generation Menu");
        System.out.println("[1] Lowercase Letters");
        System.out.println("[2] Lowercase & Uppercase Letters");
        System.out.println("[3] Lowercase, Uppercase, and Numbers");
        System.out.println("[4] Lowercase, Uppercase, Numbers, and Punctuation ");
        System.out.println("[5] Quit");
        // making selection
        System.out.print("Enter Selection(1-5): ");
        selection = input.nextInt();
        return selection;    
   }
   
   public static int askPasswordLength(Scanner input){
        int length=1; 
        System.out.print("Password Length(1-100): ");
        length = input.nextInt();  
        return length; 
    }
   
   public static boolean isLongEnough(int selection, int length){
       boolean longEnough = true;
        for (int i = 2; i<=4; i++) if (selection == i && length < i) longEnough = false;
       return longEnough; 
    }
    
   public static char getPass(int i, int selection, int length, boolean longEnough, char passLower, char passUpper, char passNumber, char passPunc){
          char pass = 'a';
          int sel=0; 
             if (selection == 1){ // begin of selection 1
                   pass= passLower;  
             } // end of selection 1
             else if (selection == 2){ // begin of selection 2
                if     (longEnough && i==0)       { pass = passUpper; }    // guaranteed upper for head
                else if(longEnough && i==length-1){ pass = passLower; }    // guaranteed lower for tail
                else { // begin of characters in the middle
                      sel = (int)(Math.random()*2);
                      if      (sel == 0){ pass = passLower; } // random pick for lowercase
                      else if (sel == 1){ pass = passUpper; } // random pick for uppercase
                     }  // characters in the middle
                 //password += pass;
             } // end of selection 2
             else if (selection == 3){
                if     (longEnough && i==0)       { pass = passUpper; }    // guaranteed upper for head
                else if(longEnough && i==1)       { pass = passLower; }    // guaranteed lower for head2
                else if(longEnough && i==length-1){ pass = passNumber; }   // guaranteed numbers for tail
                else { // begin of characters in the middle
                      sel = (int)(Math.random()*3);
                      if      (sel == 0){ pass = passLower; } // random pick for lowercase
                      else if (sel == 1){ pass = passUpper; } // random pick for uppercase
                      else if (sel == 2){ pass = passNumber;} // random pick for numbers
                     }  // characters in the middle
                  //password += pass;
             }// end 3rd selection
             else if (selection == 4){
                if     (longEnough && i==0)         { pass = passUpper; }    // guaranteed upper for head
                else if(longEnough && i==1)         { pass = passLower; }    // guaranteed lower for head2
                else if(longEnough && i==length-2)  { pass = passNumber;}    // guaranteed numbers for tail
                else if(longEnough && i == length-1){ pass = passPunc;  }    // guaranteed punctuation for tail2
                else { // begin of characters in the middle
                      sel = (int)(Math.random()*4);
                      if      (sel == 0){ pass = passLower; } // random pick for lowercase
                      else if (sel == 1){ pass = passUpper; } // random pick for uppercase
                      else if (sel == 2){ pass = passNumber;} // random pick for numbers
                      else if (sel == 3){ pass = passPunc; }  // random pick for punctation
                                   }  // characters in the middle
                 //password += pass;
             } // end of if-else-if-else-if-else-if for the choice of a character from 4 categories and append it to password
          return pass; 
    } 
    
   public static void main(String[] args){
    //Scanner
    Scanner input = new Scanner(System.in);

    //variables
    int selection      = 0;    // menu selection
    int length         = 100; 
    String password    = "";   // password result
    char pass          = ' ';  // character to be appended
    char passLower     = 'a';  // temporary character buffers
    char passUpper     = 'A';
    char passNumber    = '0';
    char passPunc      = '!';
    int  sel           = 0;    // reused selector
    boolean longEnough = true; 
      
    do {   // do-while-loop: top level for Password Generation Menu
      //User Menu 
      password = "";    // reset password for next input
      selection = showMenu(input);   // show the menu and make selection 
      
      // if not menu 5: get password length and start computing password. 
      if (selection !=5) {
        // update password length
        length = askPasswordLength(input); 
        // check if the passwrod is long enough to enforce at least one symbol from every category
        longEnough = isLongEnough(selection, length); 
        
        for (int i = 0; i<length; i++){
              /* get random symbols in all regions */
              passLower  = RandomCharacter.getRandomLowerCaseLetter(); 
              passUpper  = RandomCharacter.getRandomUpperCaseLetter();
              passNumber = RandomCharacter.getRandomDigitCharacter(); 
              passPunc = RandomCharacter.getRandomPunctuationMarkAndSymbol();
              
              /*gat a pass character: determine the symbol in a region to use */
              pass=getPass(i, selection, length, longEnough, passLower, passUpper, passNumber, passPunc);                                                                               
              
              /* append to the result password */
              password += pass; 
        }  // end of for-loop for password generation  
        System.out.println("password: " + password); 
      } // end of if
    } while (selection != 5);  // end of do while loop  
   }
}
