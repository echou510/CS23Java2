public class Point{
   static int numOfPointsCreated; 
   int x, y;            // instance data field
   Point(int a, int b){ // object-builder
      x = a;  y = b; 
      numOfPointsCreated++; 
   }
   public int getX(){ return x; }
   public int getY(){ return y; }
   public void setX(int a){ x = a; }
   public void setY(int b){ y = b; }
   public static double distance(Point p1, Point p2){
       double dx = p1.x - p2.x, dy = p1.y - p2.y; 
       return Math.sqrt(dx*dx + dy*dy); 
    }
}
