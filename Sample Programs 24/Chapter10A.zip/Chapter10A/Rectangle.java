public class Rectangle{
   int width, height;   // instance data field
   Rectangle(int a, int b){ // object-builder
      width = a;  height = b; 
   }
   public int getWidth(){ return width; }
   public int getHeight(){ return height; }
   public void setWidth(int a){ width = a; }
   public void setHeight(int b){ height = b; }
   public int getArea() {return width*height; }
   public boolean equals(Object other){ 
      Rectangle that = (Rectangle) other; 
      return this.width == that.width && this.height == that.height; 
   }
   public String toString(){
      return String.format("Rect[%d, %d]", width, height); 
   }
}
