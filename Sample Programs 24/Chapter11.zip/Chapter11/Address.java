
/**
 * Write a description of class Address here.
 * 
 * @author (Eric Y. Chou) 
 * @version (01/10/2016)
 */
public class Address
{
    
}
