
/**
 * Write a description of class BMI here.
 * 
 * @author (Eric Y. Chou) 
 * @version (V1 01/08/2016)
 */
public class BMI {
  private String name;
  private int age;
  private double weight; // in pounds
  private double height; // in inches
  public static final double KILOGRAMS_PER_POUND = 0.45359237; 
  public static final double METERS_PER_INCH = 0.0254;  
  
  public BMI(String name, int age, double weight, double height) {
    this.name = name;
    this.age = age;
    this.weight = weight;
    this.height = height;
  }
  
  public BMI(String name, double weight, double height) {
    this(name, 20, weight, height);
  }
  
  public double getBMI() {
    double bmi = weight * KILOGRAMS_PER_POUND / 
      ((height * METERS_PER_INCH) * (height * METERS_PER_INCH));
    return Math.round(bmi * 100) / 100.0;
  }
  
  public String getStatus() {
    double bmi = getBMI();
    if (bmi < 18.5)
      return "Underweight";
    else if (bmi < 25)
      return "Normal";
    else if (bmi < 30)
      return "Overweight";
    else
      return "Obese";
  }
  
  public String getName() {
    return name;
  }
  
  public int getAge() {
    return age;
  }
  
  public double getWeight() {
    return weight;
  }
  
  public double getHeight() {
    return height;
  }
  
  public void setName(String name){
       this.name = name; 
    }
  
  public void setAge(int age){
       this.age = age; 
    }
    
  public void setWeight(double weight){
       this.weight = weight; 
    }
    
  public void setHeight(double height){
       this.height = height; 
    }  
    
  public boolean equals(BMI b){
      return (this.getBMI() == b.getBMI()); 
    }
  
  public double compareTo(BMI b){
      return this.getBMI() - b.getBMI(); 
    }
    
  public String toString(){
       return "Name: "+name+" Age: "+String.format("%3d ", age)+" BMI: "+String.format("%6.2f ", getBMI())+" Status: "+getStatus();
    }
}
