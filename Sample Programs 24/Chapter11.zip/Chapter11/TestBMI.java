
/**
 * Write a description of class TestBMI here.
 * 
 * @author (Eric Y. Chou) 
 * @version (V1, 01/08/2016)
 */
public class TestBMI {
  public static void main(String[] args) {
    BMI bmi1 = new BMI("John Doe", 18, 145, 70);
    System.out.println("The BMI for " + bmi1.getName() + " is "
      + bmi1.getBMI() + " " + bmi1.getStatus());
    
    BMI bmi2 = new BMI("Peter King", 215, 70);
    System.out.println("The BMI for " + bmi2.getName() + " is "
      + bmi2.getBMI() + " " + bmi2.getStatus());
      
    System.out.println("Equality of BMI between "+bmi1.getName()+" and "+bmi2.getName()+" is "+bmi1.equals(bmi2));
    System.out.println("Comaprison of BMI from "+bmi1.getName()+" to "+bmi2.getName()+" is "+bmi1.compareTo(bmi2));
    System.out.println(bmi1.toString());
    System.out.println(bmi2.toString()); 
  }
}
