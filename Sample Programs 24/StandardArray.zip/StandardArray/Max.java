package StandardArray;

import java.util.ArrayList; 
import java.util.List; 
import java.util.Arrays;
/**
 * AP FRQ Design Patterns
 * 1. max of array               (finding min value is in the comments) 
 * 2. max of 2D array
 * 3. max of arraylist
 */
public class Max
{
  static int[] a = {5, 7, 3, 4, 9, 8, 0, 1, 2, 6};
  static Integer[] b = {5, 7, 3, 4, 9, 8, 0, 1, 2, 6};// Integer in wrapper type
  static int[][] m = {{5,7,3}, {4, 9, 8}, {1, 2, 6}};
  static List<Integer> blist = new ArrayList<Integer>(); 
  
  public static int maxArray(int[] t){
       int max = Integer.MIN_VALUE;          // int min = Integer.MAX_VALUE; 
       for (int i=0; i<t.length; i++){
           if (t[i]>max) max = t[i];         // if (t[i]<min) min = t[i];
        }
       return max;                           // return min
    }
     
  public static int max2DArray(int[][] t){
       int max=Integer.MIN_VALUE;           // int min = Integer.MAX_VALUE;
       for (int i=0; i<t.length; i++){
         for (int j=0; j<t[0].length; j++){
            if (t[i][j]>max) max = t[i][j];  // if (t[i][j]<min) min = t[i][j];
          }
        }
       return max;                           // return min
    } 
  
  public static int maxArrayList(List<Integer> al){
      int max = Integer.MIN_VALUE;         // int min = Integer.MAX_VALUE; 
        for (Integer i: al){
            if (i>max) max = i;            // if (i<min) min = i
        }
      return max;                           // return min
    }  
    
  public static void main(String[] args){
       blist = Arrays.asList(b);     // convert Integer[] array to List
       System.out.println("1D Max="+maxArray(a));
       System.out.println("2D Max="+max2DArray(m));
       System.out.println("ArrayList Max="+maxArrayList(blist));
    }
}
