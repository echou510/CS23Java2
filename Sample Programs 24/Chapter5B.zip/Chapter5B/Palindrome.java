import java.util.Scanner; 
/**
 * Write a description of class Palindrome here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Palindrome
{
    public static boolean isPalindrome(String s){
      for (int i=0; i<s.length()/2; i++){
          if (s.charAt(i)!=s.charAt(s.length()-1-i)) return false; 
        }
      return true; 
    }
    public static void main(String[] args){
       System.out.print("\f");
       System.out.print("Enter a String: ");
       Scanner input = new Scanner(System.in); 
       String str = input.nextLine(); 
       boolean isP = isPalindrome(str); 
       if (isP) System.out.println(str+" is a Palindrome string.");
       else     System.out.println(str+" is not a Palindrome string."); 
    }
}
