
/**
 * Write a description of class PrimeNumber here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class PrimeNumber
{
    static public boolean isPrime(int n){
      for (int i=2; i<Math.sqrt(n); i++){
           if (n%i==0) return false; 
        }
      return true; 
    }
    
    public static void main(String[] args){
        int num=2; 
        int count =0; 
        while (count <50){
          if (isPrime(num)) {
                if (count %10 ==9) System.out.printf("%5d%n", num);
                else System.out.printf("%5d ",num); 
                count ++; 
            }
          num++; 
        }
    
    }
}
