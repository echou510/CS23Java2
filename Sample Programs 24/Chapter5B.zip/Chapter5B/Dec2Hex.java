import java.util.Scanner; 
/**
 * Write a description of class Dec2Hex here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Dec2Hex
{
    public static String dec2Hex(int d){
      if (d==0) return "0"; 
      String sum = ""; 
      while (d>0){
          int x = d % 16; 
          sum = Integer.toString(x, 16)+sum; 
          d /= 16; 
        }
      return sum; 
    }
    public static void main(String[] args){
      System.out.print("\f");
      
      System.out.print("Enter a Decimal Integer: ");
      Scanner input = new Scanner(System.in); 
      int dec = input.nextInt(); 
      String hex = dec2Hex(dec); 
      System.out.printf("%d's hexadecimal representation is %s%n", dec, hex); 
    }
}
