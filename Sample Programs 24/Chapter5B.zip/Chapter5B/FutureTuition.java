import java.util.Scanner; 
/**
 * Write a description of class FutureTuition here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class FutureTuition
{
    public static void main(String[] args){
       double tuition = 10000;   
       int year = 0;  // Year 0
       System.out.print("\f");
       System.out.print("Rate %: ");
       Scanner input = new Scanner(System.in); 
       double rate = input.nextDouble()*0.01; 
       do {
           tuition *= 1+rate; 
           year++; 
           System.out.println("Year "+year+": tuition="+tuition); 
        } while(tuition<20000); 
       System.out.println(year+" years to double.");  
    }
}
