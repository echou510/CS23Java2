
/**
 * Write a description of class MutlplicationTable here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class MutlplicationTable
{
   public static void main(String[] args){
       // column index line
       System.out.printf("%8s |", " ");
       for (int i=1; i<=9; i++){
         System.out.printf(" %3d ", i); 
        }
       System.out.println(); 
       
       // header divider
       System.out.print("---------+"); 
       for (int i=1; i<=9; i++){
           System.out.printf("-----"); 
        }
       System.out.println(); 
       
       // mutliplication table
       for (int i=1; i<=9; i++){
          // row index
          System.out.printf("%8d |", i); 
          // multiplication cell
          for (int j=1; j<=9; j++){
              System.out.printf(" %3d ", i*j); 
            }
          System.out.println(); 
        }
    }
}
