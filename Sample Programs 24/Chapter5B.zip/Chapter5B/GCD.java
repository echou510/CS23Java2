
/**
 * Write a description of class GCD here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class GCD
{
  public static int GCD(int m, int n){
       while (n!=0){  // termination condition
           int r = m % n;  // recursive relationship
           m = n; 
           n = r; 
        }
       return m; 
    }
  public static void main(String[] args){
        System.out.print("\f");
        System.out.println(GCD(24, 36)); 
        System.out.println(GCD(4, 17)); 
    }
}
