public class ElevensGUIRunner
{
  public static void main(String[] args){
       ElevensGUI.main(new String[]{});  
    }
}
