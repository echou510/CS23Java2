
/**
 * Write a description of class Square here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Square
{
    public static void main(String[] args){
       for (int i=1; i<=5; i++)
         System.out.println((i*i)); 
    }
}
