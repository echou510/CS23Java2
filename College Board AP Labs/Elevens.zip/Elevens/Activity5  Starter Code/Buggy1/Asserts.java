
/**
 * Write a description of class Asserts here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Asserts
{
    public static int square(int x){
       int[] y = {0, 1, 4, 9, 16, 24}; 
       return y[x]; 
    }
    
    public static int sq(int x){
       return x*x; 
    }
    
    public static void main(String[] args){
       System.out.print("\f"); 
       assert(sq(0)==0) : "sq(0) is wrong. "; 
       assert(sq(1)==1) : "sq(1) is wrong. "; 
       assert(sq(2)==4) : "sq(2) is wrong. "; 
       assert(sq(3)==9) : "sq(3) is wrong. "; 
       assert(sq(4)==16) : "sq(4) is wrong. "; 
       assert(sq(5)==25) : "sq(5) is wrong. "; 
       
       System.out.println("No error!"); 
       assert(square(0)==0) : "square(0) is wrong. "; 
       assert(square(1)==1) : "square(1) is wrong. "; 
       assert(square(2)==4) : "square(2) is wrong. "; 
       assert(square(3)==9) : "square(3) is wrong. "; 
       assert(square(4)==16) : "square(4) is wrong. "; 
       assert(square(5)==25) : "square(5) is wrong. "; 
       
       System.out.println("No error!"); 
    }
}
