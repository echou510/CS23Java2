public class Exceptions
{
    public static int square(int x){
       int[] y = {0, 1, 4, 9, 16, 24}; 
       return y[x]; 
    }
    
    public static int sq(int x){
       return x*x; 
    }
    
    public static void checkSQ() throws Exception {
      if (square(0) !=0) throw new Exception("saure(0) is wrong.");  
      if (square(1) !=1) throw new Exception("saure(1) is wrong.");   
      if (square(2) !=4) throw new Exception("saure(2) is wrong.");          
      if (square(3) !=9) throw new Exception("saure(3) is wrong.");   
      if (square(4) !=16) throw new Exception("saure(4) is wrong.");   
      if (square(5) !=25) throw new Exception("saure(5) is wrong.");   
    }
    public static void main(String[] args) throws Exception {
       System.out.print("\f"); 
       try{
         checkSQ();
        } 
       catch (Exception e){
          System.out.println(e); 
        }
    }
}
