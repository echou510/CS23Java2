
/**
 * Write a description of class ThisReference here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class ThisReference
{
   private int x; 
   private int[] y = new int[2]; 
   
   ThisReference(){
       x = 5; 
       y[0] = 1; 
       y[1] = 2; 
    }
    
   public int getX(){
       return x; 
    }
    
   public int[] getY(){
       return y; 
    }
    
   public void printOut(){
      Integer a = this.hashCode(); 
      System.out.println("Pointer: "+this+" hashCode: "+this.hashCode()+" hasCode() in HexaDecimal: "
      +Integer.toHexString(a)+" toString(): "+this.toString()); 
    }
    
  public static void main(){
       ThisReference thisOne = new ThisReference(); 
       ThisReference thisTwo = new ThisReference(); 
       System.out.println("Object one: "); 
       thisOne.printOut(); 
       System.out.println("Instance Array: "+thisOne.getY()); 
       System.out.println("Object Two: ");
       thisTwo.printOut(); 
       System.out.println("Instance Array: "+thisTwo.getY());
    }
}
