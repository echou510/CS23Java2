import java.lang.StringBuilder; 
/**
 * Write a description of class StringBuilder here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class StringBuilderExamples
{
   public static void stringExample1(){
     System.out.println("String Example1(Converting, Replacing, and Splitting Strings ): ");
     System.out.println("Welcome".toLowerCase());
     System.out.println("Welcome".toUpperCase()); 
     System.out.println("  Welcome  ".trim()); 
     System.out.println("Welcome".replace('e', 'A')); 
     System.out.println("Welcome".replaceFirst("e", "AB")); 
     System.out.println("Welcome".replace("e", "AB")); 
     System.out.println("Welcome".replace("el", "AB"));  
     String[] tokens = "Java#HTML#Perl".split("#", 0);
     for (int i = 0; i < tokens.length; i++)  System.out.print(tokens[i] + " ");
     System.out.println(); 
    }
    
   public static void stringExample2(){ 
     System.out.println("String Example2(Searching in String, indexOf): ");
     System.out.println("Welcome to Java".indexOf('W')); 
     System.out.println("Welcome to Java".indexOf('x'));  
     System.out.println("Welcome to Java".indexOf('o', 5));  
     System.out.println("Welcome to Java".indexOf("come"));  
     System.out.println("Welcome to Java".indexOf("Java", 5));  
     System.out.println("Welcome to Java".indexOf("java", 5)); 
     System.out.println("Welcome to Java".lastIndexOf('a'));  
    }  
       
   public static void stringBuilder1(){
     System.out.println("StringBuilder Example1: "); 
     StringBuilder stringBuilder = new StringBuilder("Welcome to "); 
     stringBuilder.append("Java");
     System.out.println(stringBuilder.toString()); 
     //stringBuilder = new StringBuilder("Welcome to "); 
     stringBuilder.insert(11, "HTML and ");
     System.out.println(stringBuilder.toString());  
     stringBuilder = new StringBuilder("Welcome to Java"); 
     stringBuilder.delete(8, 11); 
     System.out.println(stringBuilder.toString());  
     stringBuilder = new StringBuilder("Welcome to Java"); 
     stringBuilder.deleteCharAt(8); 
     System.out.println(stringBuilder.toString());   
     stringBuilder = new StringBuilder("Welcome to Java"); 
     stringBuilder.reverse(); 
     System.out.println(stringBuilder.toString());    
     stringBuilder = new StringBuilder("Welcome to Java"); 
     stringBuilder.replace(11, 15, "HTML");  
     System.out.println(stringBuilder.toString());    
     stringBuilder = new StringBuilder("Welcome to Java"); 
     stringBuilder.setCharAt(0, 'w'); 
     System.out.println(stringBuilder.toString());
    } 
    
   public static void stringRegularExpression(){
      System.out.println("String Regular Expression(Matching *): "); 
      System.out.println("\"Java\".matches(\"Java\")   :"+"Java".matches("Java"));
      System.out.println("\"Java\".equals(\"Java\")   :"+"Java".equals("Java")); 

      System.out.println("\"Java is fun\".matches(\"Java.*\")   :"+"Java is fun".matches("Java.*"));
      System.out.println("\"Java is cool\".matches(\"Java.*\")   :"+"Java is cool".matches("Java.*"));
      System.out.println("String Regular Expression(replaceAll): "); 
      String s = "a+b$#c".replaceAll("[$+#]", "NNN");
      System.out.println("\"a+b$#c\".replaceAll(\"[$+#]\", \"NNN\")   :"+s);
      
      System.out.println("String Regular Expression(split)   : "); 
      String[] tokens = "Java,C?C#,C++".split("[.,:;?]");
      System.out.println("\"Java,C?C#,C++\".split(\"[.,:;?]\")"); 
      for (int i = 0; i < tokens.length; i++) System.out.println(tokens[i]);

      String s1   = "Java Java Java".replaceAll("v\\w", "wi") ;
      System.out.print("\"Java Java Java\".replaceAll(\"v\\w\", \"wi\")   :"); 
      System.out.println(s1); 
      
      String s2   = "Java Java Java".replaceFirst("v\\w", "wi"); 
      System.out.print("\"Java Java Java\".replaceFirst(\"v\\w\", \"wi\")   :"); 
      System.out.println(s2); 
     
      String[] s3 = "Java1HTML2Perl".split("\\d");
      System.out.print("\"Java1HTML2Perl\".split(\"\\d\")   :"); 
      System.out.println(s3[0]+" "+s3[1]+" "+s3[2]); 
    }
    
   public static void main(String[] args){
       stringExample1();
       stringExample2(); 
       stringBuilder1(); 
       stringRegularExpression(); 
    }
}
