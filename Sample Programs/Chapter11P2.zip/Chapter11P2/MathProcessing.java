
/**
 * Write a description of class MathProcessing here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class MathProcessing
{
   public static void main(String[] args){
    
    
    }
}
