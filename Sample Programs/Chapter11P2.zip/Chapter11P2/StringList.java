import java.util.ArrayList; 
/**
 * Write a description of class WordList here.
 * 
 * @author (Eric Y. Chou) 
 * @version (04/10/2017)
 */
public class StringList
{
    private ArrayList mList; 
    StringList(ArrayList wlist){
      mList = wlist; 
    }
    public int numWordsOfLength(int len){
       ArrayList<String> list = (ArrayList<String>) mList; 
       int count = 0; 
       for (String s: list){
           if (s.length() == len) count++; 
        }
       return count; 
    }
    
    public void removeWordsOfLength(int len){
       ArrayList<String> list = (ArrayList<String>) mList; 
       int count = 0; 
       for (int i=list.size()-1; i>=0;  i--){
           if (list.get(i).length() == len) list.remove(i);  
        }
    }
    public ArrayList getMList(){
      return mList; 
    }
    public static void main(String[] args){
        ArrayList<String> w = new ArrayList<String>(); 
        w.add("lemon"); w.add("date"); w.add("mango"); w.add("kiwi"); w.add("apple"); w.add("watermelon");  
        StringList fruits = new StringList(w); 
        System.out.println("\fPart (a): "); 
        System.out.println("Call fruits.numWordsOfLength(5)="+fruits.numWordsOfLength(5));
        System.out.println("Call fruits.numWordsOfLength(4)="+fruits.numWordsOfLength(4));
        System.out.println("Call fruits.numWordsOfLength(3)="+fruits.numWordsOfLength(3));
        System.out.println("Part (b): "); 
        fruits.removeWordsOfLength(5);
        System.out.println("Call fruits.removeWordsOfLength(5)="+fruits.getMList());
        fruits.removeWordsOfLength(4);
        System.out.println("Call fruits.removeWordsOfLength(4)="+fruits.getMList());
        fruits.removeWordsOfLength(3);
        System.out.println("Call fruits.removeWordsOfLength(3)="+fruits.getMList());
    }
}
