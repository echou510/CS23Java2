
/**
 * Write a description of class Catapult here.
 * 
 * each Catapult object represent a certain projectile based on certain velocity, angle and gravity
 * data. 
 * 
 * This class serve as the definition of the Catapults. 
 * 
 * @author (Eric Y. Chou) 
 * @version (06/06/2016)
 */
public class Catapult
{
    /**
     * speed of object
     */
    double velocity = 0.0;
    /**
     * angle of object
     */
    double angle = 0.0;
    /**
     * gravity of object
     */
    double gravity = 9.8;
    /**
     * distance of object
     */
    double distance = 0.0;
    /**
     * meters to feet constant
     */
    final static double METERSTOFEET = 3.28;
    /**
     * Function Catapult the constructor of the program
     * 
     * @param velocity the speed of the projectile
     * @param angle    the angle at which the projectile was shot from
     * @param gravity  the earth's gravity 
     * @return none
     */
    Catapult(double velocity, double angle, double gravity)
    {   this.velocity = velocity;
        this.angle = angle;
        this.gravity = gravity;
        
    }
    
    /**
     * Function findDistance finds the distance traveled by the projectile
     * 
     * @return distance the distance traveled by the projectile
     */
    public double findDistance(){
            distance = (Math.pow(velocity, 2) * Math.sin(2*Math.toRadians(angle))/gravity);
            return distance;
    }
    
    public static double toFeet(double meters){
        double feet = meters*METERSTOFEET;
        return feet;
    }
}
