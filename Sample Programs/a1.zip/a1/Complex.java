package a1;

import java.text.DecimalFormat; 

/**
 * Write a description of class Complex here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Complex
{
  private double r;  // real part
  private double i;  // imaginary part
  
  public Complex(){ this.r = 0; this.i = 0; }                         // Constructor for a Complex 0
  public Complex(double rr) {this.r = rr; this.i = 0.0; }             // Constructor for a real number in Complex type
  public Complex(double rr, double ii){ this.r = rr; this.i = ii; }   // Constructor for a complex number
    
  public double getR(){ return this.r; }
  public double getI(){ return this.i; }
  
  public void setR(double rr){ this.r = rr; }
  public void setI(double ii){ this.i = ii; }
  
  public void setComplex(double rr, double ii){ this.r = rr;  this.i = ii; }
  
  public String toString(){   // return a string body, not the pointer
      return "<"+this.r + "+"+ this.i + "i"+">"; 
    }
  public String toString2(){   // return a string body, not the pointer
      return "<"+String.format("%4.2f", this.r) + "+"+ String.format("%4.2f", this.i) + "i"+">"; 
    }
  public String toString4(){   // return a string body, not the pointer
      return "<"+String.format("%6.4f", this.r) + "+"+ String.format("%6.4f", this.i) + "i"+">"; 
    }
  
  public boolean equals(Complex cc){
       boolean result = false; 
       if (this.r == cc.r && this.i == cc.i) result = true; 
       return result;
    }
    
  public boolean equals4(Complex cc){
        DecimalFormat df = new DecimalFormat("#.####");  
        boolean result = false; 
        if (df.format(this.r).equals(df.format(cc.r)) && df.format(this.i).equals(df.format(cc.i))) result=true; 
        return result; 
    }  
    
  public boolean equals8(Complex cc){
        DecimalFormat df = new DecimalFormat("#.########");  
        boolean result = false; 
        if (df.format(this.r).equals(df.format(cc.r)) && df.format(this.i).equals(df.format(cc.i))) result=true; 
        return result; 
    }
    
  public boolean notEquals(Complex cc){
       boolean result = false; 
       if (this.r != cc.r || this.i != cc.i) result = true; 
       return result;
    } 
    
  public int getQuadrant(){
       int quad = 1; 
       
       if (this.r >= 0 && this.i >= 0) quad = 1; 
       if (this.r <  0 && this.i >= 0) quad = 2; 
       if (this.r <  0 && this.i <  0) quad = 3; 
       if (this.r >= 0 && this.i <  0) quad = 4; 
       return quad; 
    }
    
  public double getTheta(){
      double theta=0.0; 
      double x = Math.abs(this.r); 
      double y = Math.abs(this.i); 
      double r = Math.sqrt(x*x+y*y);
      if (r != 0) {
        if (this.getQuadrant() == 1) theta = Math.acos(x/r); 
        if (this.getQuadrant() == 2) theta = Math.PI - Math.acos(x/r); 
        if (this.getQuadrant() == 3) theta = Math.PI + Math.acos(x/r); 
        if (this.getQuadrant() == 4) theta = 2*Math.PI - Math.acos(x/r);  
      }
      return theta; 
    }
    
  public double getThetaDegree(){
      double theta=0.0; 
      double x = Math.abs(this.r); 
      double y = Math.abs(this.i); 
      double r = Math.sqrt(x*x+y*y);
      if (r != 0) {
        if (this.getQuadrant() == 1) theta = Math.acos(x/r); 
        if (this.getQuadrant() == 2) theta = Math.PI - Math.acos(x/r); 
        if (this.getQuadrant() == 3) theta = Math.PI + Math.acos(x/r); 
        if (this.getQuadrant() == 4) theta = 2*Math.PI - Math.acos(x/r);  
      }
      return theta*180/Math.PI; 
    } 
}
