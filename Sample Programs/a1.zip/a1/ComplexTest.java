package a1;

//import java.io.File; 
//import java.io.PrintWriter; 
// 
import java.io.IOException; 
/**
 * Write a description of class ComplexTest here.
 * 
 * @author (Eric Y. Chou) 
 * @version (V1, 10/22/2015)
 */
public class ComplexTest
{ 
    public static void main(String[] args) throws IOException {
       //File oFile = new File("ComplexTest.txt");
       //PrintWriter out = new PrintWriter(oFile); 
       Complex c1 = new Complex(1, 0); 
       Complex c2 = new Complex(0, 1); 
       
       System.out.println("Reading Complex: "); 
       System.out.println("c1 Real:      " + c1.getR());
       System.out.println("c1 Imaginary: " + c1.getI()); 
       System.out.println("c2 Real:      " + c2.getR());
       System.out.println("c2 Imaginary: " + c2.getI()); 
       System.out.println();
       System.out.println("Before Setting: ");
       System.out.println("c1: " + c1.toString());
       System.out.println("c2: " + c2.toString()); 
       c1.setComplex(2, 0); 
       c2.setComplex(0, 2); 
       System.out.println("After Setting: ");
       System.out.println("c1: " + c1.toString());
       System.out.println("c2: " + c2.toString());
       System.out.println();

       System.out.println("Complex Equality Check:"); 
       Complex c13 = new Complex(1.123456789, 1.123456789); 
       Complex c14 = new Complex(1.124567891, 1.124567891); 
       Complex c15 = new Complex(1.123456789, 1.124567891); 
       Complex c16 = new Complex(1.123456891, 1.123456789); 
       Complex c17 = new Complex(1.123456789, 1.123456891); 
       Complex c18 = new Complex(1.123456789, 1.123456781); 
       System.out.println("Is "+c13.toString()+" = "+c13.toString()+"? "+c13.equals(c13)); 
       System.out.println("Is "+c13.toString()+" = "+c13.toString()+"? "+c13.equals(c13)); 
       System.out.println("Is "+c13.toString()+" = "+c13.toString()+"? "+c13.equals(c13)); 
       System.out.println("Is "+c13.toString()+" = "+c14.toString()+"? "+c13.equals(c14)); 
       System.out.println("Is "+c13.toString()+" = "+c14.toString()+"? "+c13.equals4(c14)); 
       System.out.println("Is "+c13.toString()+" = "+c14.toString()+"? "+c13.equals8(c14)); 
       System.out.println("Is "+c13.toString()+" = "+c15.toString()+"? "+c13.equals(c15)); 
       System.out.println("Is "+c13.toString()+" = "+c15.toString()+"? "+c13.equals4(c15)); 
       System.out.println("Is "+c13.toString()+" = "+c15.toString()+"? "+c13.equals8(c15));        
       System.out.println("Is "+c13.toString()+" = "+c16.toString()+"? "+c13.equals(c16)); 
       System.out.println("Is "+c13.toString()+" = "+c16.toString()+"? "+c13.equals4(c16)); 
       System.out.println("Is "+c13.toString()+" = "+c16.toString()+"? "+c13.equals8(c16)); 
       System.out.println("Is "+c13.toString()+" = "+c17.toString()+"? "+c13.equals(c17)); 
       System.out.println("Is "+c13.toString()+" = "+c17.toString()+"? "+c13.equals4(c17)); 
       System.out.println("Is "+c13.toString()+" = "+c17.toString()+"? "+c13.equals8(c17)); 
       System.out.println("Is "+c13.toString()+" = "+c18.toString()+"? "+c13.equals(c18)); 
       System.out.println("Is "+c13.toString()+" = "+c18.toString()+"? "+c13.equals4(c18)); 
       System.out.println("Is "+c13.toString()+" = "+c18.toString()+"? "+c13.equals8(c18)); 

       //out.close(); 
    }
}
