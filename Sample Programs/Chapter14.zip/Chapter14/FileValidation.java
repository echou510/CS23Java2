import java.io.*; 
import java.util.*; 
public class FileValidation{
    public static void main(String[] args){
      System.out.print("\f");
      boolean done = false; 
      File f; 
      String fn = ""; 
      Scanner in = new Scanner(System.in); 
      Scanner inf = null; 
      do{
        try{
            System.out.print("Enter a File Name: ");
            fn = in.nextLine().trim();
            inf = new Scanner(new File(fn)); 
            done = true; 
        }
        catch (Exception e){
           System.out.println("File Missing"); 
        }
      } while (!done); 
      
      while (inf.hasNext()){
           String s = inf.next(); 
           System.out.println(s); 
        }
      in.close(); 
      inf.close(); 
    }
}


