import java.util.Scanner; 
public class InputValidation
{
    public static void main(String[] args) {
    int[] vals = new int[10];

    for (int i = 0; i < 10; i++) {
      vals[i] = (i+1)*(i+1);
    }
    Scanner sc = new Scanner(System.in);
    int which  = 0; 
    int square = 0; 
    boolean done = false;
    do{
        try {
          System.out.print("Please type a number: ");
          which = Integer.parseInt(sc.nextLine());
          square = vals[which-1];
          done = true; 
        }
        catch(ArrayIndexOutOfBoundsException e){
          System.out.println("Wrong Input Range!"); 
        }
        catch(Exception f){
          System.out.println("Wrong Input Format!"); 
        }
    }while (!done); 
    
    System.out.println("The square of "+which+" is "+square);
  }
    
}
