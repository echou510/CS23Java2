
/**
 * Write a description of class TestException here.
 * 
 * @author (Eric Y. Chou) 
 * @version (01/25/2016)
 */
public class TestException
{
    public static void main(String[] args) {
    try {
      System.out.println(sum(new int[] {1, 2, 3, 4, 5}));
    }
    catch (Exception ex) {
      ex.printStackTrace();
      System.out.println("\n" + ex.getMessage());  // print out error message
      System.out.println("\n" + ex.toString());    // print out error type

      System.out.println("\nTrace Info Obtained from getStackTrace");
      StackTraceElement[] traceElements = ex.getStackTrace();    // get array of stack trace information. 
      for (int i = 0; i < traceElements.length; i++) {
        System.out.print("method " + traceElements[i].getMethodName());
        System.out.print("(" + traceElements[i].getClassName() + ":");
        System.out.println(traceElements[i].getLineNumber() + ")");
      }
    }
  }

  private static int sum(int[] list) {
    int result = 0;
    for (int i = 0; i <= list.length; i++) //put the equal sign in mistake
      result += list[i];
    return result;
  } 
}
