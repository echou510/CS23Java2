import java.util.Scanner; 
/**
 * Write a description of class QuotientFloat here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class QuotientFloat{
    public static void main(String[] args){
    Scanner input = new Scanner(System.in);
    
    // Prompt the user to enter two integers
    System.out.print("Enter two doubles: ");
    double number1 = input.nextDouble();
    double number2 = input.nextDouble();
    
    System.out.println(number1 + " / " + number2 + " is " +
      (number1 / number2));
  }
 }

