package geometric;


/**
 * Write a description of interface Geo3D here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public interface Geo3D 
{
  double getSurfaceArea(); 
  boolean equals3D(Geo3D g); 
}
