package geometric;
import java.awt.*;
import javax.swing.*;
public class BasicDrawJ extends JApplet
{  /*
   * Put your graphical method definition here. 
   */
  public class GPanel extends JPanel{
       public GPanel(){
        }       
       protected void paintComponent(Graphics g) {
             super.paintComponent(g);            
             /*
              * Put your graphical objects and method calls here. 
              */
        }
    }
  public BasicDrawJ(){   
      GPanel pane = new GPanel(); 
      add(pane);  // add the Gpanel to the applet
    } 
  public static void main(String[] args) {
    // Create a frame
    JFrame frame = new JFrame("RectangleDrawJ");
    // Create an instance of the applet
    BasicDrawJ applet = new BasicDrawJ();
    applet.init();
    // Add the applet instance to the frame
    frame.getContentPane().add(applet, BorderLayout.CENTER);
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 
    // Display the frame
    frame.setSize(400, 400);
    frame.setVisible(true);
  }
}
