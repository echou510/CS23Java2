package geometric;

import java.io.Serializable; 
/**
 * Write a description of class Rectangle2 here.
 * 
 * @author (Eric Y. Chou) 
 * @version (06/06/2016)
 */
public class Rectangle3 extends Geometric implements Serializable, Geo2D
{
	// instance variables 
	private int length;
	private int width;

	/**
	 * Constructor for objects of class rectangle
	 */
	public Rectangle3(int l, int w)
	{
		// initialise instance variables
		length = l;
		width = w;
	}

	// return the height
	public int getLength()
	{
		return length;
	}
	
	public int getWidth()
	{
	    return width;
	}
	
	public void setLength(int l){
	     length = l; 
	   }
    
	public void setWidth(int w){
	     width = w; 
	   }
	
	public double getArea(){
	     return width * length; 
	   }
    
	public String toString(){
	     return"[Rectangle: width="+width+", length="+length+"]"; 
	   }   
	
	public boolean equals2D(Geo2D g){
	     if (! (g instanceof Rectangle3)) return false; 
	     return equals((Rectangle3) g); 
	   }
	   
	public boolean equals(Rectangle3 r){
	     if (length == r.getLength() && width == r.getWidth()) return true; 
	     return false; 
	   }
}
