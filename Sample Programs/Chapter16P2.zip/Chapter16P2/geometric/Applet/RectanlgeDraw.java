package geometric;

import java.applet.Applet;
import java.awt.*;

/**
 * Write a description of class RectanlgeDraw here.
 * 
 * (x, y) base point (lower left corner)
 * (x, y), (x+w, y), (x, y-l), (x+w, y-l): 4 points in a rectangle
 * 
 * 
 * @author (Eric S. Chou, Jr.) 
 * @version (02/01/2016)
 */
public class RectanlgeDraw extends Applet
{   
    public void drawRectangle(int x, int y, Rectangle3 r, Graphics canvas) { 
            int width = r.getWidth(); 
            int len   = r.getLength(); 
            
            canvas.drawLine(x, y, x+width, y);  // p1, p2
            canvas.drawLine(x, y, x, y-len);  // p1, p3
            canvas.drawLine(x+width, y, x+width, y-len);  // p2, p4
            canvas.drawLine(x, y-len, x+width, y-len);  // p3, p4
    }
    
    public void fillRectangle(int x, int y, Rectangle3 r, Graphics canvas, Color c) { 
          int width = r.getWidth(); 
          int len   = r.getLength();  
          canvas.setColor(c);
          canvas.fillRect(x, y, width, len); 
    }
    
    public void paint(Graphics g)
    {
        Rectangle3 r = new Rectangle3(200, 300);   // in unit of pixels
        drawRectangle(10, 300, r, g);
        Rectangle3 s = new Rectangle3(66, 300); 
        fillRectangle(10, 100, s,  g, Color.RED); 
        Rectangle3 t = new Rectangle3(66, 300); 
        fillRectangle(10, 234, s,  g, Color.BLUE); 
    }
}
