package geometric;

import java.applet.Applet;
import java.awt.*;

public class BasicDraw extends Applet
{   
    /*
     * Put your method definition here. 
     */
    
    
    public void paint(Graphics g)
    {
        /*          
         * Put your graphicsl objects and method calls here.    
         */
    }
}

