package geometric;

import java.util.Scanner; 
import java.io.*; 
import java.util.ArrayList; 
import java.util.Iterator; 
/**
 * Write a description of class Geometric11Tester here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Geometric11Tester
{
    public static void main(String[] args){
      ArrayList<Geometric> glist = new ArrayList<Geometric>(); 
      glist.add(new Rectangle3(2, 4)); 
      glist.add(new Box3(2, 3, 6)); 
      glist.add(new Rectangle3(3, 7)); 
        
      glist.add(
        new Cube3(3){       // parent constructor with parameter
               public String toString(){  // method to be overridden
               return "[Anonymous Cube side="+getWidth()+"]";   
            }  // end of toString
        } // end of inner class
      ); 
      glist.add(new Cube3(3)); 
      glist.add(new Square3(5));
      glist.add(new Box3(3,6, 2));
      glist.add(
          new Triangle3(3.0, 4.0, 5.0){ // parent constructor with parameters
              public String toString(){  // method to be overridden. 
              return"[Anonymous Triangle: sideA="+getSideA()+", sideB="+getSideB()+ ", sideC="+getSideC()+"]" ;  
              } // end of toString
          } // end of inner class
      ); 
      glist.add(new Triangle3(3.0, 4.0, 5.0)); 
      glist.add(new IsoscelesRight3(3.0));
      glist.add(new Equilateral3(4));
      glist.add(new Prism3(3, 3, 3, 4)); 
      glist.add(new Triangle3(4.0, 4.0, 4.0));
      
      Iterator itr = glist.iterator(); 
      
      double sum=0; 
      while (itr.hasNext()){
         Geometric g = (Geometric) itr.next(); 
         System.out.println(g);
           sum += g.getArea(); 
        }
        
      System.out.println("Total Area for Geometric Family: "+sum); 
      System.out.println(); 
    }
}
