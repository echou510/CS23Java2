package geometric;

import java.util.Scanner; 
import java.io.*; 
import java.util.ArrayList; 
import java.util.Iterator; 
/**
 * Write a description of class Geometric11Tester here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Geometric15Tester
{
     static ArrayList<Rectangle3> rlist; 
     static Triangle3[] tlist; 
    
    public static void main(String[] args){
      rlist = new ArrayList<Rectangle3>(); 
      rlist.add(new Rectangle3(2, 4)); 
      rlist.add(new Box3(2, 3, 6)); 
      rlist.add(new Rectangle3(3, 7)); 
      rlist.add(new Cube3(3)); 
      rlist.add(new Square3(5));
      rlist.add(new Box3(3,6, 2));
      
      System.out.println("Rectangle List: "); 
      for (Rectangle3 r: rlist){
           System.out.println(r);
        }
      System.out.println(); 
      System.out.println("The result of Comparing 3rd element: \n"+rlist.get(2)+"\nwith the fifth element: \n"+rlist.get(4)+
      "\nis "+rlist.get(2).compareTo(rlist.get(4))); 
      
      System.out.println(); 
      
      System.out.println("Triangle Array: "); 
      tlist = new Triangle3[6];
      tlist[0] = new Triangle3(3.0, 3.0, 5.0); 
      tlist[1] = new Triangle3(3.0, 4.0, 5.0); 
      tlist[2] = new IsoscelesRight3(3.0);
      tlist[3] = new Equilateral3(4);
      tlist[4] = new Prism3(3, 3, 3, 4); 
      tlist[5] = new Triangle3(4.0, 4.0, 4.0);

      for (Triangle3 t: tlist){
          System.out.println(t); 
        }
        
      System.out.println(); 
      System.out.println("The result of Comparing 6th element: \n"+tlist[5]+"\nwith the second element:  \n"+tlist[1]+
      "\nis "+tlist[5].compareTo(tlist[1]));     
    }
}
