package geometric;

import java.util.Scanner; 
import java.io.*; 
import java.util.ArrayList; 
/**
 * Write a description of class Geometric8Tester here.
 * Rectangle3(2, 4), Box3(2, 3, 6), Rectangle3(3, 7), Cube3(3), Square3(5), Box3(3, 6, 2)
 * Triangle3(3.0, 4.0, 5.0), IsoscelesRight3(3.0), Equilateral3(4), Triangle3(4.0, 4.0, 4.0)
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Geometric9Tester
{
      public static void main(String[] args) throws Exception {
      ArrayList<Geometric> glist = new ArrayList<Geometric>(); 
      glist.add(new Rectangle3(2, 4)); 
      glist.add(new Box3(2, 3, 6)); 
      glist.add(new Rectangle3(3, 7)); 
        
      glist.add(
        new Cube3(3){       // parent constructor with parameter
               public String toString(){  // method to be overridden
               return "[Anonymous Cube side="+getWidth()+"]";   
            }  // end of toString
        } // end of inner class
      ); 
      glist.add(new Cube3(3)); 
      glist.add(new Square3(5));
      glist.add(new Box3(3,6, 2));
      glist.add(
          new Triangle3(3.0, 4.0, 5.0){ // parent constructor with parameters
              public String toString(){  // method to be overridden. 
              return"[Anonymous Triangle: sideA="+getSideA()+", sideB="+getSideB()+ ", sideC="+getSideC()+"]" ;  
              } // end of toString
          } // end of inner class
      ); 
      glist.add(new Triangle3(3.0, 4.0, 5.0)); 
      glist.add(new IsoscelesRight3(3.0));
      glist.add(new Equilateral3(4));
      glist.add(new Triangle3(4.0, 4.0, 4.0));
      
      double sum = 0; 
      for (Geometric g: glist){
           System.out.println(g);
           sum += g.getArea(); 
        }
      System.out.println("Total Area for Rectangle Family: "+sum); 
      
      System.out.println(); 
    }
}
