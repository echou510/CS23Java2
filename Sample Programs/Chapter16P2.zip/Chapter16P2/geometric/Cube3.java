package geometric;


/**
 * Write a description of class Cube here.
 * 
 * @author (Eric Y. Chou) 
 * @version (06/12/2016)
 */
public class Cube3 extends Box3
{
    Cube3(int side){
      super(side, side, side); 
    }
    
    public int getSide(){
       return getWidth(); 
    }
    
    public void setSide(int s){
       setWidth(s); 
       setLength(s); 
       setHeight(s); 
    }
    
    @Override
    public String toString(){
        return "[Cube side="+getWidth()+"]";   
    }
}
