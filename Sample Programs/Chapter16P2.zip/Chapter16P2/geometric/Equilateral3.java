package geometric;


/**
 * Write a description of class Square here.
 * 
 * @author (Eric Y. Chou) 
 * @version (06/12/2016)
 */
public class Equilateral3 extends Triangle3
{
    Equilateral3(double side){
      super(side, side, side); 
    }
    
    public double getSide(){
       return getSideA(); 
    }
    
    public void setSide(double s){
       setSideA(s); 
       setSideB(s); 
       setSideC(s); 
    }
    
    @Override
    public String toString(){
        return "[Equilateral Triangle side="+getSideA()+"]";   
    }
}
