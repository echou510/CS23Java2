package geometric;

import java.io.Serializable; 
/**
 * Write a description of class Triangle3 here.
 * 
 * This class represents an Triangle.
 * 
 * @author (Eric Y. Chou) 
 * @version (06/06/16)
 */
public class Triangle3 extends Geometric implements Serializable, Geo2D
{
    /**
     * First side of a trianlge
     */
    private double sideA;
    /** 
     * The second side of a triangle
     */
    private double sideB;
    /**
     * The third side of a trianlge
     */
    private double sideC;
    
    /**
     * Constructor of the Triangle class
     * 
     * @param sideA double the length of the first side. 
     * @param sideB double the length of the second side.
     * @param sideC double the length of the third side.
     */
    Triangle3(double sideA, double sideB, double sideC){
        this.sideA = sideA;
        this.sideB = sideB;
        this.sideC = sideC;
    }
    
    /**
     * getter method for the first side length
     * 
     * @return double the length of the first side. 
     */
    public double getSideA(){
        return sideA;
    }
    
    /**
     * getter method for the second side length
     * 
     * @return double the length of the second side. 
     */    
    public double getSideB(){
        return sideB;
    }
    
    /**
     * getter method for the third side length
     * 
     * @return double the length of the third side. 
     */    
    public double getSideC(){
        return sideC;
    }
    
   public void setSideA(double a){
      sideA = a; 
    }
    
   public void setSideB(double b){
      sideB = b; 
    } 
    
   public void setSideC(double c){
      sideC = c; 
    }
    
    public double getArea(){
            double a = getSideA();  
            double b = getSideB();  
            double c = getSideC(); 
            double s = (a + b + c)/2; 
            //System.out.println(Math.sqrt(s*(s-a)*(s-b)*(s-c))); 
            return Math.sqrt(s*(s-a)*(s-b)*(s-c));
    }
    
  	public String toString(){
	     return"[Triangle: sideA="+sideA+", sideB="+sideB+ ", sideC="+sideC+"]" ; 
	   }   
	   
    public boolean equals2D(Geo2D g){
	     if (! (g instanceof Triangle3)) return false; 
	     return equals((Triangle3) g); 
	   }   
	   
	public boolean equals(Triangle3 t){
	     if (sideA == t.getSideA() && sideB == t.getSideB() &&sideC == t.getSideC() ) return true; 
	     return false; 
	   }
}
