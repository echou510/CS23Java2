package geometric;

import java.util.ArrayList; 
import java.util.Arrays; 
import java.util.List; 
/**
 * Write a description of class Geometric18Tester here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Geometric18Tester
{  
   static ArrayList<Rectangle3> rlist;  
   static Triangle3[] tlist;  

   public static Geometric[] selectionSort(Geometric[] list) {
    for (int i = 0; i < list.length - 1; i++) {
      // Find the minimum in the list[i..list.length-1]
      Geometric currentMin = list[i];
      int currentMinIndex = i;

      for (int j = i + 1; j < list.length; j++) {
        if (currentMin.getArea() > list[j].getArea()) {
          currentMin = list[j];
          currentMinIndex = j;
        }
      }

      // Swap list[i] with list[currentMinIndex] if necessary;
      if (currentMinIndex != i) {
        list[currentMinIndex] = list[i];
        list[i] = currentMin;
      }
    }
    
    return list; 
   }    
   
   public static void main(String[] args){
      rlist = new ArrayList<Rectangle3>(); 
      rlist.add(new Rectangle3(2, 4));      
      rlist.add(new Rectangle3(5, 3));        
      rlist.add(new Rectangle3(6, 1));      
      rlist.add(new Rectangle3(7, 2));      
      rlist.add(new Rectangle3(4, 4));        
      rlist.add(new Rectangle3(3, 3)); 

      System.out.println("Rectangle3 List　(Before Selection Sort): "); 
      for (Rectangle3 t: rlist){
           System.out.println(t);
        }

      /* Conversion of a ArrayList<Rectangle>  to Rectangle3[] array    O(n) operation */ 
      Rectangle3[] alist = new Rectangle3[rlist.size()];      
      /* Sort the Rectangle3[] array O(n^2) operation */
      alist = (Rectangle3[]) rlist.toArray(alist);       
      /* Conversion of a Rectangle3[] array to a List of objects  O(n) operation*/ 
      List<Rectangle3> qlist = Arrays.asList((Rectangle3[]) selectionSort(alist)); 
      
      System.out.println("\nRectangle3 List　(After Selection Sort): "); 
      int i=0; 
      for (Rectangle3 t: qlist){
           rlist.set(i, (Rectangle3) t);  // Convert the object back to Rectangle 3 arraylist
           System.out.println(t);
           i++;
        }
      
      System.out.println(); 
      tlist = new Triangle3[6];   
      tlist[0] = new Triangle3(5, 4, 6);      
      tlist[1] = new Triangle3(7, 9, 8); 
      tlist[2] = new Triangle3(3, 4, 3);      
      tlist[3] = new Triangle3(2, 3.5, 2); 
      tlist[4] = new Triangle3(2.5, 2, 1); 
      tlist[5] = new Triangle3(6, 8, 4); 
      
      System.out.println("Triangle3 Array (Before Selection Sort): ");       
      for (Triangle3 t: tlist){
          System.out.println(t); 
        }
        
      tlist = (Triangle3[]) selectionSort(tlist); 
      
      System.out.println("\nTriangle3 Array (After Selection Sort): ");       
      for (Triangle3 t: tlist){
          System.out.println(t); 
        }
      System.out.println(); 
   }
}
