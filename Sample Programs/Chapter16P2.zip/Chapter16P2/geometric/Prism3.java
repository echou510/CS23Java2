package geometric;


/**
 * Write a description of class Prism3 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Prism3 extends Triangle3 implements Geo3D
{  
   double height;  
    
   Prism3(double sa, double sb, double sc, double h){
       super(sa, sb, sc); 
       this.height = h;
    }
   
   public double getHeight(){
      return height; 
    }
    
   public void setHeight(double h){
       height = h; 
    }
    
   public double getArea(){
      Triangle3 t = new Triangle3(getSideA(), getSideB(), getSideC()); 
      return t.getArea()*2 + (getSideA()+getSideB()+getSideC())*getHeight(); 
    }
   
   public double getSurfaceArea(){
      return getArea(); 
    }

  public boolean equals3D(Geo3D g){
	     if (! (g instanceof Prism3)) return false; 
	     return equals((Prism3) g); 
	   }     
	   
  public boolean equals(Prism3 t){
	     if (getSideA() == t.getSideA() && getSideB() == t.getSideB() && getSideC() == t.getSideC() 
	     && getHeight() == t.getHeight()) return true; 
	     return false; 
	   }
	   
  public String toString(){
	     return"[Prism: sideA="+getSideA()+", sideB="+getSideB()+ ", sideC="+getSideC()+", Height="+getHeight()+"]" ; 
	   }   
}
