package geometric;


/**
 * Abstract class Geometric - write a description of the class here
 * 
 * @author (your name here)
 * @version (version number or date here)
 */
public abstract class Geometric implements Comparable<Geometric>
{
    public abstract double getArea(); 
    	   
    public int compareTo(Geometric g){
      if (getArea() - g.getArea()>0) return 1; 
      else if (getArea() - g.getArea()<0) return -1; 
      return 0; 
    }
}
