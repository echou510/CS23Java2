package geometric;


import java.util.ArrayList; 
import java.util.Arrays; 
import java.util.List; 
/**
 * Write a description of class Geometric21Tester here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Geometric21Tester
{  
  static ArrayList<Rectangle3> rlist;  
  static Triangle3[] tlist;  
    public static void mergeSort(Geometric[] list) {
    if (list.length > 1) {
      // Merge sort the first half
      int low = 0, high = list.length-1;
      int mid = (low+high)/2;
      Geometric[] firstHalf = new Geometric[mid+1];
      System.arraycopy(list, 0, firstHalf, 0, mid+1);
      mergeSort(firstHalf);

      // Merge sort the second half
      int secondHalfLength = list.length - (mid+1);
      Geometric[] secondHalf = new Geometric[secondHalfLength];
      System.arraycopy(list, mid+1,
        secondHalf, 0, secondHalfLength);
      mergeSort(secondHalf);

      // Merge firstHalf with secondHalf into list
      merge(firstHalf, secondHalf, list);
    }
  }

  /** Merge two sorted lists */
  public static void merge(Geometric[] list1, Geometric[] list2, Geometric[] temp) {
    int current1 = 0; // Current index in list1
    int current2 = 0; // Current index in list2
    int current3 = 0; // Current index in temp

    while (current1 < list1.length && current2 < list2.length) {
      if (list1[current1].getArea() < list2[current2].getArea())
        temp[current3++] = list1[current1++];
      else
        temp[current3++] = list2[current2++];
    }

    while (current1 < list1.length)
      temp[current3++] = list1[current1++];

    while (current2 < list2.length)
      temp[current3++] = list2[current2++];
  }
  
  public static void main(String[] args){
      rlist = new ArrayList<Rectangle3>(); 
      rlist.add(new Rectangle3(2, 4));      
      rlist.add(new Rectangle3(5, 3));        
      rlist.add(new Rectangle3(6, 1));      
      rlist.add(new Rectangle3(7, 2));      
      rlist.add(new Rectangle3(4, 4));        
      rlist.add(new Rectangle3(3, 3)); 

      System.out.println("Rectangle3 List　(Before Merge Sort): "); 
      for (Rectangle3 t: rlist){
           System.out.println(t);
        }

      /* Conversion of a ArrayList<Rectangle>  to Rectangle3[] array    O(n) operation */ 
      Rectangle3[] alist = new Rectangle3[rlist.size()];      
      /* Sort the Rectangle3[] array O(n^2) operation */
      alist = (Rectangle3[]) rlist.toArray(alist);       
      /* Conversion of a Rectangle3[] array to a List of objects  O(n) operation*/
      mergeSort(alist); 
      List<Rectangle3> qlist = Arrays.asList((Rectangle3[]) alist); 
      
      System.out.println("\nRectangle3 List　(After Merge Sort): "); 
      int i=0; 
      for (Rectangle3 t: qlist){
           rlist.set(i, (Rectangle3) t);  // Convert the object back to Rectangle 3 arraylist
           System.out.println(t);
           i++; 
        }
      
      System.out.println(); 
      tlist = new Triangle3[6];   
      tlist[0] = new Triangle3(5, 4, 6);      
      tlist[1] = new Triangle3(7, 9, 8); 
      tlist[2] = new Triangle3(3, 4, 3);      
      tlist[3] = new Triangle3(2, 3.5, 2); 
      tlist[4] = new Triangle3(2.5, 2, 1); 
      tlist[5] = new Triangle3(6, 8, 4); 
     
      System.out.println("Triangle3 Array (Before Merge Sort): ");       
      for (Triangle3 t: tlist){
          System.out.println(t); 
        }
        
      mergeSort(tlist);
      tlist = (Triangle3[]) tlist; 
     
      System.out.println("\nTriangle3 Array (After Merge Sort): ");       
      for (Triangle3 t: tlist){
          System.out.println(t); 
        }
      System.out.println(); 
   }
}
