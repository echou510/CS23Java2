package geometric;
import java.awt.*;
import javax.swing.*;
public class BasicDrawJBlueJ extends JApplet
{   /*
     * Put your graphical method definition here. 
     */  
    public void init(){
        JRootPane rootPane = this.getRootPane();    
        rootPane.putClientProperty("defeatSystemEventQueueCheck", Boolean.TRUE);
    }
    public void start(){
    }
    public void stop(){
    }
    public void paint(Graphics g){        
       /*
        * Put your graphical objects and the method calls here. 
        */
    }
    public void destroy(){
    }
    public String getAppletInfo(){
        return "Title:   \nAuthor: Eric Y. Chou  \nDraw Rectangle. ";
    }
    public String[][] getParameterInfo(){
        // provide parameter information about the applet
        String paramInfo[][] = {
                 {"firstParameter",    "1-10",    "description of first parameter"},
                 {"status", "boolean", "description of second parameter"},
                 {"images",   "url",     "description of third parameter"}
        };
        return paramInfo;
    }
}
