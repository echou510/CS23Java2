package geometric;

import java.util.Scanner; 
import java.io.*; 
import java.util.ArrayList; 
/**
 * Write a description of class Geometric5 here.
 * Rectangle(2, 4), Box3(2, 3, 6), Rectangle(3, 7), Cube3(3), Square3(5), Box3(3, 6, 2)
 * Triangle(3.0, 4.0, 5.0), IsoscelesRight3(3.0), Equilateral3(4), Triangle(4.0, 4.0, 4.0)
 * 
 * @author (Eric Y. Chou) 
 * @version (06/12/2016)
 */
public class Geometric7Tester
{
    public static void main(String[] args) throws Exception {
      Scanner input = new Scanner(new File("geometric/rectangle.txt"));
      ArrayList<Rectangle3> rlist = new ArrayList<Rectangle3>(); 
      int i1, i2, i3; 
      double d1, d2, d3; 
      try {
        while (input.hasNext()){
         String token = input.next(); 
         if (token.equals("Rectangle")){
               i1 = Integer.parseInt(input.next());   
               i2 = Integer.parseInt(input.next());
               input.nextLine();  // consume the newLine mark
               rlist.add(new Rectangle3(i1, i2)); 
            }
         else if (token.equals("Box")){
               i1 = Integer.parseInt(input.next());   
               i2 = Integer.parseInt(input.next()); 
               i3 = Integer.parseInt(input.next());
               input.nextLine();  // consume the newLine mark
               rlist.add(new Box3(i1, i2, i3)); 
            }
         else if (token.equals("Cube")){
               i1 = Integer.parseInt(input.next());   
               input.nextLine();  // consume the newLine mark
               rlist.add(new Cube3(i1)); 
            }         
         else if (token.equals("Square")){
               i1 = Integer.parseInt(input.next());   
               input.nextLine();  // consume the newLine mark
               rlist.add(new Square3(i1)); 
            }
        }
      }
      catch(Exception e){ 
        System.out.println("Reading Error Occurs on the rectangle.txt file!!!"); 
      }
    
      input.close(); 
      
      /* Write out the object and read-in here */ 
      ObjectOutputStream output = new ObjectOutputStream(new FileOutputStream("geometric/rectangle.dat"));
      //output.writeObject(new java.util.Date());
       
      for (Rectangle3 r: rlist){
          // sub-class first
          if (r instanceof Cube3){  output.writeObject((Cube3) r);} 
          else  if (r instanceof Box3){  output.writeObject((Box3) r);} 
          else  if (r instanceof Square3){  output.writeObject((Square3) r);} 
          else {  output.writeObject(r);} 
        }
       
       output.close();
       
      /* New code ends */
      System.out.println("Objects in Rectangle Family =====================");
      
      int sum = 0; 

      ObjectInputStream inputObj = new ObjectInputStream(new FileInputStream("geometric/rectangle.dat"));
      for (int i=0; i<6; i++){
        Rectangle3 r0 = (Rectangle3)(inputObj.readObject()); 
        if (r0 instanceof Cube3){  
              Cube3 r = (Cube3) r0; 
              r.setSide(r.getWidth()*2);
              r0 = r; 
            } 
        else  if (r0 instanceof Box3){  
              Box3 r = (Box3) r0; 
              r.setLength(r.getLength()*2);
              r.setWidth(r.getWidth()*2); 
              r.setHeight(r.getHeight()*2); 
              r0 = r;
            } 
        else  if (r0 instanceof Square3){  
             Square3 r = (Square3) r0; 
             r.setSide(r.getWidth()*2);
             r0 = r;
            } 
        else {  
           Rectangle3 r = (Rectangle3) r0; 
           r.setLength(r.getLength()*2);
           r.setWidth(r.getWidth()*2); 
           r0 = r;
         }      
        System.out.println(r0); 
        sum += r0.getArea(); 
      } 
      inputObj.close(); 
      
      System.out.println("Total Area for Rectangle Family: "+sum); 
      
      System.out.println(); 
      
      input = new Scanner(new File("geometric/triangle.txt"));
      
      int count=0; 
      try{
        while (input.hasNext()){
          String token = input.nextLine(); 
          if (!token.equals("")) count++; 
        }
      }
      catch(Exception e){
         System.out.println("Reading Error Occurs on the triangle.txt file!!!"); 
        }
      input.close(); 
      
      input = new Scanner(new File("geometric/triangle.txt"));
      Triangle3[] tlist = new Triangle3[count];
      try{
        for (int i=0; i<count; i++){
         String token = input.next(); 
         if (token.equals("Triangle")){
               d1 = Double.parseDouble(input.next());   
               d2 = Double.parseDouble(input.next());
               d3 = Double.parseDouble(input.next());               
               input.nextLine();  // consume the newLine mark
               tlist[i]  = new Triangle3(d1, d2, d3); 
            }
         else if (token.equals("IsoscelesRight")){
               d1 = Double.parseDouble(input.next());               
               input.nextLine();  // consume the newLine mark
               tlist[i]  = new IsoscelesRight3(d1); 
            }           
         else if (token.equals("Equilateral")){
               d1 = Double.parseDouble(input.next());               
               input.nextLine();  // consume the newLine mark
               tlist[i]  = new Equilateral3(d1); 
            }                  
        }
      }
      catch(Exception e){
          System.out.println("Reading Error Occurs on the triangle.txt file!!!"); 
        }
      input.close(); 
      
      /* Write out the object and read-in here */ 
      output = new ObjectOutputStream(new FileOutputStream("geometric/triangle.dat"));
      //output.writeObject(new java.util.Date());
       
      for (Triangle3 t: tlist){
          // sub-class first
          if (t instanceof Equilateral3){  output.writeObject((Equilateral3) t);} 
          else  if (t instanceof IsoscelesRight3){  output.writeObject((IsoscelesRight3) t);} 
          else {  output.writeObject(t);} 
        }
       
       output.close();
      /* New code ends */
      System.out.println("Objects in Triangle Family =====================");
      
      double total = 0.0; 
      
      //for (Triangle3 t: tlist){
      //    System.out.println(t); 
      //    total += t.getArea(); 
      //  }
      inputObj = new ObjectInputStream(new FileInputStream("geometric/triangle.dat"));
      for (int i=0; i<4; i++){
        Triangle3 t0 = (Triangle3)(inputObj.readObject()); 
        if (t0 instanceof Equilateral3){  
              Equilateral3 t = (Equilateral3) t0; 
              t.setSide(t.getSideA()*2);
              t0 = t; 
            } 
        else  if (t0 instanceof IsoscelesRight3){  
              IsoscelesRight3 t = (IsoscelesRight3) t0; 
              t.setEqualSide(t.getSideA()*2);
              t0 = t;
            } 
        else {  
           Triangle3 t = (Triangle3) t0; 
           t.setSideA(t.getSideA()*2); t.setSideB(t.getSideB()*2); t.setSideC(t.getSideC()*2);
           t0 = t;
         }      
        System.out.println(t0); 
        total += t0.getArea(); 
      }
      inputObj.close();       
      
      System.out.println("Total Area for Triangle Family: "+total); 
    }
}
