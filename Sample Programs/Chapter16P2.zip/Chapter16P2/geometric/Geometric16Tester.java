package geometric;


import java.util.Scanner; 
import java.io.*; 
import java.util.ArrayList; 
import java.util.Iterator; 
/**
 * Write a description of class Geometric11Tester here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Geometric16Tester
{
    static ArrayList<Geo2D> list2;  
    static Geo3D[] list3 = new Geo3D[6];
    
    public static int linearSearch2D(ArrayList<Geo2D> a, Geo2D g){
        int index = -1; 
        
        for (int i=0; i<a.size() && index ==-1; i++){
           if (a.get(i).equals2D(g)) index = i; 
        }
        
        return index; 
    }
    
    public static int linearSearch3D(Geo3D[] a, Geo3D g){
        int index = -1; 
        
        for (int i=0; i<a.length && index ==-1; i++){
           if (a[i].equals3D(g)) index = i; 
        }
        
        return index; 
    }
    
    public static void main(String[] args){
      list2 = new ArrayList<Geo2D>(); 
      list2.add(new Rectangle3(2, 4)); 
      list2.add(new Triangle3(3.0, 4.0, 5.0)); 
      list2.add(new IsoscelesRight3(3.0));
      list2.add(new Equilateral3(4));
      list2.add(new Rectangle3(3, 7)); 
      list2.add(new Square3(5));

      
      System.out.println("Geo2D List: "); 
      for (Geo2D t: list2){
           System.out.println(t);
        }

      System.out.println(); 
      System.out.println("Equilateral3(4)   is found at index=" + linearSearch2D(list2, new Equilateral3(4)));
      System.out.println("Rectangle3(3, 7)  is found at index=" + linearSearch2D(list2, new Rectangle3(3, 7)));
      System.out.println("Square3(5)        is found at index=" + linearSearch2D(list2, new Square3(5)));
      System.out.println("Rectangle3(6, 6)  is found at index=" + linearSearch2D(list2, new Rectangle3(6, 6)));
      System.out.println("Triangle3(5, 5, 5)is found at index=" + linearSearch2D(list2, new Triangle3(5, 5, 5)));  

      System.out.println(); 
      
      System.out.println("Geo3D Array: "); 
      list3[0] = new Box3(2, 3, 6); 
      list3[1] = new Prism3(3, 3, 3, 4); 
      list3[2] = new Cube3(3); 
      list3[3]= new Box3(3, 6, 2);      
      list3[4] = new Prism3(4, 3, 5, 2);
      list3[5] = new Cube3(2); 


      for (Geo3D t: list3){
          System.out.println(t); 
        }
      
      System.out.println(); 
      System.out.println("Box3(2, 3, 6)     is found at index=" + linearSearch3D(list3, new Box3(2, 3, 6)  ));
      System.out.println("Prism3(4, 3, 5, 2)is found at index=" + linearSearch3D(list3, new Prism3(4, 3, 5, 2)  ));
      System.out.println("Cube3(3)          is found at index=" + linearSearch3D(list3, new Cube3(3) ));
      System.out.println("Box3(6, 6, 6)     is found at index=" + linearSearch3D(list3, new Box3(6, 6, 6) ));  
      System.out.println("Cube3(5)          is found at index=" + linearSearch3D(list3, new Cube3(5)  ));  
      
      System.out.println(); 
    }
}
