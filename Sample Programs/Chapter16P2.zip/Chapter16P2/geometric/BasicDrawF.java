package geometric;
import java.awt.*;
import javax.swing.*;
public class BasicDrawF extends JFrame
{ /*
   * Put your graphical method definition here. 
   */  
    public class GPanel extends JPanel{
       public GPanel(){
        }        
       protected void paintComponent(Graphics g) {
          super.paintComponent(g);          
          /*
           * Put your graphical objects and the method calls here. 
           */
        }
    }    
  public BasicDrawF(){   
      GPanel pane = new GPanel(); 
      add(pane);  // add the Gpanel to the applet
    }  
  public static void main(String[] args) {
    // Create a frame
    BasicDrawF frame = new BasicDrawF();
    frame.setTitle("Basic Draw"); 
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 
    // Display the frame
    frame.setSize(400, 400);
    frame.setVisible(true);
  }
}
