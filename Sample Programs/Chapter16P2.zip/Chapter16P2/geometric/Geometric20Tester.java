package geometric;

import java.util.ArrayList; 
import java.util.Arrays; 
import java.util.List; 
/**
 * Write a description of class Geometric20Tester here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Geometric20Tester
{  
  static ArrayList<Rectangle3> rlist;  
  static Triangle3[] tlist;  
   
  public static Geometric[] bubbleSort(Geometric[] list) {
    boolean needNextPass = true;
    
    for (int k = 1; k < list.length && needNextPass; k++) {
      // Array may be sorted and next pass not needed
      needNextPass = false;
      for (int i = 0; i < list.length - k; i++) {
        if (list[i].getArea() > list[i + 1].getArea()) {
          // Swap list[i] with list[i + 1]
          Geometric temp = list[i];
          list[i] = list[i + 1];
          list[i + 1] = temp;
          
          needNextPass = true; // Next pass still needed
        }
      }
    }  
    return list; 
  }
  
  public static void main(String[] args){
      rlist = new ArrayList<Rectangle3>(); 
      rlist.add(new Rectangle3(2, 4));      
      rlist.add(new Rectangle3(5, 3));        
      rlist.add(new Rectangle3(6, 1));      
      rlist.add(new Rectangle3(7, 2));      
      rlist.add(new Rectangle3(4, 4));        
      rlist.add(new Rectangle3(3, 3)); 

      System.out.println("Rectangle3 List　(Before Bubble Sort): "); 
      for (Rectangle3 t: rlist){
           System.out.println(t);
        }

      /* Conversion of a ArrayList<Rectangle>  to Rectangle3[] array    O(n) operation */ 
      Rectangle3[] alist = new Rectangle3[rlist.size()];      
      /* Sort the Rectangle3[] array O(n^2) operation */
      alist = (Rectangle3[]) rlist.toArray(alist);       
      /* Conversion of a Rectangle3[] array to a List of objects  O(n) operation*/ 
      List<Rectangle3> qlist = Arrays.asList((Rectangle3[]) bubbleSort(alist)); 
      
      System.out.println("\nRectangle3 List　(After Bubble Sort): "); 
      int i=0; 
      for (Rectangle3 t: qlist){
           rlist.set(i, (Rectangle3) t);  // Convert the object back to Rectangle 3 arraylist
           System.out.println(t);
           i++; 
        }
      
      System.out.println(); 
      tlist = new Triangle3[6];   
      tlist[0] = new Triangle3(5, 4, 6);      
      tlist[1] = new Triangle3(7, 9, 8); 
      tlist[2] = new Triangle3(3, 4, 3);      
      tlist[3] = new Triangle3(2, 3.5, 2); 
      tlist[4] = new Triangle3(2.5, 2, 1); 
      tlist[5] = new Triangle3(6, 8, 4); 
     
      System.out.println("Triangle3 Array (Before Bubble Sort): ");       
      for (Triangle3 t: tlist){
          System.out.println(t); 
        }
        
      tlist = (Triangle3[]) bubbleSort(tlist); 
     
      System.out.println("\nTriangle3 Array (After Bubble Sort): ");       
      for (Triangle3 t: tlist){
          System.out.println(t); 
        }
      System.out.println(); 
   }
}
