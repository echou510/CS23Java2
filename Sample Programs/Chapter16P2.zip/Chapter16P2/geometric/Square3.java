package geometric;


/**
 * Write a description of class Square here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Square3 extends Rectangle3 
{
    Square3(int side){
      super(side, side); 
    }
    
    public int getSide(){
       return getWidth(); 
    }
    
    public void setSide(int s){
       setWidth(s); 
       setLength(s); 
    }
    
    @Override
    public String toString(){
        return "[Square side="+getWidth()+"]";   
    }
}
