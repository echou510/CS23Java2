package geometric;


/**
 * Write a description of class Box here.
 * 
 * @author (Eric Y. Chou) 
 * @version (06/11/2016)
 */
public class Box3 extends Rectangle3 implements Geo3D
{
   private int height; 
   
   Box3(int l, int w, int h){
       super(l, w); 
       this.height = h; 
    }
    
   public int getHeight(){
      return height; 
    }
   
   public void setHeight(int h){
       this.height = h; 
    }
    
   @Override
   public double getArea(){  // get the surface area of a box. 
      return 2*(getWidth()*getLength()+getWidth()*getHeight()+getLength()*getHeight()); 
    }
    
   @Override
   public double getSurfaceArea(){  // get the surface area of a box. 
      return 2*(getWidth()*getLength()+getWidth()*getHeight()+getLength()*getHeight()); 
    }
    
   @Override
   public String toString(){
      return "[Box: length="+getLength()+", width="+getWidth()+", height="+getHeight()+"]"; 
    }
    
	public boolean equals3D(Geo3D g){
	     if (! (g instanceof Box3)) return false; 
	     return equals((Box3) g); 
	   }
	   
   // Not really overriding because Box is different from Rectangle
   public boolean equals(Box3 a){
       if (this.getLength()== a.getLength() && this.getWidth() == a.getWidth() && this.getHeight() == a.getHeight()){
          return true; 
        }
       return false; 
    } 
}
