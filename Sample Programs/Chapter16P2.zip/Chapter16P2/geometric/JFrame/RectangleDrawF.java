package geometric;


import java.awt.*;
import javax.swing.*;

/**
 * Class RectangleDrawJ - write a description of the class here
 * 
 * @author (Eric Y. Chou) 
 * @version (06/20/2016)
 */
public class RectangleDrawF extends JFrame
{
  public void drawRectangle(int x, int y, Rectangle3 r, Graphics canvas) { 
            int width = r.getWidth(); 
            int len   = r.getLength(); 
            
            canvas.drawLine(x, y, x+width, y);  // p1, p2
            canvas.drawLine(x, y, x, y-len);  // p1, p3
            canvas.drawLine(x+width, y, x+width, y-len);  // p2, p4
            canvas.drawLine(x, y-len, x+width, y-len);  // p3, p4
    }
    
  public void fillRectangle(int x, int y, Rectangle3 r, Graphics canvas, Color c) { 
          int width = r.getWidth(); 
          int len   = r.getLength();  
          canvas.setColor(c);
          canvas.fillRect(x, y, width, len); 
    }    
  
    public class GPanel extends JPanel{
       public GPanel(){
        }
        
       protected void paintComponent(Graphics g) {
          super.paintComponent(g);
          
          Rectangle3 r = new Rectangle3(200, 300);   // in unit of pixels
          drawRectangle(10, 300, r, g);
          Rectangle3 s = new Rectangle3(66, 300); 
          fillRectangle(10, 100, s,  g, Color.RED); 
          Rectangle3 t = new Rectangle3(66, 300); 
          fillRectangle(10, 234, s,  g, Color.BLUE); 
        }
    }
    
  public RectangleDrawF(){   
      GPanel pane = new GPanel(); 
      add(pane);  // add the Gpanel to the applet
    }  
   
  public static void main(String[] args) {
    // Create a frame
    RectangleDrawF frame = new RectangleDrawF();

    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 
    // Display the frame
    frame.setSize(400, 400);
    frame.setVisible(true);
  }
}
