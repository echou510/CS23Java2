package geometric;

import java.util.ArrayList; 
import java.util.List;  
import java.util.Arrays; 
/**
 * Write a description of class Geometric19Tester here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Geometric19Tester
{
    static ArrayList<Geo2D> list2;  
    static Geo3D[] list3 = new Geo3D[6];
    
    public static Geo2D[] selectionSort(Geo2D[] list) {
     for (int i = 0; i < list.length - 1; i++) {
       // Find the minimum in the list[i..list.length-1]
       Geo2D currentMin = list[i];
       int currentMinIndex = i;
       for (int j = i + 1; j < list.length; j++) {
         if (currentMin.getArea() > list[j].getArea()) {
           currentMin = list[j];
           currentMinIndex = j;
         }
       }
       // Swap list[i] with list[currentMinIndex] if necessary;
       if (currentMinIndex != i) {
         list[currentMinIndex] = list[i];
         list[i] = currentMin;
       }
      }
      return list; 
    }        
    
    public static Geo3D[] selectionSort(Geo3D[] list) {
     for (int i = 0; i < list.length - 1; i++) {
       // Find the minimum in the list[i..list.length-1]
       Geo3D currentMin = list[i];
       int currentMinIndex = i;
       for (int j = i + 1; j < list.length; j++) {
         if (currentMin.getSurfaceArea() > list[j].getSurfaceArea()) {
         //if (((Geometric) currentMin).compareTo((Geometric) list[j])>0) {
           currentMin = list[j];
           currentMinIndex = j;
         }
       }
       // Swap list[i] with list[currentMinIndex] if necessary;
       if (currentMinIndex != i) {
         list[currentMinIndex] = list[i];
         list[i] = currentMin;
       }
      }
      return list; 
    }    
    
    public static int binarySearch2D(Geo2D[] list, Geo2D key) {
      int low = 0;
      int high = list.length - 1;
  
      while (high >= low) {
        int mid = (low + high) / 2;
        if (key.getArea() - list[mid].getArea() < 0)
          high = mid - 1;
        else if (key.equals2D(list[mid]))
          return mid;
        else
          low = mid + 1;
      }
      return -low - 1; // Now high < low
    }
    
    public static int binarySearch3D(Geo3D[] list, Geo3D key) {
      int low = 0;
      int high = list.length - 1;
      
      while (high >= low) {
        int mid = (low + high) / 2;
        if (key.getSurfaceArea() - list[mid].getSurfaceArea() < 0)
          high = mid - 1;
        else if (key.equals3D(list[mid]))
          return mid;
        else
          low = mid + 1;
      }
      return -low - 1; // Now high < low
    }
    
    public static void main(String[] args){
      list2 = new ArrayList<Geo2D>(); 
      list2.add(new Rectangle3(2, 4)); 
      list2.add(new Triangle3(3.0, 4.0, 5.0)); 
      list2.add(new IsoscelesRight3(3.0));
      list2.add(new Equilateral3(4));
      list2.add(new Rectangle3(3, 7)); 
      list2.add(new Square3(5));
      
      System.out.println("Geo2D List: "); 
      for (Geo2D t: list2){
           System.out.println(t);
        }
      
      /* Selection Sort on list2 */         
      Geo2D[] alist = new Geo2D[list2.size()];      
      alist = (Geo2D[]) list2.toArray(alist);       

      /* Conversion of a Rectangle3[] array to a List of objects  O(n) operation*/ 
      List<Geo2D> qlist = Arrays.asList((Geo2D[]) selectionSort(alist));   
      
      int i=0; 
      for (Geo2D t: qlist){
           list2.set(i, t);  // Convert the object back to Rectangle 3 arraylist
           i++; 
        }
        
      System.out.println("");
      System.out.println("Geo2D List: "); 
      for (Geo2D t: list2){
           System.out.println(t);
        }
        
      alist = new Geo2D[list2.size()];  alist = (Geo2D[]) list2.toArray(alist);
      System.out.println(); 
      System.out.println("Equilateral3(4)   is found at index=" + binarySearch2D(alist, new Equilateral3(4)));
      System.out.println("Rectangle3(3, 7)  is found at index=" + binarySearch2D(alist, new Rectangle3(3, 7)));
      System.out.println("Square3(5)        is found at index=" + binarySearch2D(alist, new Square3(5)));
      System.out.println("Rectangle3(6, 6)  is found at index=" + binarySearch2D(alist, new Rectangle3(6, 6)));
      System.out.println("Triangle3(5, 5, 5)is found at index=" + binarySearch2D(alist, new Triangle3(5, 5, 5)));  

      System.out.println(); 
      

      list3[0] = new Box3(2, 3, 6); 
      list3[1] = new Prism3(3, 3, 3, 4); 
      list3[2] = new Cube3(3); 
      list3[3]= new Box3(3, 6, 2);      
      list3[4] = new Prism3(4, 3, 5, 2);
      list3[5] = new Cube3(2); 
      
      System.out.println("Geo3D Array: ");       
      for (Geo3D t: list3){
          System.out.println(t); 
        }

      System.out.println();         
      /* Selection Sort on list3 */         
      list3 = selectionSort(list3);   
      
      System.out.println("Geo3D Array: ");       
      for (Geo3D t: list3){
          System.out.println(t); 
        }
        
      System.out.println(); 
      System.out.println("Box3(2, 3, 6)     is found at index=" + binarySearch3D(list3, new Box3(2, 3, 6)  ));
      System.out.println("Prism3(4, 3, 5, 2)is found at index=" + binarySearch3D(list3, new Prism3(4, 3, 5, 2)  ));
      System.out.println("Cube3(3)          is found at index=" + binarySearch3D(list3, new Cube3(3) ));
      System.out.println("Box3(6, 6, 6)     is found at index=" + binarySearch3D(list3, new Box3(6, 6, 6) ));  
      System.out.println("Cube3(5)          is found at index=" + binarySearch3D(list3, new Cube3(5)  ));  
      
      System.out.println(); 
    }
}
