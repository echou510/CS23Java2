package geometric;


/**
 * Write a description of class IsoscelesRight3here.
 * 
 * @author (Eric Y. Chou) 
 * @version (06/11/2016)
 */
public class IsoscelesRight3 extends Triangle3
{
     /**
     * Constructor of the IsoscelesRight class
     * 
     * @param equalSide double side length of the two equal-side (sides near the right angle)
     */
    IsoscelesRight3(double equalSide){
        super(equalSide, equalSide, equalSide*Math.sqrt(2.0));
    
    }
    
    public void setEqualSide(double s){
       setSideA(s);  setSideB(s); setSideC(s*Math.sqrt(2.0)); 
    }
    
    /** 
     * get the side length of the equal sides for a isoscelesRight
     * 
     * @return double the side length of the equal sides for a isoscelesRight
     */
    public double getEqualSide(){
        return this.getSideA();
    }
    
    /**
     * tet the side length of the non-equal side (far-side from the right angle) for an isoscelesRight
     * 
     * @return double the length of the non-equal side of an isoscelesRight triagnle. 
     */
    public double getNotEqualSide(){
        return this.getSideC();
    }
    
    public boolean equals(IsoscelesRight3 a){
      double e = (int) (this.getEqualSide() * 10000)/10000.0; 
      double f = (int) (   a.getEqualSide() * 10000)/10000.0;
      if (e==f) return true; 
      return false; 
    }
    
    public String toString(){
	     return"[IsoscelesRight: equal side="+getEqualSide()+", non-equal side="+getNotEqualSide()+"]" ; 
	   }   
}
