
/**
 * Write a description of class TestProgramOOP here.
 * 
 * @author (Eric Y. Chou) 
 * @version (12/15/2015)
 */
public class TestProgramOOP
{   public static void testStaticMethod(ProgramOOP oop){
        System.out.println("Hey... I am in static method...");
        oop.setStr("STATIC-STRING"); 
        System.out.println(oop.getStr());
    }
    public static void testObjectMethod(ProgramOOP oop){
        System.out.println("Hey i am in non-static method");
        System.out.println(oop.getStr());
        oop.setName("Java Programming AP Edition"); 
        System.out.println("Name: "+oop.getName());
    }     
    public static void main(String[] args){
       ProgramOOP oop = new ProgramOOP();  
       testStaticMethod(oop);   
       testObjectMethod(oop); 
    }
}
