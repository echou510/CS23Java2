
/**
 * PHY constants
 * 
 * @author (Eric Y. Chou) 
 * @version (12/14/2015)
 */
public class PHY
{  public final static double C = 3.00E+08;                      // Speed of Light
   public final static double MOLAR_GAS = 8.31;                  // Molar gas constant
   public final static double E_CHARGE = 1.60E-19;               // electron charge
   public final static double P_CHARGE = 1.60E-19;               // proton charge
   public final static double E_MASS =  9.11E-31;                // electron mass
   public final static double P_MASS =  1.67E-27;                // proton Mass
   public final static double N_MASS =  1.67E-27;                // neutron Mass
   public final static double G = 6.67E-11;                      // Gravitational Constant
   public final static double QUARTER_PI_EPSILON0 = 8.99E+09;    // Electrostatic Constant
   public final static double EPSILON0 = 8.85E-12;               // Permitivity of Free Space 
   public final static double MAG = 1.26E-06;                    // Permeability of Free Space
   public final static double BOLTZMANN = 1.38E-23;              // Boltzmann Constant
   public final static double PLANCK =  6.63E-34;                // Planck Constant
}
