
/**
 * Write a description of class Phasor here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Phasor
{
   public double theta = 0.0; 
   public double radius= 0.0; 
}
