
/**
 * Write a description of class Vector here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Vector
{
   public double x = 0.0; 
   public double y = 0.0; 
}
