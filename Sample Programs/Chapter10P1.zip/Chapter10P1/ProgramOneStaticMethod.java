
/**
 * Write a description of class ProgramOneStaticMethod here.
 * 
 * @author (Eric Y. Chou) 
 * @version (12/15/2015)
 */
public class ProgramOneStaticMethod
{
    // To be expanded for Static Methods
    //public ProgramStaticMixed(String n){}
    //public static void testStaticMethod(){}
    //public void testObjectMethod(){}  
    
    public static void main(String a[]){
        String name;
        String staticStr = "STATIC-STRING";
        System.out.println("Hey... I am in static method...");
        System.out.println(staticStr);
        System.out.println("Hey i am in non-static method");
        System.out.println(staticStr);
        System.out.println("Name: "+"Java Programming AP Edition");
    }
}
