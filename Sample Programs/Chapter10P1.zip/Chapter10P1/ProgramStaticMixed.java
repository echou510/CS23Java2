/**
 * Write a description of class ProgramStaticMixed here.
 * 
 * @author (Eric Y. Chou) 
 * @version (12/15/2015)
 */
public class ProgramStaticMixed {
    private String name;
    private static String staticStr = "STATIC-STRING";
    public ProgramStaticMixed(String n){
        this.name = n;
    }
    public static void testStaticMethod(){
        System.out.println("Hey... I am in static method...");
        //you can call static variables here
        System.out.println(ProgramStaticMixed.staticStr);
        //you can not call instance variables here.
    }
    public void testObjectMethod(){
        System.out.println("Hey i am in non-static method");
        //you can also call static variables here
        System.out.println(ProgramStaticMixed.staticStr);
        //you can call instance variables here
        System.out.println("Name: "+this.name);
    }     
    public static void main(String a[]){
        //By using class name, you can call static method
        ProgramStaticMixed.testStaticMethod();
        ProgramStaticMixed msm = new ProgramStaticMixed("Java Programming AP Edition");
        msm.testObjectMethod();
    }
}
