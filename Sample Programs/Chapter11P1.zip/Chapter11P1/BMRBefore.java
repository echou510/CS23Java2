import java.util.Scanner; 
/**
 * Write a description of class BMRBefore here.
 * 
 * @author (Eric Y. Chou) 
 * @version (V1 01/09/2016)
 */
public class BMRBefore
{   public static double rounded(double dd){
     double roundedDD = Math.round(dd*10.0)/10.0;   // To get a double number with 1 digit decimal point
     return roundedDD;
    }
    
    public static void main(String []args){
        //input
        Scanner input = new Scanner(System.in);
        //User Input
        System.out.print("Enter your name (First Last): ");
        String name = input.nextLine();
        System.out.print("Gender (M/F): ");
        char gender = input.nextLine().charAt(0);
        System.out.print("Enter your age: ");
        int age = input.nextInt(); 
        System.out.print("Height in inches: ");
        int height = input.nextInt();
        System.out.print("Weight in pounds: ");
        int weight = input.nextInt();
        
        //Calculations
        double height1 = height*2.54;         // height1 in cm
        double weight1 = weight*0.454;        // weight1 in kg
        
        double bmr = 0.0;             // BMR in calories Original Harris-Benedict Equation
        double bmrRounded = 0.0;      // BMR rounded to 1 decimal digit in calories Original Harris-Benedict Equation (optional)
        
        if (gender == 'M') {
           bmr = 13.7516*weight1 +  5.0033*height1 - 6.7550*age + 66.4730;
           bmrRounded = rounded(13.7516)*weight1 +  rounded(5.0033)*height1 - rounded(6.7550)*age + rounded(66.4730); 
        }
        else if (gender == 'F'){
           bmr = 9.5634*weight1 +  1.8496*height1 - 4.6756*age + 655.0955; 
           bmrRounded = rounded(9.5634)*weight1 +  rounded(1.8496)*height1 - rounded(4.6756)*age + rounded(655.0955); 
        }
        
        //print
        System.out.println("Basal Metabolic Rate Calculation");
        System.out.println("Name: " + name);
        System.out.println("Gender: " + gender); 
        System.out.println("Age: " + age); 
        // System.out.println("Weight (kg): "+weight1); 
        System.out.print("Weight (kg): ");        
        System.out.printf("%6.1f", weight1);
        System.out.println(); 
        //System.out.println("Height (m): " + height1);
        System.out.print("Height  (m): ");
        System.out.printf("%6.1f", height1);
        System.out.println(); 
        System.out.println(); 
        
        // BMR output
        System.out.print("Basal Metabolic Rate: ");  
        System.out.printf("%6.1f", bmr);
        System.out.println(" calories per day. (Original Harris-Benedict Equation)"); 
        System.out.print("Basal Metabolic Rate: ");  
        System.out.printf("%6.1f", bmrRounded);
        System.out.println(" calories per day. (Rounded Original Harris-Benedict Equation)"); 
        System.out.println(); 
    }
}
