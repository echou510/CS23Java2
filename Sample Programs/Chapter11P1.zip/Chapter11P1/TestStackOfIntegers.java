
/**
 * Write a description of class TestStackOfIntegers here.
 * 
 * @author (Eric Y. Chou) 
 * @version (01/10/2016)
 */
public class TestStackOfIntegers {
  public static void main(String[] args) {
    StackOfIntegers stack = new StackOfIntegers(16);
    
    for (int i = 0; i < 10; i++)
      stack.push(i);
    
    while (!stack.empty())
      System.out.print(stack.pop() + " ");  
      
    System.out.println(); 
    System.out.println("Check Underflow Condition"); 
    int a = stack.pop(); 
    System.out.println(); 
    
    System.out.println("Check Overflow Condition");    
    for (int i=0; i<18; i++){
         stack.push(i*2); 
    }
    
    for (int i=0; i<18; i++){
      System.out.print(stack.pop() + " ");  
    }
    System.out.println(); 
  }
}
