package frontcontroller;


/**
 * Write a description of class HomeView here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class HomeView {
   public void show(){
      System.out.println("Displaying Home Page");
   }
}