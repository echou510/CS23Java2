package frontcontroller;


/**
 * Write a description of class FrontControllerPatternDemo here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class FrontControllerPatternDemo {
   public static void main(String[] args) {
   
      FrontController frontController = new FrontController();
      frontController.dispatchRequest("HOME");
      frontController.dispatchRequest("STUDENT");
   }
}