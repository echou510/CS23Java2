package frontcontroller;


/**
 * Write a description of class StudentView here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class StudentView {
   public void show(){
      System.out.println("Displaying Student Page");
   }
}
