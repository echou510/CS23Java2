
/**
 * Write a description of class Eggplant here.
 * 
 * @author (Eric Y. Chou) 
 * @version (04/10/2017)
 */
public class Eggplant extends Vegatable
{
   public Eggplant(String name){
       super(name); 
    }
   
   public String cook(){
       return super.cook()+super.cook(); 
    }
}
