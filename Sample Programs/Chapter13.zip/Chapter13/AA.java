import java.util.Arrays; 
import java.util.ArrayList; 
public class AA
{
  public static void main(String[] args){
      ArrayList<Integer> alist = new ArrayList<Integer>(Arrays.asList(new Integer[]{5, 4, 3, 2, 1})); 
      System.out.println(alist); 
    }
  
}
