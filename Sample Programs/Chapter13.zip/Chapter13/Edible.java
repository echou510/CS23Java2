
/**
 * Write a description of interface Edible here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public interface Edible {
  /** Describe how to eat */
  public abstract String howToEat(); // must be overriden
}
