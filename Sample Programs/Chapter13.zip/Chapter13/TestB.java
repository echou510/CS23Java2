import java.util.Arrays; 
public class TestB
{
   
   public static void main(String[] args){
      System.out.print("\f"); 
      A a = new A(3); 
      System.out.println("Instance variable a="+a); 
      System.out.println("class variable count accessed by A="+A.count); 
      System.out.println("class variable count accessed by instance="+a.count); 
      A a1 = new A(3); 
      A a2 = new A(); 
      A a3 = new A(3); 
      System.out.println("class variable count accessed by A4="+A.count); 
      System.out.println(a1.equals(a2));
      System.out.println(a1.equals(a3));
      
      A[] alist = {new A(5), new A(1), new A(3), new A(2), new A(4)}; 
      Arrays.sort(alist);
      System.out.println(Arrays.toString(alist)); 
      B b = new A(); 
      System.out.println("From b="+b.getB()); 
      B[] blist = {new A(5), new D(), new A(3), new D(), new A(4)}; 
      for (B bx: blist) {
            bx.printName(); 
        }
      A a5 = new A(4);
      D d3 = new D(); 
      a5.m1(); 
      a5.m2(); 
      d3.m1(); 
      d3.m2(); 
      
    }
}
