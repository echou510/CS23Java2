
public class D extends C
{
    public void m2(){System.out.println("D's m2"); }
    public void printName(){
        System.out.println("Class D"); 
    } 
}
