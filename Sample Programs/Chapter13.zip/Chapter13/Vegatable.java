
/**
 * Write a description of class Vegatable here.
 * 
 * @author (Eric Y. Chou) 
 * @version (04/10/2017)
 */
public class Vegatable extends Food
{
   public Vegatable(String name){
       super(name); 
    }

   public String cook(){
        return "Stir Fry! ";
    }
}
