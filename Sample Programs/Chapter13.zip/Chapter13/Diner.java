import java.util.ArrayList; 
/**
 * Write a description of class Diner here.
 * 
 * @author (Eric Y. Chou) 
 * @version (04/10/2017)
 */
public class Diner
{
   private ArrayList foodList; 
   public Diner(){
      foodList = new ArrayList<Food>(); 
    }
    
   public ArrayList getFoodList() {return foodList; } 
   
   public void allCook(){
      for (Food f: (ArrayList<Food>) foodList){
          System.out.println(f.getName()+" "+f.cook()); 
        } 
    }
   
   public static void main(String[] args){
       Diner d = new Diner(); 
       System.out.print("\f");
       d.getFoodList().add(new Meat("Beef")); 
       d.getFoodList().add(new Vegatable("Green Pepper"));
       d.getFoodList().add(new Meat("Lamb"));
       d.getFoodList().add(new Eggplant("Purple Eggplant"));
       d.getFoodList().add(new Vegatable("Brocolli"));
       
       d.allCook(); 
    }
}
