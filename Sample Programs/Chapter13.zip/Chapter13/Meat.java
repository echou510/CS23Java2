
/**
 * Write a description of class Meat here.
 * 
 * @author (Eric Y. Chou) 
 * @version (04/10/2017)
 */
public class Meat extends Food
{
   public Meat(String name){
      super(name); 
    }
   
   public String cook(){
      return "Braised"; 
    }
}
