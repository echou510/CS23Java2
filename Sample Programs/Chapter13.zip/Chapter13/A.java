import java.util.Arrays; 

public class A extends B implements Comparable<A>, I1, I2
{  
   public static int count = 0; // class variable 
   int a; // int get 0, double 0.0, boolean false, Ref String, Object null
          // instance variable       
   A(){}
   A(int x){ 
       super(); 
       a = x; 
       count++; 
    }
   public int getA() { return a; }
   public void setA(int x) { a = x; }
   public String toString(){
      return ""+a; 
    }
   public boolean equals(A other){
      return this.a == other.a; 
    }
   public int compareTo(A other){
       if (this.a > other.a) return 1; 
       if (this.a == other.a) return 0; 
       return -1; 
    }
   public void printName(){
        System.out.println("Class A"); 
    }
   public void m1() {System.out.println("A's m1"); }
   public void m2() {System.out.println("A's m2"); }
}
