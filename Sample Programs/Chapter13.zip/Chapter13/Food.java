
/**
 * Abstract class Food - write a description of the class here
 * 
 * @author (Eric Y. Chou)
 * @version (04/10/2017)
 */
public abstract class Food
{
   private String myName; 
   public Food(String name){
       myName = name;
    }
    
   public String getName(){
       return myName; 
    }
    
   public abstract String cook();
}
