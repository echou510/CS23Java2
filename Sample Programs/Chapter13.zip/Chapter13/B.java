public abstract class B
{  
   private int b=0; 
   B(){
      System.out.println(b); 
    }
   public int getB(){return b; }
   public abstract void printName();
}
