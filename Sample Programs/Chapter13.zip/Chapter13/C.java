
public abstract class C extends B implements I1, I2
{  
    public void m1(){}
    public abstract void m2(); 
}
