package a2;

import java.io.File; 
import java.io.PrintWriter; 
import java.io.IOException; 
/**
 * Write a description of class ComplexTest here.
 * 
 * @author (Eric Y. Chou) 
 * @version (V1, 10/22/2015)
 */
public class ComplexTest
{ 
    public static void main(String[] args) throws IOException {
       File oFile = new File("a2\\ComplexTest.txt");
       PrintWriter out = new PrintWriter(oFile); 
       Complex c1 = new Complex(1, 0); 
       Complex c2 = new Complex(0, 1); 
       
       out.println("Reading Complex: "); 
       out.println("c1 Real:      " + c1.getR());
       out.println("c1 Imaginary: " + c1.getI()); 
       out.println("c2 Real:      " + c2.getR());
       out.println("c2 Imaginary: " + c2.getI()); 
       out.println();
       out.println("Before Setting: ");
       out.println("c1: " + c1.toString());
       out.println("c2: " + c2.toString()); 
       c1.setComplex(2, 0); 
       c2.setComplex(0, 2); 
       out.println("After Setting: ");
       out.println("c1: " + c1.toString());
       out.println("c2: " + c2.toString());
        out.println();
       out.println("Addition c3=c1+c2: "); 
       Complex c3 = c1.add(c2); 
       out.println("c3 Real:      " + c3.getR());
       out.println("c3 Imaginary: " + c3.getI()); 
        out.println();
       out.println("Setting: ");
       out.println("c1: " + c1.toString());
       c1.setComplex(5,5); 
       out.println("Setting: ");
       out.println("c1: " + c1.toString());
        out.println();
       out.println("Addition c4=c1-c2: "); 
       Complex c4 = c1.minus(c2); 
       out.println("c4 Real:      " + c4.getR());
       out.println("c4 Imaginary: " + c4.getI());
        out.println();
       out.println("Negation of c4: "); 
       out.println("-c4:      " + c4.neg().toString());
        out.println();
       out.println("Conjugate of c4: "); 
       out.println("Conj(c4): " + c4.conjugate().toString());
        out.println();
       out.println("Inverse of c4: "); 
       out.println("Inv(c4): " + c4.inverse().toString2());
        out.println();
       out.println("Addition c4=c1*c2: "); 
       c4 = c1.multiply(c2); 
       out.println("c4:      " + c4.toString2());
        out.println(); 
       Complex c6 = new Complex(3, 2); 
       Complex c7 = new Complex(3, -2); 
       Complex c8 = c6.multiply(c7); 
       out.println("Multiplication c8=c6*c7: "); 
       out.println("c6: " + c6.toString2());
       out.println("c7: " + c7.toString2());
       out.println("c8: " + c8.toString2());
       out.println(); 
       out.println("Division c8=c6/c7: "); 
       c8 = c6.divide(c7); 
       out.println("c6: " + c6.toString2());
       out.println("c7: " + c7.toString2());
       out.println("c8: " + c8.toString2());
       out.println(); 
       out.println("Division c9=i/-i"); 
       Complex c10 = new Complex(0, 1); 
       Complex c11 = new Complex(0, -1); 
       Complex c9 = c10.divide(c11); 
       out.println("c9: " + c9.toString2());
       out.println(); 
       out.println("Scalar Multiplication/Division c8*3, c8*3i, c8/3, c8/3i:");
       out.println("c8*3:  " + c8.multiplyR(3).toString4());
       out.println("c8*3i: " + c8.multiplyI(3).toString4());
       out.println("c8/3:  " + c8.divideR(3).toString4());
       out.println("c8/3i: " + c8.divideI(3).toString4());
       out.println();
       out.println("i's arbitary order"); 
       Complex c12 = new Complex(0,1); 
       out.println("i's 5th order:   " + c12.pow(5).toString2()); 
       out.println("i's 0.5th order: " + c12.pow(0.5).toString2()); 
       out.println("i's 8th order:   " + c12.pow(8).toString2()); 
       out.println("i's -2th order:  " + c12.pow(-2).toString2()); 
       out.println("i's -2.5th order:" + c12.pow(-2.5).toString2()); 
       out.println(); 
       out.println("Rotation from i"); 
       out.println("PI/4:       " + c12.rotate(Math.PI/4.0).toString2()); 
       out.println("PI:         " + c12.rotate(Math.PI).toString2()); 
       out.println("1.5*PI:     " + c12.rotate(Math.PI*1.5).toString2()); 
       out.println("2.3*PI:     " + c12.rotate(Math.PI*2.3).toString2()); 
       out.println("270 degree: " + c12.rotateDegree(270).toString2()); 
       out.println("45 degree:  " + c12.rotateDegree(45).toString2()); 
       out.println(); 
       out.println("Show Functions for c6:");
       //out.println("c6's mag:      " + c6.mag());
       out.println("c6's abs:         " + String.format("%6.4f", c6.abs()));
       out.println("c6's angle:       " + String.format("%6.4f", c6.getTheta())); 
       out.println("c6's angleDegree: " + String.format("%6.4f", c6.getThetaDegree())); 
       out.println("c6's quadrant:    " + c6.getQuadrant());
       out.println(); 
       out.println("Complex Equality Check:"); 
       Complex c13 = new Complex(1.123456789, 1.123456789); 
       Complex c14 = new Complex(1.124567891, 1.124567891); 
       Complex c15 = new Complex(1.123456789, 1.124567891); 
       Complex c16 = new Complex(1.123456891, 1.123456789); 
       Complex c17 = new Complex(1.123456789, 1.123456891); 
       Complex c18 = new Complex(1.123456789, 1.123456781); 
       out.println("Is "+c13.toString()+" = "+c13.toString()+"? "+c13.equals(c13)); 
       out.println("Is "+c13.toString()+" = "+c13.toString()+"? "+c13.equals(c13)); 
       out.println("Is "+c13.toString()+" = "+c13.toString()+"? "+c13.equals(c13)); 
       out.println("Is "+c13.toString()+" = "+c14.toString()+"? "+c13.equals(c14)); 
       out.println("Is "+c13.toString()+" = "+c14.toString()+"? "+c13.equals4(c14)); 
       out.println("Is "+c13.toString()+" = "+c14.toString()+"? "+c13.equals8(c14)); 
       out.println("Is "+c13.toString()+" = "+c15.toString()+"? "+c13.equals(c15)); 
       out.println("Is "+c13.toString()+" = "+c15.toString()+"? "+c13.equals4(c15)); 
       out.println("Is "+c13.toString()+" = "+c15.toString()+"? "+c13.equals8(c15));        
       out.println("Is "+c13.toString()+" = "+c16.toString()+"? "+c13.equals(c16)); 
       out.println("Is "+c13.toString()+" = "+c16.toString()+"? "+c13.equals4(c16)); 
       out.println("Is "+c13.toString()+" = "+c16.toString()+"? "+c13.equals8(c16)); 
       out.println("Is "+c13.toString()+" = "+c17.toString()+"? "+c13.equals(c17)); 
       out.println("Is "+c13.toString()+" = "+c17.toString()+"? "+c13.equals4(c17)); 
       out.println("Is "+c13.toString()+" = "+c17.toString()+"? "+c13.equals8(c17)); 
       out.println("Is "+c13.toString()+" = "+c18.toString()+"? "+c13.equals(c18)); 
       out.println("Is "+c13.toString()+" = "+c18.toString()+"? "+c13.equals4(c18)); 
       out.println("Is "+c13.toString()+" = "+c18.toString()+"? "+c13.equals8(c18)); 

       out.close(); 
    }
}
