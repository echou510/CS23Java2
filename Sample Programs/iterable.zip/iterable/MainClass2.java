package iterable;

import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

/**
 * Write a description of class MainClass2 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class MainClass2 {
  public static void main(String[] args) {
    List list = Arrays.asList("A", "B", "C", "D");
     Iterator iterator = list.iterator();
     while (iterator.hasNext () ) {
         String element = (String) iterator.next ();
         System.out.println(element);
     }

  }
}