package iterable;


/**
 * Write a description of class MainClass4 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class MainClass4 {
  public static void main(String args[]) {
    IterableString x = new IterableString("This is a test.");

    for (char ch : x){
      System.out.println(ch);
    }
  }
}