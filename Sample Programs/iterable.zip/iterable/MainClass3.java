package iterable;

import java.util.Arrays;
import java.util.List;

/**
 * Write a description of class MainClass3 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class MainClass3 {
  public static void main(String[] args) {
    List list = Arrays.asList("A", "B", "C", "D");

    for (Object object : list) {
      System.out.println(object);
    }

  }
}
