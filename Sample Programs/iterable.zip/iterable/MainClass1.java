package iterable;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

/**
 * Write a description of class MainClass1 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class MainClass1 {
  public static void main(String[] a) {
    Collection c = new ArrayList();
    c.add("1");
    c.add("2");
    c.add("3");
    Iterator i = c.iterator();
    while (i.hasNext()) {
      System.out.println(i.next());
    }
  }
}