import java.io.File;
import java.util.Scanner; 

/**
 * Write a description of class DirectorySize here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class DirectorySize {
  public static void main(String[] args) {
    // Prompt the user to enter a directory or a file
    // System.out.print("Enter a directory or a file: ");    
    // Scanner input = new Scanner(System.in);
    // String directory = input.nextLine();
    
    String directory = "C:\\Eric_Chou\\Udemy\\APCSB\\BlueJ\\Chapter14"; 
          // Try a directory of your own, make sure the escape sequence is handled right. 
    // Display the size
    System.out.println(getSize(new File(directory)) + " bytes");
  }

  public static long getSize(File file) {
    long size = 0; // Store the total size of all files

    if (file.isDirectory()) {
      File[] files = file.listFiles(); // All files and subdirectories
      for (int i = 0; i < files.length; i++) {
        size += getSize(files[i]); // Recursive call
      }
    }
    else { // Base case
      size += file.length();
    }

    return size;
  }
}
