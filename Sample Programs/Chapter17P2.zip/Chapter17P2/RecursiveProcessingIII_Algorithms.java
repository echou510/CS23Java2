import java.util.Arrays; 
/**
 * Write a description of class RecursiveProcessingIII_Algorithms here.
 * 
 * @author (Eric Y. Chou) 
 * @version (03/04/2016)
 */
public class RecursiveProcessingIII_Algorithms
{
   static int[] a = {5, 3, 6, 7, 9, 24, 27, 1, 0 , 16}; 
    
   public static int search(int[] a, int key){
       return search(a, key, 0, -1); 
    }
   
   public static int search(int[] a, int key, int current, int result){
       if (current == a.length) return result; 
       if (a[current] == key) return current;  
       return search(a, key, current+1, result); 
    }
   
   public static int minIndex(int[] a){
        return minIndex(a, 0, Integer.MAX_VALUE, -1);     
    }
    
   public static int minIndex(int[] a, int current, int result, int index){
         if (current == a.length) return index; 
         if (a[current] < result) { result = a[current];  index = current; } 
         return minIndex(a, current+1, result, index);     
    }
    
   public static void sort(int[] a){
        int[] c = new int[a.length]; int[] b = new int[a.length];  
        for (int i=0; i<a.length; i++) c[i] = a[i];
        sort(c, b, 0); 
        for (int i=0; i<a.length; i++) a[i] = b[i]; 
    }
    
   public static void sort(int[] c, int[] b, int current){
        if(current == c.length) return; 
        b[current] = c[minIndex(c)];  
        c[minIndex(c)] = Integer.MAX_VALUE;
        sort(c, b, current+1); 
    }
    
   public static void main(String[] args){
        // Print out data in a1 using a2 array
        Integer[] a2 = new Integer[a.length];
        for (int i=0; i<a.length; i++) a2[i] = new Integer(a[i]); 
        System.out.println("Data: "+ Arrays.asList(a2).toString());   
        System.out.println("Key: "+12+" Index: "+search(a, 12)); 
        System.out.println("Key: "+27+" Index: "+search(a, 27));
        System.out.println("Key: "+ 5+" Index: "+search(a, 5));
        
        System.out.println("MinIndex: "+minIndex(a)); 
        sort(a); 
        for (int i=0; i<a.length; i++) a2[i] = new Integer(a[i]); 
        System.out.println("Data: "+ Arrays.asList(a2).toString());   

    }
}
