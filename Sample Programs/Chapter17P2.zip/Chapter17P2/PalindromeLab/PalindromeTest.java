import java.util.Scanner;
/**
 * Write a description of class PalindromeTest here.
 * 
 * This is the tester class of the program of Palindrome.  
 * It takes in the information from the Recursive Palindrome and shows it onto the screen of the computer.
 * My program tells the user to input a String or word and see whether or not it is a palindrome.
 * @author (Eric S. Chou Jr.) 
 * @version (V1 or 1/27/16)
 */
public class PalindromeTest
{
    //main function
     public static void main(String[] args){
         //Scanner function
        Scanner input = new Scanner(System.in);
        boolean done = false;
        //while loop
        while(!done){
            System.out.println("Please enter a String or a Word: ");
            String word = input.nextLine();
            Palindrome rp = new Palindrome();
            System.out.println(rp.isPalindrome(word));
            System.out.println("Do you want to continue(Y/N)? ");
            String yes = input.nextLine();
            //if loop
            if(yes.length()!= 0 && (yes.charAt(0)=='Y' || yes.charAt(0)== 'y')) done = false;
            else done = true;
        }
    }
    
}
