package a3;

import java.io.File; 
import java.io.PrintWriter; 
import java.io.IOException; 
/**
 * Write a description of class ComplexTest here.
 * 
 * @author (Eric Y. Chou) 
 * @version (V1, 10/22/2015)
 */
public class ComplexTest
{ 
    public static void main(String[] args) throws IOException {
       File oFile = new File("a3\\ComplexTestStatic.txt");
       PrintWriter out = new PrintWriter(oFile); 
       Complex c1 = new Complex(1, 0); 
       Complex c2 = new Complex(0, 1); 
       
       out.println("Reading Complex: "); 
       out.println("c1 Real:      " + c1.getR());
       out.println("c1 Imaginary: " + c1.getI()); 
       out.println("c2 Real:      " + c2.getR());
       out.println("c2 Imaginary: " + c2.getI()); 
       out.println();
       out.println("Before Setting: ");
       out.println("c1: " + Complex.toString(c1));
       out.println("c2: " + Complex.toString(c2)); 
       c1.setComplex(2, 0); 
       c2.setComplex(0, 2); 
       out.println("After Setting: ");
       out.println("c1: " + Complex.toString(c1));
       out.println("c2: " + Complex.toString(c2));
        out.println();
       out.println("Addition c3=c1+c2: "); 
       Complex c3 = Complex.add(c1, c2); 
       out.println("c3 Real:      " + c3.getR());
       out.println("c3 Imaginary: " + c3.getI()); 
        out.println();
       out.println("Setting: ");
       out.println("c1: " + Complex.toString(c1));
       c1.setComplex(5,5); 
       out.println("Setting: ");
       out.println("c1: " + Complex.toString(c1));
        out.println();
       out.println("Addition c4=c1-c2: "); 
       Complex c4 = Complex.minus(c1, c2); 
       out.println("c4 Real:      " + c4.getR());
       out.println("c4 Imaginary: " + c4.getI());
        out.println();
       out.println("Negation of c4: "); 
       out.println("-c4:      " + Complex.toString(Complex.neg(c4)));
        out.println();
       out.println("Conjugate of c4: "); 
       out.println("Conj(c4): " + Complex.toString(Complex.conjugate(c4)));
        out.println();
       out.println("Inverse of c4: "); 
       out.println("Inv(c4): " + Complex.toString2(Complex.inverse(c4)));
        out.println();
       out.println("Addition c4=c1*c2: "); 
       c4 = Complex.multiply(c1, c2); 
       out.println("c4:      " + Complex.toString2(c4));
        out.println(); 
       Complex c6 = new Complex(3, 2); 
       Complex c7 = new Complex(3, -2); 
       Complex c8 = Complex.multiply(c6, c7); 
       out.println("Multiplication c8=c6*c7: "); 
       out.println("c6: " + Complex.toString2(c6));
       out.println("c7: " + Complex.toString2(c7));
       out.println("c8: " + Complex.toString2(c8));
       out.println(); 
       out.println("Division c8=c6/c7: "); 
       c8 = Complex.divide(c6, c7); 
       out.println("c6: " + Complex.toString2(c6));
       out.println("c7: " + Complex.toString2(c7));
       out.println("c8: " + Complex.toString2(c8));
       out.println(); 
       out.println("Division c9=i/-i"); 
       Complex c10 = new Complex(0, 1); 
       Complex c11 = new Complex(0, -1); 
       Complex c9 = Complex.divide(c10, c11); 
       out.println("c9: " + Complex.toString2(c9));
       out.println(); 
       out.println("Scalar Multiplication/Division c8*3, c8*3i, c8/3, c8/3i:");
       out.println("c8*3:  " + Complex.toString4(Complex.multiplyR(c8, 3)));
       out.println("c8*3i: " + Complex.toString4(Complex.multiplyI(c8, 3)));
       out.println("c8/3:  " + Complex.toString4(Complex.divideR(c8, 3)));
       out.println("c8/3i: " + Complex.toString4(Complex.divideI(c8,3)));
       out.println();
       out.println("i's arbitary order"); 
       Complex c12 = new Complex(0,1); 
       out.println("i's 5th order:   " + Complex.toString2(Complex.pow(c12, 5))); 
       out.println("i's 0.5th order: " + Complex.toString2(Complex.pow(c12, 0.5))); 
       out.println("i's 8th order:   " + Complex.toString2(Complex.pow(c12, 8))); 
       out.println("i's -2th order:  " + Complex.toString2(Complex.pow(c12, -2))); 
       out.println("i's -2.5th order:" + Complex.toString2(Complex.pow(c12, -2.5))); 
       out.println(); 
       out.println("Rotation from i"); 
       out.println("PI/4:       " + Complex.toString2(Complex.rotate(c12, Math.PI/4.0))); 
       out.println("PI:         " + Complex.toString2(Complex.rotate(c12, Math.PI))); 
       out.println("1.5*PI:     " + Complex.toString2(Complex.rotate(c12, Math.PI*1.5))); 
       out.println("2.3*PI:     " + Complex.toString2(Complex.rotate(c12, Math.PI*2.3))); 
       out.println("270 degree: " + Complex.toString2(Complex.rotateDegree(c12, 270))); 
       out.println("45 degree:  " + Complex.toString2(Complex.rotateDegree(c12, 45))); 
       out.println(); 
       out.println("Show Functions for c6:");
       //out.println("c6's mag:      " + c6.mag());
       out.println("c6's abs:         " + String.format("%6.4f", Complex.abs(c6)));
       out.println("c6's angle:       " + String.format("%6.4f", c6.getTheta())); 
       out.println("c6's angleDegree: " + String.format("%6.4f", c6.getThetaDegree())); 
       out.println("c6's quadrant:    " + c6.getQuadrant());
       out.println(); 
       out.println("Complex Equality Check:"); 
       Complex c13 = new Complex(1.123456789, 1.123456789); 
       Complex c14 = new Complex(1.124567891, 1.124567891); 
       Complex c15 = new Complex(1.123456789, 1.124567891); 
       Complex c16 = new Complex(1.123456891, 1.123456789); 
       Complex c17 = new Complex(1.123456789, 1.123456891); 
       Complex c18 = new Complex(1.123456789, 1.123456781); 
       out.println("Is "+Complex.toString(c13)+" = "+Complex.toString(c13)+"? "+Complex.equals(c13, c13)); 
       out.println("Is "+Complex.toString(c13)+" = "+Complex.toString(c13)+"? "+Complex.equals(c13, c13)); 
       out.println("Is "+Complex.toString(c13)+" = "+Complex.toString(c13)+"? "+Complex.equals(c13, c13)); 
       out.println("Is "+Complex.toString(c13)+" = "+Complex.toString(c14)+"? "+Complex.equals(c13, c14)); 
       out.println("Is "+Complex.toString(c13)+" = "+Complex.toString(c14)+"? "+Complex.equals4(c13, c14)); 
       out.println("Is "+Complex.toString(c13)+" = "+Complex.toString(c14)+"? "+Complex.equals8(c13, c14)); 
       out.println("Is "+Complex.toString(c13)+" = "+Complex.toString(c15)+"? "+Complex.equals(c13, c15)); 
       out.println("Is "+Complex.toString(c13)+" = "+Complex.toString(c15)+"? "+Complex.equals4(c13, c15)); 
       out.println("Is "+Complex.toString(c13)+" = "+Complex.toString(c15)+"? "+Complex.equals8(c13, c15));        
       out.println("Is "+Complex.toString(c13)+" = "+Complex.toString(c16)+"? "+Complex.equals(c13, c16)); 
       out.println("Is "+Complex.toString(c13)+" = "+Complex.toString(c16)+"? "+Complex.equals4(c13, c16)); 
       out.println("Is "+Complex.toString(c13)+" = "+Complex.toString(c16)+"? "+Complex.equals8(c13, c16)); 
       out.println("Is "+Complex.toString(c13)+" = "+Complex.toString(c17)+"? "+Complex.equals(c13, c17)); 
       out.println("Is "+Complex.toString(c13)+" = "+Complex.toString(c17)+"? "+Complex.equals4(c13, c17)); 
       out.println("Is "+Complex.toString(c13)+" = "+Complex.toString(c17)+"? "+Complex.equals8(c13, c17)); 
       out.println("Is "+Complex.toString(c13)+" = "+Complex.toString(c18)+"? "+Complex.equals(c13, c18)); 
       out.println("Is "+Complex.toString(c13)+" = "+Complex.toString(c18)+"? "+Complex.equals4(c13, c18)); 
       out.println("Is "+Complex.toString(c13)+" = "+Complex.toString(c18)+"? "+Complex.equals8(c13, c18)); 
       System.out.println("Utility Methods:" + Complex.toString4(Complex.add(c1, c2))); 
             // Complex means class here not package, unless you have no import statement. 
       out.close(); 
    }
}

