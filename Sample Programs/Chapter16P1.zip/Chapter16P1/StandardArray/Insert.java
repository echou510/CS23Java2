package StandardArray;

import java.util.Arrays; 
/**
 * Write a description of class Insert here.
 * 
 * @author (Eric Y. Chou) 
 * @version (04/29/2016)
 */
public class Insert
{
   static int[] a = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9};
   
   static int[] insert(int[] a, int k, int value){
        if (k<0 || k>=a.length) return a; 
        int[] r = new int[a.length+1];
        
        for (int i=0; i<k; i++){ r[i] = a[i]; }
        r[k] = value; 
        for (int i=k+1; i<r.length; i++) r[i] = a[i-1]; 
        
        return r; 
    }
    
   public static void main(String[] args){
      Integer[] aa = new Integer[a.length]; for (int i=0; i<a.length; i++) aa[i] = a[i];
      System.out.println("Original Array="+Arrays.asList(aa)); 
      int[] r = insert(a, 6, 99); 
      Integer[] rr = new Integer[r.length]; for (int i=0; i<r.length; i++) rr[i] = r[i]; 
      System.out.println("After insert "+99+" Array="+Arrays.asList(rr)); 
    }
}
