package StandardArray;


/**
 * Write a description of class Traversal here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Traversal
{  public static int[] a = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9};
   public static int[] b = new int[10]; 
   public static int[] c = new int[20]; 
   
   public static void traversalFor(){
        for (int i=0; i<a.length; i++){
           System.out.print(a[i]+" "); 
        }
        System.out.println(); 
    } 
    
   public static void traversalForB(){
        for (int i=0; i<b.length; i++){
           System.out.print(b[i]+" "); 
        }
        System.out.println(); 
    }
   public static void traversalForC(){
        for (int i=0; i<c.length; i++){
           System.out.print(c[i]+" "); 
        }
        System.out.println(); 
    }   
   public static void traversalWhile(){
        int i=0;
        while (i<a.length){
           System.out.print(a[i]+" "); 
           i++; 
        }
        System.out.println(); 
    } 
    
   public static void traversalReverseCopy(){
        int j=b.length-1; 
        for (int i=0; i<a.length; i++){
            b[j] = a[i]; 
            j--; 
        }
    }    
    
   public static void traversalJumpCopy(){
        int j=0; 
        for (int i=0; i<a.length; i++){
            c[j] = a[i]; 
            j+=2; 
        }
    }              
   public static void main(String[] args){
        System.out.print("A[0..9]= "); 
        traversalFor(); 
        System.out.print("A[0..9]= "); 
        traversalWhile(); 
        traversalReverseCopy(); 
        traversalJumpCopy(); 
        System.out.print("A[0..9]= "); 
        traversalFor(); 
        System.out.print("B[0..9]= "); 
        traversalForB(); 
        System.out.print("C[0..19]= "); 
        traversalForC(); 
    }
}
