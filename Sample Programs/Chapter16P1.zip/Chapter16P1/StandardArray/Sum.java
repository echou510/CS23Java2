package StandardArray;

import java.util.ArrayList; 
import java.util.List; 
import java.util.Arrays;
/**
 * AP FRQ Design Patterns
 * 1. sum of array
 * 2. sum of 2D array
 * 3. sum of arraylist
 */
public class Sum
{
  static int[] a = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9};
  static Integer[] b = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9};// Integer in wrapper type
  static int[][] m = {{1, 2, 3}, {4, 5, 6}, {7, 8, 9}};
  static List<Integer> blist = new ArrayList<Integer>(); 
  
  public static int SumArray(int[] t){
       int sum=0; 
       for (int i=0; i<t.length; i++){
           sum += t[i]; 
        }
       return sum; 
    }
     
  public static int Sum2DArray(int[][] t){
       int sum=0; 
       for (int i=0; i<t.length; i++){
         for (int j=0; j<t[0].length; j++){
            sum += t[i][j]; 
          }
        }
       return sum; 
    } 
  
  public static int SumArrayList(List<Integer> al){
      int sum =0; 
        for (Integer i: al){
            sum += i;
        }
      return sum; 
    }  
    
  public static void main(String[] args){
       blist = Arrays.asList(b);     // convert Integer[] array to List
       System.out.println("1D Sum="+SumArray(a));
       System.out.println("2D Sum="+Sum2DArray(m));
       System.out.println("ArrayList Sum="+SumArrayList(blist));
    }
}
