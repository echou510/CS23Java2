package StandardArray;

public class TestArray{
  public static void main(String[] args){
    System.out.println("Your code: ");
    Integer i1 = 127;
    Integer i2 = 127;
    System.out.println("i1.intValue() == i2.intValue ->"+(i1.intValue() == i2.intValue()));
    Integer i3 = 128;
    Integer i4 = 128;
    System.out.println("i3 == i4 ->"+(i3 == i4)); 
    System.out.println("i3.intValue() == i4.intValue() ->"+(i3.intValue() == i4.intValue()));
    int i5 = i3; 
    int i6 = i4; 
    System.out.println("i5 == i6  ->"+(i5 == i6)); 
    System.out.println("i3 == i4  ->"+(i3 == i4));   
    System.out.println("i3.equals(i4) ->"+i3.equals(i4)); 
  }
}
