package StandardArray;

import java.util.ArrayList; 
import java.util.List; 
import java.util.Arrays;
/**
 * AP FRQ Design Patterns
 * 1. index of maximum of array               (finding min Index value is in the comments) 
 * 2. index of maximum of 2D array
 * 3. index of maximum of arraylist
 */
public class MaxIndex
{
  static int[] a = {5, 7, 3, 4, 9, 8, 0, 1, 2, 6};
  static Integer[] b = {5, 7, 3, 4, 9, 8, 0, 1, 2, 6};// Integer in wrapper type
  static int[][] m = {{5,7,3}, {4, 9, 8}, {1, 2, 6}};
  static List<Integer> blist = new ArrayList<Integer>(); 
  
  static class Index{  // class to allow return of two index values
      int i, j; 
      Index (int i, int j){ 
          this.i = i; 
          this.j = j; 
        }
      public String toString(){
          return "["+this.i+", "+this.j+"]"; 
        }
    }
  
  public static int maxIndexArray(int[] t){
       int max = t[0];                       // int min = t[0]; 
       int maxIndex = 0;                     // int minIndex = 0; 
       for (int i=0; i<t.length; i++){
           if (t[i]>max) {max = t[i]; maxIndex = i; }   // if (t[i]<min) {min = t[i]; minIndex = i;}
        }
       return maxIndex;                           // return minIndex
    }
     
  public static Index maxIndex2DArray(int[][] t){
       int max = t[0][0];                    // int min = t[0][0];
       Index maxIndex = new Index(0, 0);     // Index minIndex = new Index(0,0); 
       for (int i=0; i<t.length; i++){
         for (int j=0; j<t[0].length; j++){
            if (t[i][j]>max) { max = t[i][j]; maxIndex = new Index(i, j); }   // if (t[i][j]<min) {min = t[i][j]; minIndex = new Index(i, j);}
          }
        }
       return maxIndex;                           // return minIndex
    } 
  
  public static int maxArrayList(List<Integer> al){
      int max = al.get(0);                          // int min = al.get(0); 
      int maxIndex = 0;                             // int minIndex = 0; 
        int count = 0; 
        for (Integer i: al){
            if (i>max) {max = i; maxIndex = count;}            // if (i<min) {min = i; maxIndex = cout; }
            count++; 
        }
      return maxIndex;                              // return minIndex
    }  
    
  public static void main(String[] args){
       blist = Arrays.asList(b);     // convert Integer[] array to List
       System.out.println("1D Max Index="+maxIndexArray(a));
       System.out.println("2D Max Index ="+maxIndex2DArray(m));
       System.out.println("ArrayList Max Index="+maxArrayList(blist));
    }
}
