package numbers;

/**
 * @author Eric Y. Chou
 */
public class ShowNumbers {

  /**
   * @param args the command line arguments
   */
  public static void main(String[] args) {
    Number[] nums = new Number[]{
      100,              // int
      333.44,           // double
      (float) 333.44,
      new java.math.BigDecimal(111.555555555555555555555555555),
    };
    for(Number num: nums) {
      System.out.println(num.doubleValue());
    }
  }

}
