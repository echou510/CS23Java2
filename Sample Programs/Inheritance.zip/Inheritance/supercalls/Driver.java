package supercalls;

class SuperClass {
  public void foo() {
    System.out.println("SuperClass.foo");
  }
}

class SubClass extends SuperClass {
  @Override
  public void foo() {
    System.out.println("SubClass.foo");
    super.foo();
  }
}

class SubSubClass extends SubClass {
  @Override
  public void foo() {
    System.out.println("SubSubClass.foo");
    super.foo();
  }
}

public class Driver {
  public static void main(String[] args) {
    SuperClass obj = new SubSubClass();
    obj.foo();
  }
}
