package people1;

/**
 *
 * @author Eric Y. Chou
 */
public class Staff extends Employee {
  protected String office;
  protected Staff() { }
  public Staff(String name, int id, double salary, String office) {
    this.name = name;
    this.id = id;
    this.salary = salary;
    this.office = office;
  }
}
