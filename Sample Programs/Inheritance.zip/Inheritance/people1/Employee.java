package people1;

/**
 *
 * @author Eric Y. Chou
 */
public class Employee extends Person {
  protected double salary;
  protected Employee() { }
  public Employee(String name, int id, double salary) {
    this.name = name;
    this.id = id;
    this.salary = salary;
  }
}
