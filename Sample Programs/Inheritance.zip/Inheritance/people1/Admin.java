package people1;

/**
 *
 * @author Eric Y. Chou
 */
public class Admin extends Staff {
  protected int parkingSpace;
  public Admin(String name, int id, double salary, String office, int parkingSpace) {
    this.name = name;
    this.id = id;
    this.salary = salary;
    this.office = office;
    this.parkingSpace = parkingSpace;
  }
}
