package people1;

/**
 *
 * @author Eric Y. Chou
 */
public class Student extends Person {
  protected double gpa;
  public Student(String name, int id, double gpa) {
    this.name = name;
    this.id = id;
    this.gpa = gpa;
  }
}
