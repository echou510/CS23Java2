package anonymous;

public class Driver {

  public static void main(String[] args) {
    User joe = new User("Joe Jones", 111111);

    User joe1 = new User("Joe Jones", 111111) {
      @Override
      public String toString() {
        return "My Buddy";
      }
    };
    
    System.out.println("anonymous class: " + joe1.getClass());

    System.out.println(joe);
    
    System.out.println(joe1);
  }
}
