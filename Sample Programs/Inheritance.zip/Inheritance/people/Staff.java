package people;

/**
 *
 * @author Eric Y. Chou
 */
public class Staff extends Employee {
  private String office;
  public Staff(String name, int id, double salary, String office) {
    super(name, id, salary);
    this.office = office;
  }
}
