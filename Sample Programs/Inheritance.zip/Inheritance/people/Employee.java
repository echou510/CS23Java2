package people;

/**
 *
 * @author Eric Y. Chou
 */
public class Employee extends Person {
  private double salary;
  public Employee(String name, int id, double salary) {
    super(name,id);
    this.salary = salary;
  }
}
