package people;

/**
 *
 * @author Eric Y. Chou
 */
public class Admin extends Staff {
  private int parkingSpace;
  public Admin(String name, int id, double salary, String office, int parkingSpace) {
    super(name, id, salary, office);
    this.parkingSpace = parkingSpace;
  }
}
