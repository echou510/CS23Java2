package people;

/**
 *
 * @author Eric Y. Chou
 */
public class Student extends Person {
  private double gpa;
  public Student(String name, int id, double gpa) {
    super(name, id);
    this.gpa = gpa;
  }
}
