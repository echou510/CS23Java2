package exceptions;

class ExceptionA extends Exception {
  public ExceptionA(String message) {
    super(message);
  }
}

class ExceptionB extends Exception {
  public ExceptionB(String message) {
    super(message);
  }
}

class ExceptionC extends ExceptionB {
  public ExceptionC(String message) {
    super(message);
  }
}

public class ThrowsClause {

  public static void main(String[] args) 
                             throws ExceptionA, ExceptionB, ExceptionC 
  {
    java.util.Random rand = new java.util.Random();
    int x = rand.nextInt(40);
    if (x < 10) {
      throw new ExceptionA("test1");
    }
    else if (x < 20) {
      throw new ExceptionB("test2");
    }
    else if (x < 30) {
      throw new ExceptionC("test3");
    }
  }
}
