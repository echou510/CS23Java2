package exceptions;

import java.util.Scanner;

/**
 * @author Eric Y. Chou
 */
public class UserDefined {

  /**
   * @param args the command line arguments
   */
  public static void main(String[] args) {
    class TooBigException extends Exception {
      TooBigException(String msg) { super(msg); }
    }
    class TooSmallException extends Exception {
      TooSmallException(String msg) { super(msg); }
    }
    
    Scanner in = new Scanner(System.in);
    while (true) {
      try {
        System.out.print("==> enter number (empty to stop): ");
        String line = in.nextLine().trim();
        if (line.isEmpty()) {
          break;
        }
        double x = Double.parseDouble(line);
        if ( x > 1000 ) {
          throw new TooBigException("Too big");
        }
        else if ( x < -1000) {
          throw new TooSmallException("Too small");          
        }
        System.out.println("Just Right");
      }
      catch (RuntimeException ex) {
        System.out.println("Invalid Double");
      }
      catch(TooBigException ex) {
        System.out.println(ex.getMessage());
      }
      catch(TooSmallException ex) {
        System.out.println(ex.getMessage());
      }
    }
  }

}
