package base;


/**
 * Write a description of class NewNain here.
 * 
 * @author (Eric Y. Chou) 
 * @version (01/22/2016)
 */
 class SuperClass {
  public SuperClass(int x) { System.out.println("SuperClass: " + x); }  
}
 
class SubClass extends SuperClass {
  public SubClass() {
    super(5);
    System.out.println("SubClass"); 
  }  
}

public class NewMain2 {
  public static void main(String[] args) {
    SuperClass obj = new SubClass();
  }
}
