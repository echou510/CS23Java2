package base;

/**
 * Write a description of class NewNain here.
 * 
 * @author (Eric Y. Chou) 
 * @version (01/22/2016)
 */
class SuperClass {
  public SuperClass() { System.out.println("SuperClass"); }  
}
 
class SubClass extends SuperClass {
  public SubClass() { System.out.println("SubClass"); }  
}
 
public class NewMain {
  public static void main(String[] args) {
    SuperClass obj = new SubClass();
  }
}
