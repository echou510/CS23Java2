package equality;

public class UserEquality {
  public static void main(String[] args) {
    User joe = new User("Joe Smith");
    User joe1 = joe;
    User joe2 = new User("Joe Jones");
    User joe3 = new User("Joe Smith");
    
    System.out.println("joe.equals(joe1): " + joe.equals(joe1));
    System.out.println("joe.equals(joe2): " + joe.equals(joe2));
    System.out.println("joe.equals(joe3): " + joe.equals(joe3));

    System.out.println("joe.equals(null): " + joe.equals(null));

    String str = "Joe Smith";

    System.out.println("joe.equals(str): " + joe.equals(str));
    
    User joeSpecial = new SpecialUser("Joe Smith");
    
    System.out.println("joe.equals(joeSpecial): " + joe.equals(joeSpecial));
  }
}
