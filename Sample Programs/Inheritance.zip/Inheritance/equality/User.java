package equality;

public class User { 
  private String name;
  public User(String name) { this.name = name; }
  @Override
  public String toString() { return name; }
  
  // remove /* and */ to uncomment the equals method to enable the custome equals() method. 
  /*
  @Override
  public boolean equals(Object obj) {
    if (obj == null) {
      return false;
    }
    if ( ! this.getClass().equals( obj.getClass() )) {
      return false;
    }    
    String objName = ((User)obj).name;
    return name.equals(objName);
  }
  */
}

