package equality;

public class SpecialUser extends User {
  public SpecialUser(String name) { super(name); }
}
