package equality;

public class Wrappers {

  public static void main(String[] args) {
    Integer m = new Integer(33);
    Integer n = m;
    Integer p = new Integer(33);
    Integer q = 55;
    
    String s = new String("33");
    Double d = new Double(33);
    
    System.out.println("m == n:" + (m==n));
    System.out.println("m == p:" + (m==p));
    System.out.println();

    System.out.println("m.equals(n): " + m.equals(n));
    System.out.println("m.equals(p): " + m.equals(p));
    System.out.println("m.equals(q): " + m.equals(q));
    System.out.println("m.equals(s): " + m.equals(s));
    System.out.println("m.equals(d): " + m.equals(d));
    System.out.println("m.equals(null): " + m.equals(null));
    System.out.println();
    
    String str1 = "22";
    String str2 = "2233".substring(0, 2);
    
    System.out.println("str1 == str2: " + (str1 == str2));
    System.out.println("str1.equals(str2): " + (str1.equals(str2))); 
  }
}
