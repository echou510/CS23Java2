package absfinal;

public abstract class SuperClass {
 public void foo() { System.out.println("Super:foo"); }
 //public abstract void foo();

 //public void bar() { System.out.println("Super:bar"); }
 public final void bar() { System.out.println("Super:bar"); }
}
