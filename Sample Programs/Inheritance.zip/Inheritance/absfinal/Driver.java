package absfinal;

public class Driver {
  public static void main(String[] args) {
    SuperClass obj = new SubClass();
    obj.foo();
    obj.bar();
  }
}
