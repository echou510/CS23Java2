package absfinal;

public class SubClass extends SuperClass {
  @Override
  public void foo() { System.out.println("foo"); }
  
  //@Override
  //public void bar() { System.out.println("bar"); }
}
