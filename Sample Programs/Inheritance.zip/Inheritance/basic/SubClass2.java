package basic;

public class SubClass2 extends SuperClass {
  @Override
  public void pervasive() {
    System.out.println("pervasive in SubClass2");
  }
}
