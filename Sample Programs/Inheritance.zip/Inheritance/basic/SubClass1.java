package basic;

public class SubClass1 extends SuperClass {
  @Override
  public void pervasive() {
    System.out.println("pervasive in SubClass1");
  }
}
