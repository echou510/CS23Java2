package basic;

public class SuperClass {
  public void top() {
    System.out.println("top in SuperClass");
  }
  public void pervasive() {
    System.out.println("pervasive in SuperClass");
  }
}
