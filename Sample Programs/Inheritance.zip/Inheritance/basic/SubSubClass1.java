package basic;

public class SubSubClass1 extends SubClass1 {
  @Override
  public void pervasive() {
    System.out.println("pervasive in SubSubClass1");
  }
  public void bottom() {
    System.out.println("bottom in SubSubClass1");
  }
}
