package basic;

public class Driver {

  public static void main(String[] args) {
    SuperClass[] objs = new SuperClass[] {
      new SuperClass(),
      new SubClass1(),
      new SubClass2(),
      new SubSubClass1(),
    };
        
    System.out.println("\n====> calls to top");
    for(SuperClass obj: objs) {
      System.out.print("---- obj in " + obj.getClass().getSimpleName());
      System.out.print(" calls: ");
      obj.top();
    }
    
    System.out.println("\n====> calls to pervasive");
    for(SuperClass obj: objs) {
      System.out.print("---- obj in " + obj.getClass().getSimpleName());
      System.out.print(" calls: ");
      obj.pervasive();
    }

    System.out.println("\n====> calls to bottom");
    for(SuperClass obj: objs) {
      System.out.print("---- obj in " + obj.getClass().getSimpleName());
      if (obj instanceof SubSubClass1) {
        System.out.print(" calls ");
        ((SubSubClass1) obj).bottom();
      }
      else {
        System.out.println();
      }
    }
    
    System.out.println("\n====> casting changes nothing about pervasive call");
    SuperClass obj = new SubSubClass1();
    System.out.print("---- obj in " + obj.getClass().getSimpleName());
    System.out.println(" casted to SubClass1 type, calls pervasive");
    ((SubClass1) obj).pervasive();
  }
}
