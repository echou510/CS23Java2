
/**
 * Write a description of class TestFaculty here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class TestFaculty
{
    public static void main(String[] args){
      Faculty fc = new Faculty(); 
    }
}
