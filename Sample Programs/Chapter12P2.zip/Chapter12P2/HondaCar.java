public class HondaCar extends Car{
    String model;     
    HondaCar(int year, String m){
        super("Honda", year); 
        model = m; 
    }
    
    public String toString(){
      return String.format("HondaCar(%s, %s, %d)", brand, model, year);
    }
}
