
/**
 * Write a description of class TestCars here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class TestCars
{   static Car[] carlist = {new Car("Honda", 2012), new HondaCar(2013, "CIVIC"), new HondaCRV(2015, "John Doe")}; 
    public static void main(){
      for (Car c: carlist){
            System.out.println(c); 
        }
    }
}
