
/**
 * Write a description of class AccumulatedSum here.
 *
 * @author (Eric Y. Chou)
 * @version (08/27/2019)
 */
public class AccumulatedSum
{
    public static int sum(int n, int s){
      if (n==0) return s; 
      return sum(n-1, s+n); 
    }
    
    public static void main(String[] args){
      System.out.print("\f");
      System.out.println(sum(10, 0)); 
    }
}
