
/**
 * Write a description of class AccumultedProduct here.
 *
 * @author (Eric Y. Chou)
 * @version (08/27/2019)
 */
public class AccumultedProduct
{
   public static int product(int n, int s){
      if (n==0) return s; 
      return product(n-1, s*n); 
    }
    
    public static void main(String[] args){
      System.out.print("\f");
      System.out.println(product(5, 1)); 
    }
}


